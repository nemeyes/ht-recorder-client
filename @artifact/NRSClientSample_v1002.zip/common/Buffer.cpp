#include "StdAfx.h"
#include "buffer.h"

static const size_t BUFFER_ADD_SIZE = 1024;
static const size_t LIMIT_BUFFER_SIZE	= 300 * 1024;	// 300K

CBuffer::CBuffer(size_t nSize /*= 512*/)
:m_nUsed(0)
,m_pBuffer(NULL)
,m_nStartPos(0)
,m_nEndPos(0)
{
	size_t size = nSize + 32;
	m_nSize = size;
	m_nInitSize = size;
	m_nLimitMove = size / 2;

	m_pBuffer = (char*)malloc(size);
	if(m_pBuffer == NULL)
	{
		m_nSize = 0;
		TRACE(_T("CBuffer::���� ����~~~ size: %I64u\n"), nSize);
	}

	if(nSize > LIMIT_BUFFER_SIZE)
		m_nLimitSize = m_nInitSize * 2;
	else
		m_nLimitSize = LIMIT_BUFFER_SIZE;
}

CBuffer::~CBuffer(void)
{
	if(m_pBuffer)
	{
		free(m_pBuffer);
		m_pBuffer = NULL;
	}
}

inline BOOL CBuffer::CheckBuffer(size_t nSize)
{
	size_t nTotal = m_nEndPos + nSize;
	if(nTotal > m_nSize)
	{
		size_t size = m_nSize + nTotal + BUFFER_ADD_SIZE;
		size_t padding = size % 32;

		m_pBuffer = (char*)realloc(m_pBuffer, size + padding);
		if(m_pBuffer == NULL)
		{
			m_nSize = 0;
			m_nUsed = 0;
			m_nEndPos = 0;
			m_nStartPos = 0;
			TRACE(_T("CBuffer::CheckBuffer ����~~~\n"));

			return FALSE;
		}

		m_nSize = size + padding;
		m_nLimitMove = size / 2;
	}

	return TRUE;
}

size_t CBuffer::GetSize() const
{
	return m_nUsed;
}

size_t CBuffer::GetCapacity() const
{
	return m_nSize;
}

void CBuffer::Assign(const void *pData, size_t nDataSize)
{
	if(pData)
	{
		if(!CheckBuffer(nDataSize + 32))
			return;
		
		memcpy(m_pBuffer, pData, nDataSize);
	}
	m_pBuffer[ nDataSize ]  = '\0';
	m_nUsed = nDataSize;
	
	m_nStartPos = 0;
	m_nEndPos = nDataSize;
}

void CBuffer::Append(const void *pData, size_t nDataSize)
{
	if(pData)
	{
		if(!CheckBuffer(nDataSize + 32))
			return;

		CopyMemory(m_pBuffer + m_nEndPos, pData, nDataSize);
		m_pBuffer[ m_nEndPos + nDataSize ] = '\0';
	}
	m_nUsed += nDataSize;
	m_nEndPos += nDataSize;
}

void CBuffer::Erase(size_t nStart /*= 0*/, size_t nCount /*= UINT_MAX*/)
{
	if(nStart > m_nUsed) return;
	if(nCount == UINT_MAX) nCount = m_nUsed;

	size_t nEnd = m_nStartPos + nStart + nCount;

	// ����� ����ũ�⺸�� ũ�ٸ� ��� ������ ����. ���� �����͸� �̵�
	if(nEnd >= m_nEndPos)
	{
		m_nEndPos = m_nStartPos + nStart;
		m_nUsed = m_nEndPos - m_nStartPos;

		if(m_nStartPos == m_nEndPos)
		{
			m_nStartPos = 0;
			m_nEndPos = 0;
		}

		return;
	}

	// ����� ���ۺ��� �۴ٸ� �տ� �����͸� �̵���.
	if(nStart == 0)
	{
		// ���۰� ���� �տ� ��ġ���� ������.
		m_nStartPos += nCount;
		m_nUsed -= nCount;
		if(m_nStartPos > m_nLimitMove)
		{
			//TRACE("�޸� �̵�~~~(%d)\n", m_nUsed);
			memmove(m_pBuffer, m_pBuffer + m_nStartPos, m_nUsed);
			m_nStartPos = 0;
			m_nEndPos = m_nUsed;
		}
	}
	else
	{
		// ���۰� �߰������� ������. �޸� �̵�
		memmove(m_pBuffer + m_nStartPos + nStart, m_pBuffer + nEnd, m_nUsed - nCount);
		m_nEndPos -= nCount;
		m_nUsed -= nCount;
	}

	if(m_nSize > m_nLimitSize)
	{
		size_t size = m_nUsed;
		size_t padding = size % 32;

		if(m_nUsed < size + padding)
		{
			//TRACE("���� ������ Ŀ����... ���ʱ�ȭ: %d -> %d\n", m_nSize, size + padding);

			char *pTemp = m_pBuffer;
			m_pBuffer = (char*)malloc(size + padding);

			memcpy(m_pBuffer, pTemp + m_nStartPos, m_nUsed);
			m_pBuffer[m_nUsed] = '\0';
			m_nStartPos = 0;
			m_nEndPos = m_nUsed;
			m_nSize = size + padding;

			free(pTemp);
		}
	}
}

char* CBuffer::GetPtr()
{
#if 0
	return m_pBuffer;
#endif
	return m_pBuffer + m_nStartPos;
}

size_t CBuffer::SetReserve(size_t nSize)
{
	if(nSize > m_nSize)
	{
		m_pBuffer = (char*)realloc(m_pBuffer, nSize);
		m_nSize = nSize;
	}

	return m_nSize;
}

void CBuffer::SetSize(size_t nSize)
{
	if(nSize > m_nSize)
	{
		size_t size = nSize + BUFFER_ADD_SIZE;
		size_t padding = size % 32;

		m_pBuffer = (char*)realloc(m_pBuffer, size + padding);
		m_nSize = size + padding;
	}
	m_nUsed = nSize;
	m_nEndPos = m_nUsed;

	m_pBuffer[ m_nUsed ] = '\0';
}

void CBuffer::Init(size_t nSize)
{
	if(m_pBuffer)
		free(m_pBuffer);

	size_t size = nSize + BUFFER_ADD_SIZE;
	size_t padding = size % 32;

	m_pBuffer = (char*)malloc(size);

	m_nUsed = 0;
        m_nEndPos = 0;
	m_nSize = size;
	m_pBuffer[0] = '\0';
}