#pragma once
#include <vector>

class CBitArray
{
public:
	CBitArray(size_t nBits = 32);
	virtual ~CBitArray();

	void Assign(BYTE* pArray, size_t nSize);
	void ExclusiveOR(BYTE *pArray, size_t nSize);
	void Resize(size_t nBits);
	void Reset();
	BOOL Get(size_t nBit) const;
	void Set(size_t nBit, BOOL bVal = TRUE);
	size_t	GetCount() const { return m_nCount; }

protected:
	std::vector<BYTE> m_Bits;
	size_t m_nCount;
};
