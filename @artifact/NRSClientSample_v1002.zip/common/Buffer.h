#pragma once

class CBuffer
{
public:
	CBuffer(size_t nSize = 512);
	~CBuffer(void);

	void Assign(const void *pData, size_t nDataSize);
	void Append(const void *pData, size_t nDataSize);
	void Erase(size_t nStart = 0, size_t nCount = UINT_MAX);
		
	size_t GetSize() const;
	size_t GetCapacity() const;
	char* GetPtr();

	size_t SetReserve(size_t nSize);
	void SetSize(size_t nSize);		// ���� �ʱ�ȭ ���� ����.
	void Init(size_t nSize);	// ���� �ٽ� �ʱ�ȭ

	inline BOOL CheckBuffer(size_t nSize);
private:
	char *m_pBuffer;
	size_t m_nSize;
	size_t m_nUsed;
	size_t m_nStartPos;
	size_t m_nEndPos;

	size_t m_nInitSize;
	size_t m_nLimitSize;
	size_t m_nLimitMove;
};
