#include "stdafx.h"
#include "BitArray.h"

CBitArray::CBitArray(size_t nBits /*= 32*/)
{
	Resize(nBits);
}

CBitArray::~CBitArray()
{
}

void CBitArray::Assign(BYTE* pArray, size_t nSize)
{
	Resize(nSize * 8);
	for(size_t i=0; i<nSize; i++)
		m_Bits[i] = pArray[i];
}

void CBitArray::ExclusiveOR(BYTE *pArray, size_t nSize)
{
	size_t nCount = m_Bits.size();
	BYTE value;
	for(size_t i=0; i<nCount; i++)
	{
		if(i < nSize)
		{
			value = m_Bits[i];
			m_Bits[i] = ( value | pArray[i] );
		}
	}
}

void CBitArray::Resize(size_t nBits)
{
	m_nCount = nBits;

	size_t nSize = (nBits / 8) + 1;

	m_Bits.resize(nSize, 0x00);
}

void CBitArray::Reset()
{
	if(m_Bits.empty())
		return;

	ZeroMemory(&m_Bits[0], m_Bits.size());
}

BOOL CBitArray::Get(size_t nBit) const
{
	if(nBit > m_nCount)
		return FALSE;

	BYTE mask = 0x01 << (nBit % 8);

	return ( m_Bits[nBit/8] & mask );
}

void CBitArray::Set(size_t nBit, BOOL bVal /*= TRUE*/)
{
	if(nBit > m_nCount)
		return;

	BYTE value = m_Bits[nBit/8];
	BYTE mask = 0x01 << (nBit % 8);

	m_Bits[nBit/8] = bVal ? ( value | mask ) : (value & ~mask);
}