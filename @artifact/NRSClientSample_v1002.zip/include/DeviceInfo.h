#pragma once
#include <BitArray.h>
#include "RecordInfo.h"
#include "EventInfo.h"

class NVRDEVICE_CAM_INFO;

enum XTREE_CAMERA_STATUS {
	ITEM_NONE = -1,
	ITEM_DISABLED = 0, // Disabled Camera Item (Disconnected)
	ITEM_ENABLED,      // Enabled Camera Item (Connected)
	ITEM_RECORD,       // Recording Camera Item (Recording)
	ITEM_EVENT,        // Event Blink Mode (Event but not Recording)
	ITEM_EVENT_REC,    // Event Recording Blink Mode (Event Recording)
	ITEM_ADDED
};

enum NC_DEVICE_TYPE
{
	NC_DEVICE_UNKNOWN	= 0,
	NC_DEVICE_NAUTILUS,
	NC_DEVICE_HITRON_CAMERA,
	NC_DEVICE_ONVIF_CAMERA,
	NC_DEVICE_HITRON_NVR,
	NC_DEVICE_HITRON_NVR_CAM,
};

BOOL IsSequenceDevice(NC_DEVICE_TYPE DeviceType);
BOOL IsCameraDevice(NC_DEVICE_TYPE DeviceType);
BOOL IsNVRDevice(NC_DEVICE_TYPE DeviceType);
BOOL IsNVRCamera(NC_DEVICE_TYPE DeviceType);

BOOL IsDevice(NC_DEVICE_TYPE DeviceType);

typedef struct _ONVIF_INFO {
	CString			strServiceUri;
	CString			strPtzUri;
	CString			strPtzToken;
} ONVIF_INFO;


struct _GROUP_INFO;
//	Device ��ġ ����
class DEVICE_INFO
{
public:
	DEVICE_INFO();
	virtual ~DEVICE_INFO();
	virtual void	Free() {}

	NC_DEVICE_TYPE	GetDeviceType() const { return DeviceType; }
	UINT			GetKeyID() const { return nKeyID; }
	// MAC have not delimiter character. (ex: ':', '-')
	CString			GetMAC() { return strMAC; }
	CString			GetProfileName() const { return strProfileName; }
	CString			GetModelType() const { return strModelType; }
	CString			GetModel() const { return strModel; }
	CString			GetID() const { return strID; }
	CString			GetName() const { return strName; }
	CString			GetAddress() const { return strAddress; }
	CString			GetURL() const { return strURL; }
	UINT			GetRTSPPort() const { return nRTSPPort; }
	UINT			GetHTTPPort() const { return nHTTPPort; }
	UINT			GetHTTPSPort() const { return nHTTPSPort; }
	BOOL			GetSSL() const { return bSSL; }
	UINT			GetConnectionType() const { return nConnectType; }
	CString			GetUser() const { return strUser; }
	CString			GetPassword() const { return strPass; }
	CString			GetDescription() const { return strDesc; }
	CString			GetFirmwareVersion() const { return strFirmwareVer; }
	// Gets channel information for ip device. (Zero-Base)
	UINT			GetChannel() const { return nChannel; };

	CString			GetOnvifServiceUri() const { return Onvif.strServiceUri; }
	CString			GetOnvifPtzUri() const { return Onvif.strPtzUri; }
	CString			GetOnvifPtzToken() const { return Onvif.strPtzToken; }

	void			SetNeedUpdate() { if(bCanBeUpdated) _bIsUpdated = TRUE; }
	void			SetKeyID(const UINT Key) { nKeyID = Key; }
	void			SetDeviceType(NC_DEVICE_TYPE Type) { DeviceType = Type; }
	void			SetMAC(const CString& MAC)
	{
		if(strMAC == MAC) return;
		strMAC = MAC;
		SetNeedUpdate();
	}
	void			SetProfileName(const CString& ProfileName)
	{
		if(strProfileName == ProfileName) return;
		strProfileName = ProfileName;
		SetNeedUpdate();
	}
	void			SetModelType(const CString& ModelType) { strModelType = ModelType; }
	void			SetModel(const CString& Model) { strModel = Model; }
	void			SetID(const CString& ID) { strID = ID; }
	void			SetName(const CString& Name) { strName = Name; }
	void			SetAddress(const CString& Address)
	{
		if(strAddress == Address) return;
		strAddress = Address;
		SetNeedUpdate();
	}
	void			SetURL(const CString& URL) {
		if(strURL == URL) return;
		strURL = URL;
		SetNeedUpdate();
	}
	void			SetRTSPPort(const UINT Port) {
		if(nRTSPPort == Port) return;
		nRTSPPort = Port;
		SetNeedUpdate();
	}
	void			SetHTTPPort(const UINT Port) {
		if(nHTTPPort == Port) return;
		nHTTPPort = Port;
		SetNeedUpdate();
	}
	void			SetHTTPSPort(const UINT Port) {
		if(nHTTPSPort == Port) return;
		nHTTPSPort = Port;
		SetNeedUpdate();
	}
	void			SetSSL(const BOOL SSL) {
		if(bSSL == SSL) return;
		bSSL = SSL;
		SetNeedUpdate();
	}
	void			SetConnectionType(const UINT ConnectionType) {
		if(nConnectType == ConnectionType) return;
		nConnectType = ConnectionType;
		SetNeedUpdate();
	}
	void			SetUser(const CString& User) {
		if(strUser == User) return;
		strUser = User;
		SetNeedUpdate();
	}
	void			SetPassword(const CString& Password) {
		if(strPass == Password) return;
		strPass = Password;
		SetNeedUpdate();
	}
	void			SetDescription(const CString& Description) { strDesc = Description; }
	void			SetFirmwareVersion(const CString& FirmwareVer) { strFirmwareVer = FirmwareVer; }
	void			SetGroup(struct _GROUP_INFO* _pGroup) { pGroup = _pGroup; }
	void			SetChannel(int nCh) { nChannel = nCh; };

	void			SetOnvifServiceUri(const CString& ServiceUri)
	{
		if(Onvif.strServiceUri == ServiceUri) return;
		Onvif.strServiceUri = ServiceUri;
		SetNeedUpdate();
	}
	void			SetOnvifPtzUri(const CString& Uri)
	{
		if(Onvif.strPtzUri == Uri) return;
		Onvif.strPtzUri = Uri;
		SetNeedUpdate();
	}
	void			SetOnvifPtzToken(const CString& Token)
	{
		if(Onvif.strPtzToken == Token) return;
		Onvif.strPtzToken = Token;
		SetNeedUpdate();
	}

	struct _GROUP_INFO* GetGroup() { return pGroup; }

	void			SetNRSId(UINT Id) { _NRS_Id = Id; }
	UINT			GetNRSId() const { return _NRS_Id; }
	BOOL			IsNeedUpdate() const { return _bIsUpdated; }

	void			SetMessageText(LPCTSTR lpszMessage) { strMessageText = lpszMessage; };
	CString			GetMessageText() const { return strMessageText; };

	void			SetRec_Year(int nYear);
	void			SetRec_idxMonth(BYTE* pIndex, size_t nSize);
	void			SetRec_idxDay(BYTE* pIndex, size_t nSize);
	void			SetRec_idxHour(BYTE* pIndex, size_t nSize);
	void			SetRec_idxMin(BYTE* pIndex, size_t nSize);
	void			SetRec_idxDupMin(BYTE* pIndex, size_t nSize);

	int				GetRec_Year() const { return iRec_Year; }
	CBitArray		GetRec_idxMonth() const;
	CBitArray		GetRec_idxDay() const;
	CBitArray		GetRec_idxHour() const;
	CBitArray		GetRec_idxMin() const;
	CBitArray		GetRec_idxDupMin() const;

	void			SetDeviceStatus(XTREE_CAMERA_STATUS Status) { DeviceStatus = Status; }
	XTREE_CAMERA_STATUS	GetDeviceStatus() const { return DeviceStatus; }

	void			SetStreamStatus(DWORD dwStatus);
	DWORD			GetStreamStauts() const;

	void			SetRecordStatus(BOOL bOn) { bRecordOn = bOn; }
	BOOL			GetRecordStatus() const { return bRecordOn; }

	RECORD_INFO		GetRecordInfo() const;
	CString			GetRecordID() const;
	int				GetPreRecordTime() const;
	int				GetPostRecordTime() const;
	BOOL			IsRecordOverwrite() const;
	BOOL			IsRecordAudio() const;

	void			SetRecordInfo(RECORD_INFO& info);
	void			SetReocrdID(LPCTSTR lpRecordID);
	void			SetPreRecordTime(int nTime);
	void			SetPostRecordTime(int nTime);
	void			SetEnableRecordOverwrite(BOOL bEnable);
	void			SetEnableRecordAudio(BOOL bEnable);

	void			SetScheduleID(int day, int time, LPCTSTR id);
	void			SetScheduleEvent(int day, int time, BYTE event);
	void			SetScheduleRecordAudio(int day, int time, BOOL bRecord);
	void			SetScheduleName(int day, int time, LPCTSTR name);
	void			SetScheduleReset(int day, int time);

	LPCTSTR			GetScheduleID(int day, int time);
	BOOL			IsScheduleRecordAudio(int day, int time);
	BYTE			GetScheduleEvent(int day, int time);
	LPCTSTR			GetScheduleName(int day, int time);

	void			SetSpRecordInfo(RECORD_SPECIAL_INFO& info);
	void			SetEnableSpRecord(BOOL bEnable);
	void			SetSpPreRecordTime(int nTime);
	void			SetSpPostRecordTime(int nTime);
	void			GetSpRecordDayMap(std::map<std::wstring, RECORD_SPECIAL_DAY>& spDay);
	void			AddSpRecordDay(const std::wstring& name, RECORD_SPECIAL_DAY spDay);
	void			RemoveSpRecordDay(const std::wstring& name);

	RECORD_SPECIAL_INFO	GetSpRecordInfo() const;
	BOOL				IsSpRecord() const;
	int					GetSpPreRecordTime() const;
	int					GetSpPostRecordTime() const;
	BOOL				GetSpRecordDay(const std::wstring& name, RECORD_SPECIAL_DAY& spDay);
	RECORD_SPECIAL_DAY*	GetSpRecordDay(const std::wstring& name);

	void			SetSupportPtz(BOOL bSupport);
	BOOL			IsSupportPtz() const;
	BOOL			IsSupportMPtz();
	BOOL			IsSupportRS485();

	void			UpdateStream();
	time_t			GetLastUpdateStream() const;
	void			SetErrorConnect(BOOL bError);
	BOOL			IsErrorConnect() const;
	void			SetNoDevice(BOOL bNoDevice);
	BOOL			IsNoDevice() const;

	void			SetCustomerModel(const CString& CustomerModel);
	CString			GetCUstomerModel() const;

	void			SetVideoFilter(UINT nFIlter);
	UINT			GetVideoFilter() const;

	void			SetOptBuiltinPTZ(BOOL bValue);
	BOOL			GetOptBuiltinPTZ() const;
	void			SetOptPTZ(BOOL bValue);
	BOOL			GetOptPTZ() const;
	void			SetOptMPTZ(BOOL bValue);
	BOOL			GetOptMPTZ() const;
	void			SetOptSmartFocus(BOOL bValue);
	BOOL			GetOptSmartFocus() const;

	void			Reset();	// ���� �ʱ�ȭ
	BOOL			isDependOnNrs()
	{
		return ((DeviceType == NC_DEVICE_HITRON_CAMERA) || (DeviceType == NC_DEVICE_ONVIF_CAMERA));
	};

protected:

	NC_DEVICE_TYPE	DeviceType;
	int				nKeyID;			// ID, 32ä���� ��� 0~31, 64ä�� �ΰ�� 0~63
	CString			strMAC;			// MAC Address
	CString			strProfileName;	// ProfileName (ONVIF Profile, Hitron���� /1/stream1 �� �������� ���� )
	CString			strModelType;	// EModel, HModel, SModel, ONVIF, Unknown
	CString			strModel;		// ���̸�
	CString			strCustomerModel;	// ���̾� ���̸�
	CString			strID;			// guid ���
	CString			strName;		// �̸�
	CString			strAddress;		// IP Addres
	CString			strURL;			// RTSP ��ü URL
	UINT			nRTSPPort;		// RTSP Port
	UINT			nHTTPPort;		// HTTP Port
	UINT			nHTTPSPort;		// HTTPS Port
	BOOL			bSSL;			// SSL ���
	UINT			nConnectType;	//1. RTP over UDP	//2. RTP over RTSP (TCP)	//3. RTP over RTSP over HTTP (TCP)	//4. RTP Multicast
	CString			strUser;		// Login ID
	CString			strPass;		// Login Password
	CString			strDesc;		// ŰŸ����
	CString			strFirmwareVer;	// ���� ���Ŀ� ������ ���� ����
	ONVIF_INFO		Onvif;			// ONVIF ��ġ ����
	UINT			nChannel;		// DVR/NVR ���� ��ġ�� ä�ο� ���� ����

	_GROUP_INFO		*pGroup;

	UINT			_NRS_Id;		// Recording ������ �ĺ��� (���� ����1���� 0���� Default ���̴�.)
	BOOL			_bIsUpdated;

	// Joseph
	// 2011.02.25
	CString			strMessageText;		// Display�� Message 

	// RECORD ��������
	int				iRec_Year;
	CBitArray		idxMonth;
	CBitArray		idxDay;
	CBitArray		idxHour;
	CBitArray		idxMinute;
	CBitArray		idxDupMin;

	XTREE_CAMERA_STATUS	DeviceStatus;	// ī�޶� Status
	DWORD			dwStreamStatus;

	BOOL			bRecordOn;

	RECORD_INFO			RecordInfo;			// ������ ��������
	RECORD_SPECIAL_INFO	SpecialRecordInfo;	// ����ȵ��� ��������

	BOOL			bSupportPtz;

	// Hitron ����options�׸� ����
	// BUILTIN_PTZ (PTZ��Ʈ�� -> /ptz/control.php ���)
	// PTZ (PTZ��Ʈ�� -> /ptz/control.php ���)
	// BUILTIN_PTZ + PTZ (PTZ��Ʈ�� -> /ptz/control.php ���)
	// M_PTZ (PTZ��Ʈ�� -> /mptz/control.php)
	// M_PTZ + PTZ (PTZ��Ʈ�� -> /mptz/control.php, RS485��Ʈ�� -> /ptz/control.php )
	BOOL			opt_builtin_ptz;
	BOOL			opt_ptz;
	BOOL			opt_m_ptz;

	// Hitron Device Only
	BOOL			opt_smart_focus;

	time_t			tLastUpdateStream;		// ���������� ��Ʈ���� �޴� �ð�
	BOOL			bErrorConnect;			// ������ ���� ���� �Ǿ��°�
	BOOL			bIsNoDevice;			// ������ ��ϵ��� ���� ��ġ�ΰ�

	// 2011.11.15	Deinterlaced Filter�� ���� : ��ġ��������!!
	UINT			nVideoFilter;

public:
	DEVICE_EVENT_INFO	EventInfo;

	BOOL			bCanBeUpdated;
	int				nSeq;					// Sort ID

};

typedef DEVICE_INFO*		LPDEVICE_INFO;
