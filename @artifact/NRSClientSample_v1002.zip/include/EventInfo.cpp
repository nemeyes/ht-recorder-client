#include "stdafx.h"
#include "EventInfo.h"

void ON_EVENT_INFO::SetEnable(BOOL bEnable)
{
	this->bEnable = bEnable;
}

BOOL ON_EVENT_INFO::IsEnabled() const
{
	return bEnable;
}

void ON_EVENT_INFO::SetOldEnalbe(BOOL bEnable)
{
	bOldEnable = bEnable;
}

BOOL ON_EVENT_INFO::IsChanged()
{
	// ����� bEnable���� bOldEnable���� ����.

	return (bEnable != bOldEnable);
}

BOOL ON_EVENT_INFO::IsEnabledRecord()
{
	return (nRecordDwellTime != -1);
}

BOOL ON_EVENT_INFO::IsEnabledPreset()
{
	return (nPtzPreset != -1);
}

BOOL ON_EVENT_INFO::IsEnabledTrigger()
{
	return (nManualTrigger != -1);
}

void ON_EVENT_INFO::SetRecordTime(int nDwellTime)
{
	nRecordDwellTime = nDwellTime;
}

int ON_EVENT_INFO::GetRecordTime() const
{
	return nRecordDwellTime;
}

void ON_EVENT_INFO::SetPreset(int nPreset)
{
	nPtzPreset = nPreset;
}

int ON_EVENT_INFO::GetPreset() const
{
	return nPtzPreset;
}

void ON_EVENT_INFO::SetTrigger(int nTrigger)
{
	nManualTrigger = nTrigger;
}

int ON_EVENT_INFO::GetTrigger() const
{
	return nManualTrigger;
}
