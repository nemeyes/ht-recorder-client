#include "stdafx.h"
#include "DeviceInfo.h"

// Channel Sequence�� �� �� �ִ� ��ġ�ΰ�?
BOOL IsSequenceDevice(NC_DEVICE_TYPE DeviceType)
{
	if(DeviceType == NC_DEVICE_HITRON_CAMERA ||
		DeviceType == NC_DEVICE_ONVIF_CAMERA ||
		DeviceType == NC_DEVICE_HITRON_NVR_CAM)
		return TRUE;

	return FALSE;
}

// Nautilus Server�� ��ϵ� ī�޶��ΰ�?
BOOL IsCameraDevice(NC_DEVICE_TYPE DeviceType)
{
	if(DeviceType == NC_DEVICE_HITRON_CAMERA ||
		DeviceType == NC_DEVICE_ONVIF_CAMERA)
		return TRUE;

	return FALSE;
}

// Hitron NVR��ġ�ΰ�?
BOOL IsNVRDevice(NC_DEVICE_TYPE DeviceType)
{
	if(DeviceType == NC_DEVICE_HITRON_NVR)
		return TRUE;

	return FALSE;
}

// Hitron NVR�� ��ϵ� ��ġ�ΰ�?
BOOL IsNVRCamera(NC_DEVICE_TYPE DeviceType)
{
	if(DeviceType == NC_DEVICE_HITRON_NVR_CAM)
		return TRUE;

	return FALSE;
}

// ��ġ�� ���еǴ� �͵�
BOOL IsDevice(NC_DEVICE_TYPE DeviceType)
{
	// ó���� ������ �õ��ؾ� �ϴ� ��ġ
	// ���� Permitoin�� ū �׷����� ��ϵǴ� ��ġ

	if(DeviceType == NC_DEVICE_HITRON_CAMERA ||
		DeviceType == NC_DEVICE_ONVIF_CAMERA ||
		DeviceType == NC_DEVICE_HITRON_NVR)
		return TRUE;

	return FALSE;
}

////////////////////////////////////////////////////////////////////////////////
// DEVICE_INFO

DEVICE_INFO::DEVICE_INFO()
: DeviceType (NC_DEVICE_HITRON_CAMERA)
, nKeyID(-1)
, nRTSPPort(554), nHTTPPort(80), nHTTPSPort(443), bSSL(FALSE), nConnectType(3)
, pGroup(NULL)
, _NRS_Id(0)
, _bIsUpdated(FALSE)
, bCanBeUpdated(FALSE)
, idxMonth(12)
, idxDay(31)
, idxHour(24)
, idxMinute(60)
, idxDupMin(60)
, nSeq(0)
, DeviceStatus(ITEM_ENABLED)
, dwStreamStatus(0)
, bRecordOn(FALSE)
, bSupportPtz(FALSE)
, opt_builtin_ptz(FALSE)
, opt_ptz(FALSE)
, opt_m_ptz(FALSE)
, opt_smart_focus(FALSE)
, tLastUpdateStream(0)
, bErrorConnect(FALSE)
, bIsNoDevice(FALSE)
, nVideoFilter(0)
{
}

DEVICE_INFO::~DEVICE_INFO()
{
}

void DEVICE_INFO::SetRec_Year(int nYear)
{
	iRec_Year = nYear;
}

void DEVICE_INFO::SetRec_idxMonth(BYTE* pIndex, size_t nSize)
{
	idxMonth.Assign(pIndex, nSize);
}

void DEVICE_INFO::SetRec_idxDay(BYTE* pIndex, size_t nSize)
{
	idxDay.Assign(pIndex, nSize);
}

void DEVICE_INFO::SetRec_idxHour(BYTE* pIndex, size_t nSize)
{
	idxHour.Assign(pIndex, nSize);
}

void DEVICE_INFO::SetRec_idxMin(BYTE* pIndex, size_t nSize)
{
	idxMinute.Assign(pIndex, nSize);
}

void DEVICE_INFO::SetRec_idxDupMin(BYTE* pIndex, size_t nSize)
{
	idxDupMin.Assign(pIndex, nSize);
}

CBitArray DEVICE_INFO::GetRec_idxMonth() const
{
	return idxMonth;
}

CBitArray DEVICE_INFO::GetRec_idxDay() const
{
	return idxDay;
}

CBitArray DEVICE_INFO::GetRec_idxHour() const
{
	return idxHour;
}

CBitArray DEVICE_INFO::GetRec_idxMin() const
{
	return idxMinute;
}

CBitArray DEVICE_INFO::GetRec_idxDupMin() const
{
	return idxDupMin;
}

void DEVICE_INFO::SetStreamStatus(DWORD dwStatus)
{
	dwStreamStatus = dwStatus;
}

DWORD DEVICE_INFO::GetStreamStauts() const
{
	return dwStreamStatus;
}

RECORD_INFO DEVICE_INFO::GetRecordInfo() const
{
	return RecordInfo;
}

CString DEVICE_INFO::GetRecordID() const
{
	return RecordInfo.strRecordID;
}

int DEVICE_INFO::GetPreRecordTime() const
{
	return RecordInfo.nPreEventTime;
}

int DEVICE_INFO::GetPostRecordTime() const
{
	return RecordInfo.nPostEventTime;
}

BOOL DEVICE_INFO::IsRecordOverwrite() const
{
	return RecordInfo.bEnableOverwrite;
}

BOOL DEVICE_INFO::IsRecordAudio() const
{
	return RecordInfo.bRecordAudio;
}

void DEVICE_INFO::SetRecordInfo(RECORD_INFO& info)
{
	RecordInfo = info;
	SetNeedUpdate();
}

void DEVICE_INFO::SetReocrdID(LPCTSTR lpRecordID)
{
	RecordInfo.strRecordID = lpRecordID;
	SetNeedUpdate();
}

void DEVICE_INFO::SetPreRecordTime(int nTime)
{
	RecordInfo.nPreEventTime = nTime;
	SetNeedUpdate();
}

void DEVICE_INFO::SetPostRecordTime(int nTime)
{
	if(nTime < 10)
		nTime = 10;

	RecordInfo.nPostEventTime = nTime;
	SetNeedUpdate();
}

void DEVICE_INFO::SetEnableRecordOverwrite(BOOL bEnable)
{
	RecordInfo.bEnableOverwrite = bEnable;
	SetNeedUpdate();
}

void DEVICE_INFO::SetEnableRecordAudio(BOOL bEnable)
{
	RecordInfo.bRecordAudio = bEnable;
	SetNeedUpdate();
}

void DEVICE_INFO::SetScheduleID(int day, int time, LPCTSTR id)
{
	if(id)
	{
		RecordInfo.schedule[day][time].id = id;
		SetNeedUpdate();
	}
}

void DEVICE_INFO::SetScheduleEvent(int day, int time, BYTE event)
{
	RecordInfo.schedule[day][time].event = event;
	SetNeedUpdate();
}

void DEVICE_INFO::SetScheduleRecordAudio(int day, int time, BOOL bRecord)
{
	RecordInfo.schedule[day][time].record_audio = bRecord;
	SetNeedUpdate();
}

void DEVICE_INFO::SetScheduleName(int day, int time, LPCTSTR name)
{
	_tcscpy_s(RecordInfo.schedule[day][time].name, SIZEOF_ARRAY(RecordInfo.schedule[day][time].name), name);
	SetNeedUpdate();
}

void DEVICE_INFO::SetScheduleReset(int day, int time)
{
	RecordInfo.schedule[day][time]._INIT();
	SetNeedUpdate();
}

LPCTSTR DEVICE_INFO::GetScheduleID(int day, int time)
{
	return RecordInfo.schedule[day][time].id.c_str();
}

BOOL DEVICE_INFO::IsScheduleRecordAudio(int day, int time)
{
	return RecordInfo.schedule[day][time].record_audio;
}

BYTE DEVICE_INFO::GetScheduleEvent(int day, int time)
{
	return RecordInfo.schedule[day][time].event;
}

LPCTSTR DEVICE_INFO::GetScheduleName(int day, int time)
{
	return RecordInfo.schedule[day][time].name;
}

void DEVICE_INFO::SetSpRecordInfo(RECORD_SPECIAL_INFO& info)
{
	SpecialRecordInfo = info;
	SetNeedUpdate();
}

void DEVICE_INFO::SetEnableSpRecord(BOOL bEnable)
{
	SpecialRecordInfo.bEnable = bEnable;
	SetNeedUpdate();
}

void DEVICE_INFO::SetSpPreRecordTime(int nTime)
{
	SpecialRecordInfo.nPreEvent = nTime;
	SetNeedUpdate();
}

void DEVICE_INFO::SetSpPostRecordTime(int nTime)
{
	SpecialRecordInfo.nPostEvent = nTime;
	SetNeedUpdate();
}

void DEVICE_INFO::AddSpRecordDay(const std::wstring& name, RECORD_SPECIAL_DAY spDay)
{
	SpecialRecordInfo.SpecialDayMap[name] = spDay;
	SetNeedUpdate();
}

void DEVICE_INFO::RemoveSpRecordDay(const std::wstring& name)
{
	SpecialRecordInfo.SpecialDayMap.erase(name);
	SetNeedUpdate();
}

RECORD_SPECIAL_INFO DEVICE_INFO::GetSpRecordInfo() const
{
	return SpecialRecordInfo;
}

BOOL DEVICE_INFO::IsSpRecord() const
{
	return SpecialRecordInfo.bEnable;
}

int DEVICE_INFO::GetSpPreRecordTime() const
{
	return SpecialRecordInfo.nPreEvent;
}

int DEVICE_INFO::GetSpPostRecordTime() const
{
	return SpecialRecordInfo.nPostEvent;
}

BOOL DEVICE_INFO::GetSpRecordDay(const std::wstring& name, RECORD_SPECIAL_DAY& spDay)
{
	std::map<std::wstring, RECORD_SPECIAL_DAY>::iterator pos;
	pos = SpecialRecordInfo.SpecialDayMap.find( name );
	if(pos == SpecialRecordInfo.SpecialDayMap.end())
		return FALSE;

	spDay = pos->second;

	return TRUE;
}

RECORD_SPECIAL_DAY* DEVICE_INFO::GetSpRecordDay(const std::wstring& name)
{
	std::map<std::wstring, RECORD_SPECIAL_DAY>::iterator pos;
	pos = SpecialRecordInfo.SpecialDayMap.find( name );
	if(pos == SpecialRecordInfo.SpecialDayMap.end())
		return NULL;

	return &pos->second;
}

void DEVICE_INFO::GetSpRecordDayMap(std::map<std::wstring, RECORD_SPECIAL_DAY>& spDay)
{
	spDay = SpecialRecordInfo.SpecialDayMap;
}

void DEVICE_INFO::SetSupportPtz(BOOL bSupport)
{
	bSupportPtz = bSupport;
}

BOOL DEVICE_INFO::IsSupportPtz() const
{
	return bSupportPtz;
}

BOOL DEVICE_INFO::IsSupportMPtz()
{
	return opt_m_ptz;
}

BOOL DEVICE_INFO::IsSupportRS485()
{
	return (!opt_builtin_ptz && opt_m_ptz && opt_ptz);
}

void DEVICE_INFO::SetOptBuiltinPTZ(BOOL bValue)
{
	opt_builtin_ptz = bValue;
}

BOOL DEVICE_INFO::GetOptBuiltinPTZ() const
{
	return opt_builtin_ptz;
}

void DEVICE_INFO::SetOptPTZ(BOOL bValue)
{
	opt_ptz = bValue;
}

BOOL DEVICE_INFO::GetOptPTZ() const
{
	return opt_ptz;
}

void DEVICE_INFO::SetOptMPTZ(BOOL bValue)
{
	opt_m_ptz = bValue;
}

BOOL DEVICE_INFO::GetOptMPTZ() const
{
	return opt_m_ptz;
}

void DEVICE_INFO::UpdateStream()
{
	tLastUpdateStream = time(NULL);
}

time_t DEVICE_INFO::GetLastUpdateStream() const
{
	return tLastUpdateStream;
}

void DEVICE_INFO::SetErrorConnect(BOOL bError)
{
	bErrorConnect = bError;
}

BOOL DEVICE_INFO::IsErrorConnect() const
{
	return bErrorConnect;
}

void DEVICE_INFO::SetNoDevice(BOOL bNoDevice)
{
	bIsNoDevice = bNoDevice;
}

BOOL DEVICE_INFO::IsNoDevice() const
{
	return bIsNoDevice;
}

void DEVICE_INFO::SetCustomerModel(const CString& CustomerModel)
{
	strCustomerModel = CustomerModel;
}

CString DEVICE_INFO::GetCUstomerModel() const
{
	return strCustomerModel;
}

void DEVICE_INFO::SetVideoFilter(UINT nFIlter)
{
	nVideoFilter = nFIlter;
}

UINT DEVICE_INFO::GetVideoFilter() const
{
	return nVideoFilter;
}

void DEVICE_INFO::Reset()
{
	// 2011.12.20 PTZ ���� ������ �ʱ�ȭ
	// TODO:: ���߿� ���� �ʱ�ȭ�ص� �Ǵ��� Ȯ���� ����!!!
	bSupportPtz			= FALSE;
	opt_builtin_ptz		= FALSE;
	opt_ptz				= FALSE;
	opt_m_ptz			= FALSE;
}

void DEVICE_INFO::SetOptSmartFocus(BOOL bValue)
{
	opt_smart_focus = bValue;
}

BOOL DEVICE_INFO::GetOptSmartFocus() const
{
	return opt_smart_focus;
}

