#pragma once
#include <map>
#include "DeviceInfo.h"
//#include "LayoutInfo.h"

// User ����
enum NC_USER_LEVEL
{
	USER_ADMINISTRATOR	= 0,
	USER_NORMAL,
	USER_GUEST,
};

// ���� ����
#define USER_PERMITION_LIVE		0x00000001
#define USER_PERMITION_PLAYBACK	0x00000002
#define USER_PERMITION_PTZ		0x00000004
#define USER_PERMITION_SETUP	0x00000008

typedef struct _NC_USER_INFO
{
	_NC_USER_INFO()
		: nSeq(0), Level(USER_NORMAL)
		, Permition(USER_PERMITION_LIVE | USER_PERMITION_PLAYBACK | USER_PERMITION_PTZ | USER_PERMITION_SETUP)
		, bUseAll(TRUE)
	{
	}

	size_t		nSeq;
	CString		strUserID;
	CString		strUserPass;
	CString			strUserOldPass;
	NC_USER_LEVEL	Level;
	ULONG			Permition;		// ���� �۹̼� ��Ʈ�÷��� ����
	BOOL			bUseAll;		// ��� ��ġ,���̾ƿ�,�������� ����� �� �ִ�.

	std::map<std::wstring, std::tr1::shared_ptr<DEVICE_INFO>> m_mapAuthDevices;
	//std::map<std::wstring, LPLAYOUT_INFO> m_mapAuthLayout;
	//std::map<std::wstring, LPLAYOUT_SEQ_GROUP> m_mapAuthLayoutSeq;
	//std::map<std::wstring, LPCHANNEL_SEQ_GROUP> m_mapAuthChannelSeq;

} NC_USER_INFO, *LPNC_USER_INFO;
