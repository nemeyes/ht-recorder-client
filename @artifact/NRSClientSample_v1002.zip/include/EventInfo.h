#pragma once

// On Event Ÿ��
#define ONEVENT_ON_MOTION		0x00000001
#define ONEVENT_ON_ALARM1		0x00000002
#define ONEVENT_ON_ALARM2		0x00000004
#define ONEVENT_ON_BOOT			0x00000008
#define ONEVENT_ON_VIDEOLOSS	0x00000010

enum ONEVENT_ID {
	ONEVENT_ID_ON_MOTION	= 0,
	ONEVENT_ID_ON_ALARM1,
	ONEVENT_ID_ON_ALARM2,
	ONEVENT_ID_BOOT,
	ONEVENT_ID_VIDEOLOSS,
	ONEVENT_ID_MAX,
};

enum ONSYSTEMEVENT_ID {
	// Recording service
	ONSYSTEM_ID_DISK_FULL = 0,
	ONSYSTEM_ID_DISK_FAULT,
	// Monitoring service
	ONSYSTEM_ID_UPDATE,
	ONSYSTEM_ID_MAX,
};

typedef struct _ONEVENT_FIELD_T
{
	ONEVENT_ID	Id;
	TCHAR		name[16];
	UINT		Type;

} ONEVENT_FIELD_T;

typedef struct _ON_EVENT_INFO
{
	_ON_EVENT_INFO()
		: bEnable(FALSE), bOldEnable(FALSE), nEventType(0), nRecordDwellTime(-1), nPtzPreset(-1), nManualTrigger(-1)
	{
	}

	typedef struct _view_channel_t {
		_view_channel_t() : nDwellTime(0), nLiveWindow(0) {}
		int		nLiveWindow;
		int		nDwellTime;	// 0: Disabled, 1: Infinite
	} view_channel_t;

	typedef struct _view_layout_t {
		_view_layout_t() : nDwellTime(0) {}
		int		nDwellTime;	// 0: Disabled, 1: Infinite
		CString	strLayoutID;
	} view_layout_t;

	typedef struct _sound_t {
		_sound_t() : bEnable(FALSE) {}
		BOOL	bEnable;
		CString	strFileName;
	} sound_t;

	UINT			nEventType;
	view_channel_t	view_channel;
	view_layout_t	view_layout;
	sound_t			sound;
	CString			RelayoutID;
	//std::set<std::wstring> RelaySet;

	CString			strExeAppName;

	void			SetEnable(BOOL bEnable);
	BOOL			IsEnabled() const;
	void			SetOldEnalbe(BOOL bEnable);
	BOOL			IsChanged();				// ����� bEnable���� bOldEnable���� ����.

	BOOL			IsEnabledRecord();
	BOOL			IsEnabledPreset();
	BOOL			IsEnabledTrigger();
	void			SetRecordTime(int nDwellTime);
	int				GetRecordTime() const;
	void			SetPreset(int nPreset);
	int				GetPreset() const;
	void			SetTrigger(int nTrigger);
	int				GetTrigger() const;

protected:
	BOOL			bEnable;
	BOOL			bOldEnable;					// ������ ����Ǿ����� Ȯ���ϱ� ����

	int				nRecordDwellTime;	// -1 : disabled
	int				nPtzPreset;			// -1 : disabled
	int				nManualTrigger;		// -1 : disabled

} ON_EVENT_INFO;

typedef struct _DEVICE_EVENT_INFO
{
	ON_EVENT_INFO	Event[ONEVENT_ID_MAX];

} DEVICE_EVENT_INFO;
