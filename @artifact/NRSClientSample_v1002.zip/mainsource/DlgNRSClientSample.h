#pragma once
// DlgNRSClientSample.h : ��� ����
//
#include "DlgDeviceRegister.h"
#include "NRSManageII.h"
#include <dx3d9_util/dx3d_gui.h>
#include <dx3d9_util/dx3d_gui_button.h>
#include "ColorListBox.h"
#include "resource.h"
#include "DlgPlaybackView.h"


// CDlgNRSClientSample ��ȭ ����

typedef struct{
	float fX;	
	float fY;
	float fZ;
	float fRHW;	
	D3DCOLOR Color;	
	float fU;	
	float fV;
}D3DTLVERTEX;

class CDeviceStatus 
{
	CDeviceStatus()
	{
		m_strStreamID	= _T("");
		m_strNRSError = _T("");
		m_strBitrate = _T("");
		m_strFPS = _T("");
		m_strVCodec= _T("");
		m_strACodec = _T("");
		m_strIsVRec = _T("");
		m_strIsARec = _T("");
		m_strIsConnected = _T("");
		m_strResolW = _T("");
		m_strResolH = _T("");
	}
	virtual ~CDeviceStatus();

	CString m_strNRSError;
	CString m_strStreamID;
	CString m_strBitrate;
	CString m_strFPS;
	CString m_strVCodec;
	CString m_strACodec;
	CString m_strIsVRec;
	CString m_strIsARec;
	CString m_strIsConnected;
	CString m_strResolW;
	CString m_strResolH;
};

class CDlgNRSClientSample : public CDialog
{
// �����Դϴ�.
public:
	CDlgNRSClientSample(CWnd* pParent = NULL);	// ǥ�� �������Դϴ�.

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_MAIN_DIALOG };

	CDlgDeviceRegister *m_pDlgDevRegister;
	CDisplayLib *m_pLive1Disp;
	NRS::CNRSManage *m_pNRSManager;

	DX3DUTIL::CDX3DResourceManager m_dx3dResource;
	LPD3DXLINE			m_pd3dLine;

	CRITICAL_SECTION	m_cs;

	BOOL m_bClose;
	BOOL m_bStop;
	HANDLE m_hEvent;
	HANDLE m_hStatusThread;

	CColorListBox m_listLog;
	CEdit m_edStatus;

	void SetSelectionIndex(int nCh);	
protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV �����Դϴ�.

	CEdit	m_edNrsIP;
	CEdit m_edID;
	CEdit m_edPW;
	CButton m_btnDevRegister;

	static UINT WINAPI ShellCheckStatus(LPVOID pParam);
	UINT CheckStatus();
	UINT DoCheckStatus();

	/////////////////////////////////////////////////////////////////////////////////////////////////
	// DIrectX3D ����
	virtual void	OnDxDeviceCreated(LPDIRECT3DDEVICE9 pd3dDevice, LPD3DXSPRITE pd3dSprite, const D3DSURFACE_DESC* pBackBufferSurfaceDesc);
	virtual void	OnDxDeviceDestroyed();
	virtual void	OnDxDeviceLost();
	virtual void	OnDxDeviceReset(LPDIRECT3DDEVICE9 pd3dDevice,  LPD3DXSPRITE pd3dSprite, const D3DSURFACE_DESC* pBackBufferSurfaceDesc);
	virtual void	OnDxCustomDraw(DISP_DX3D9* pDisp);
	virtual void	OnDxPannelEvent(UINT nID, UINT nEvent, DX3DUTIL::CDX3DBaseControl* pControl);
	virtual BOOL	OnDxDispMsgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

	/////////////////////////////////////////////////////////////////////////////////////////////////
	// DIrectX3D �ݹ��Լ�
	static HRESULT WINAPI OnD3DDeviceCreated(LPDIRECT3DDEVICE9 pd3dDevice, LPD3DXSPRITE pd3dSprite, const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext);
	static HRESULT WINAPI OnD3DDeviceDestroyed(void *pUserContext);
	static void WINAPI OnD3DDeviceLost(void *pUserContext);
	static void WINAPI OnD3DDeviceReset(LPDIRECT3DDEVICE9 pd3dDevice,  LPD3DXSPRITE pd3dSprite, const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext);
	static void WINAPI OnD3D9CustomDraw(DISP_DX3D9* pDisp);
	static void WINAPI OnD3DPannelEvent(UINT nID, UINT nEvent, DX3DUTIL::CDX3DBaseControl* pControl, void* pUserContext);
	static BOOL WINAPI OnDispMsgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, void* pUserContext);

	void DrawCircle(CPoint pt, float fRadius, D3DCOLOR color, LPDIRECT3DDEVICE9 lp3dDevice);
	D3DTLVERTEX CreateD3DTLVERTEX (float X, float Y, float Z, float RHW, D3DCOLOR color, float U, float V);

	void	Lock();
	void	Unlock();

protected:
	HICON m_hIcon;

	// ������ �޽��� �� �Լ�
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnDestroy();
	afx_msg void OnBnClickedButtonNrsConnect();
	afx_msg void OnBnClickedButtonCameraRegister();
	afx_msg void OnBnClickedBtnPlaybackView();
};
