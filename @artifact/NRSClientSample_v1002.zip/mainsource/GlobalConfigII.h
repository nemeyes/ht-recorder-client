#pragma once

#pragma comment(lib, "Rpcrt4.lib")
#include <d3d9types.h>
#include "../Include/DeviceInfo.h"

#define RECORD_TIME		0x01					// ���� ���ڵ�
#define RECORD_EVENT	0x02					// �̺�Ʈ ���ڵ�


namespace NRS {
	class CNRSBase;
};

typedef struct _NRS_SERVER_INFO
{
	_NRS_SERVER_INFO()
		: nId(-1), bEnable(FALSE), nPort(DEFAULT_NCSERVICE_PORT)
	{
	}
	UINT		nId;			// 0, 1, 2, 3, ... �������
	CString		strServerId;	// guid
	BOOL		bEnable;
	CString		strName;
	CString		strAddress;
	UINT		nPort;
	CString		strUserId;
	CString		strUserPassword;
	CString		strDesc;

} NRS_SERVER_INFO;

class CGlobalConfig
{

protected:
	GUID *m_pGUID;

public:
	CGlobalConfig(LPCTSTR lpszConfigXml = NULL, NRS::CNRSBase* pRemote = NULL);
	~CGlobalConfig(void);

	std::map<std::wstring, std::tr1::shared_ptr<DEVICE_INFO>> m_mapDevices;

	CStringW	GetGUIDW();
	CStringA	GetGUIDA();
	std::string EncodeMD5(const std::string& str);
	std::wstring EncodeMD5(const std::wstring& str);
	
	BOOL GetDevice(std::tr1::shared_ptr<DEVICE_INFO>& DevicePtr, LPCTSTR lpDeviceID);
	void RemoveDeviceAll();

};