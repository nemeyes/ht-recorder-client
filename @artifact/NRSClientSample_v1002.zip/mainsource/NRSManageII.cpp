#include "StdAfx.h"
#include "NRSManageII.h"
#include "NRSStream.h"
#include "ScopeLock.h"
#include <atlenc.h>
using namespace NRS;

size_t CNRSManage::m_nVideoStreamCount = 0;

NRS::CNRSManage::CNRSManage( size_t nId, LPCTSTR lpServerID )
: CNRSBase(nId)
, m_DeviceType(NC_DEVICE_NAUTILUS)
, m_strServerID(lpServerID)
{
	InitializeCriticalSection(&m_csLive);
	m_hConnWaitEvent = CreateEvent(NULL, TRUE, FALSE, NULL);

	m_pStream = NULL;
}

NRS::CNRSManage::~CNRSManage( void )
{
	if (m_hConnWaitEvent)
	{
		CloseHandle(m_hConnWaitEvent);
		m_hConnWaitEvent = NULL;
	}
}

void NRS::CNRSManage::OnNotifyMessage( LiveNotifyMsg* pNotify )
{
	__super::OnNotifyMessage(pNotify);

	if(pNotify->nMessage == LIVE_CONNECT)
	{
		TRACE(_T("NRS ����: %s:%d, Error: %d\n"), m_strAddress, m_nPort, pNotify->nError);
		if(pNotify->nError == NO_ERROR)
		{
			//Meta ���� ����
			DWORD dwStreamFlags = NRS_RELAY_META;

		}
	}else if(pNotify->nMessage == LIVE_DISCONNECT)
	{
		TRACE(_T("NRS �������� %s:%d, Error: %d\n"), m_strAddress, m_nPort, pNotify->nError);
	}else
		TRACE(_T("CNRSManage::OnNotifyMessage �̻��� �޼���? [%d]\n"), pNotify->nMessage);

}

void NRS::CNRSManage::OnReceive( LPStreamData Data )
{
	return __super::OnReceive(Data);
}

void CNRSManage::Disconnect()
{
	DisconnectStreamAll();
	ClearStreamAll();
	__super::Disconnect();
}

void CNRSManage::SetServerID(LPCTSTR lpServerID)
{
	m_strServerID = lpServerID;
}

CString CNRSManage::GetServerID() const
{
	return m_strServerID;
}

BOOL NRS::CNRSManage::GetServer( std::tr1::shared_ptr<DEVICE_INFO>& DevicePtr )
{
	return GetGlobalConfig().GetDevice(DevicePtr, GetServerID());
}

BOOL CNRSManage::LoadRSDevices()
{
	CStringA SendStr;
	SendStr.Format("%s<GetAllStreamInfoReq req_id=\"%s\" />",
		XML_UTF8_HEAD_STR,
		GetGlobalConfig().GetGUIDA());

	string RecvStr;

	if(SendRecvXML(SendStr, RecvStr) != NO_ERROR)
	{
		TRACE(_T("LoadRSDevices error~~~ \n"));
		return FALSE;
	}

	CXML xml;
	if(!xml.LoadXMLFromString(RecvStr.c_str()))
		return FALSE;

	return DoLoadRSDevices( xml.FindNodeList(_T("//Device")) );	//<-- CheckRSDevices
}

BOOL NRS::CNRSManage::DoLoadRSDevices( MSXML2::IXMLDOMNodeListPtr pList )  //<-- CheckRSDevices
{

	if(pList == NULL)
	{
		// ������ ��ϵ� ��ġ�� �Ѱ��� ���� ���!!!
		if(GetGlobalConfig().m_mapDevices.size() > 0)
		{		
			GetGlobalConfig().RemoveDeviceAll();
			return TRUE;
		}
		return FALSE;
	}

	long count = pList->Getlength();
	for(long i=0; i<count; i++)
	{
		std::tr1::shared_ptr<DEVICE_INFO> pDevice(new DEVICE_INFO);
		
		MSXML2::IXMLDOMNodePtr pNode = pList->Getitem(i);

		CString device_type	= CXML::GetAttributeValue(pNode, L"type");
		CString	stream_id	= CXML::GetChildNodeText(pNode, _T("StreamID"));
		CString mac			= CXML::GetChildNodeText(pNode, _T("MAC"));
		CString profile		= CXML::GetChildNodeText(pNode, _T("Profile"));
		CString model_type	= CXML::GetChildNodeText(pNode, _T("ModelType"));	// HModel, SModel, ONVIF
		CString model		= CXML::GetChildNodeText(pNode, _T("Model"));		// model name
		CString address		= CXML::GetChildNodeText(pNode, _T("Address"));
		CString url			= CXML::GetChildNodeText(pNode, _T("URL"));			// connection uri
		UINT rtsp_port		= _ttoi( CXML::GetChildNodeText(pNode, _T("RTSPPort")) );
		UINT http_port		= _ttoi( CXML::GetChildNodeText(pNode, _T("HTTPPort")) );
		UINT https_port		= _ttoi( CXML::GetChildNodeText(pNode, _T("HTTPSPort")) );
		BOOL ssl			= _ttoi( CXML::GetChildNodeText(pNode, _T("SSL")) );
		UINT conn_type		= _ttoi( CXML::GetChildNodeText(pNode, _T("ConnectType")) );

		MSXML2::IXMLDOMNodePtr pLoginPtr = CXML::GetChildNode(pNode, _T("Login"));
		if(pLoginPtr)
		{
			CString id	= CXML::GetAttributeValue(pLoginPtr, L"id");
			CString pwd	= CXML::GetAttributeValue(pLoginPtr, L"pwd");

			pDevice->SetUser(id);
			pDevice->SetPassword(pwd);
		}

		NC_DEVICE_TYPE DeviceType;
		if(model_type == _T("ONVIF"))
		{
			DeviceType = NC_DEVICE_ONVIF_CAMERA;
			MSXML2::IXMLDOMNodePtr pOnvifPtr = CXML::GetChildNode(pNode, _T("ONVIF"));
			if(pOnvifPtr)
			{
				CString service_uri	= CXML::GetChildNodeText(pOnvifPtr, _T("ServiceUri"));

				MSXML2::IXMLDOMNodePtr pOnvifPtzPtr = CXML::GetChildNode(pOnvifPtr, _T("PTZ"));
				if(pOnvifPtzPtr)
				{
					CString ptz_uri	= CXML::GetChildNodeText(pOnvifPtzPtr, _T("PTZUri"));
					CString token	= CXML::GetChildNodeText(pOnvifPtzPtr, _T("Token"));

					pDevice->SetOnvifPtzUri(ptz_uri);
					pDevice->SetOnvifPtzToken(token);
				}
				pDevice->SetOnvifServiceUri(service_uri);
			}
		}
		else
			DeviceType = NC_DEVICE_HITRON_CAMERA;

		pDevice->SetID( stream_id );
		pDevice->SetDeviceType(DeviceType);
		pDevice->SetMAC(mac);
		pDevice->SetModelType(model_type);
		pDevice->SetModel(model);
		pDevice->SetProfileName(profile);
		pDevice->SetAddress(address);
		pDevice->SetURL(url);
		pDevice->SetRTSPPort(rtsp_port);
		pDevice->SetHTTPPort(http_port);
		pDevice->SetHTTPSPort(https_port);
		pDevice->SetSSL(ssl);
		pDevice->SetConnectionType(conn_type);

		pDevice->SetName( model + mac );

		GetGlobalConfig().m_mapDevices.insert( pair<wstring, std::tr1::shared_ptr<DEVICE_INFO>>( (LPCTSTR)stream_id, pDevice ) );
	}


	return TRUE;
}

BOOL NRS::CNRSManage::ConnectRelayStream( LPCTSTR lpszDeviceID, DWORD dwStreamFlag /*= NRS_RELAY_VIDEO | NRS_RELAY_AUDIO | NRS_RELAY_META*/, 
																std::tr1::shared_ptr<CNRSStream> *pStreamPtrOut /*= NULL*/, std::tr1::shared_ptr<CNRSStream> *pStreamPtrIn /*= NULL*/ )
{
	std::tr1::shared_ptr<DEVICE_INFO> DevicePtr;
	if(!GetGlobalConfig().GetDevice(DevicePtr, lpszDeviceID))
		return FALSE;
	
	if(!IsCameraDevice(DevicePtr->GetDeviceType()))
		return FALSE;
	
	SCOPE_TRY_LOCK_START(&m_csLive);
	std::map<wstring, std::tr1::shared_ptr<CNRSStream>>::iterator pos = m_StreamMap.find(lpszDeviceID);
	if(pos != m_StreamMap.end())
	{
		if(pStreamPtrOut)
			*pStreamPtrOut = pos->second;

		TRACE(_T(">> �̹� ��Ʈ���� ���� %s \n"), lpszDeviceID);
		return FALSE;
	}
	SCOPE_LOCK_END();
	
	CheckStream(dwStreamFlag);

	std::tr1::shared_ptr<CNRSStream> StreamPtr;
	if(pStreamPtrIn)
		StreamPtr = *pStreamPtrIn;
	else
		StreamPtr.reset(new CNRSStream(*this, m_nId, lpszDeviceID, dwStreamFlag));

	CString sXml;
	sXml.Format(_T("<?xml version=\"1.0\" encoding=\"utf-8\"?>") \
		_T("<StartRelayReq req_id=\"%s\">") \
		_T("<ClientID>%d</ClientID>") \
		_T("<StreamID>%s</StreamID>") \
		_T("<Type>%d</Type>") \
		_T("</StartRelayReq>"),

		GetGlobalConfig().GetGUIDW(),
		m_pXml->GetClientId(),
		DevicePtr->GetID(),
		dwStreamFlag
		);

	std::string utf8 = WStringToUTF8(sXml);

	void* stream = Live5_ConnectStream(GetNRSHandle(), m_nId, utf8.c_str(), StreamPtr.get());
	if(stream == NULL)
	{
		DevicePtr->SetStreamStatus(NRS_RELAY_NONE);
		return FALSE;
	}

	DevicePtr->SetStreamStatus(dwStreamFlag);
	StreamPtr->m_bIsConnecting = TRUE;
	StreamPtr->SetHandle(stream);

	SCOPE_TRY_LOCK_START(&m_csLive);
	m_StreamMap[lpszDeviceID] = StreamPtr;
	SCOPE_LOCK_END();

	if(pStreamPtrOut)
		*pStreamPtrOut = StreamPtr;
	
	return TRUE;

}

BOOL NRS::CNRSManage::UpdateRelayStream( LPCTSTR lpszDeviceID, DWORD dwStreamFlag /*= NRS_RELAY_VIDEO | NRS_RELAY_AUDIO | NRS_RELAY_META*/ )
{
	std::tr1::shared_ptr<DEVICE_INFO> DevicePtr;
	if(!GetGlobalConfig().GetDevice(DevicePtr, lpszDeviceID))
		return FALSE;

	std::tr1::shared_ptr<CNRSStream> StreamPtr;

	CheckStream(dwStreamFlag);

	SCOPE_TRY_LOCK_START(&m_csLive);
	std::map<wstring, std::tr1::shared_ptr<CNRSStream>>::iterator pos = m_StreamMap.find(lpszDeviceID);
	if(pos != m_StreamMap.end())
		StreamPtr = pos->second;
	SCOPE_LOCK_END();

	if(!StreamPtr.get())
	{
		DevicePtr->SetStreamStatus(NRS_RELAY_NONE);
		return FALSE;
	}

	CString sXml;
	sXml.Format(_T("<?xml version=\"1.0\" encoding=\"utf-8\"?>") \
		_T("<UpdateRelayReq req_id=\"%s\">") \
		_T("<ClientID>%d</ClientID>") \
		_T("<StreamID>%s</StreamID>") \
		_T("<Type>%d</Type>") \
		_T("</UpdateRelayReq>"),

		GetGlobalConfig().GetGUIDW(),
		m_pXml->GetClientId(),
		DevicePtr->GetID(),
		dwStreamFlag);

	// ����/������� ���� ���·� ���ư��� ���۸� ����� �ʱ�ȭ �ǵ��� ����
	if(dwStreamFlag == NRS_RELAY_META)
		StreamPtr->ClearBuffer(FALSE, TRUE);

	std::string utf8 = WStringToUTF8(sXml);

	if(SendXML(utf8.c_str()) != NO_ERROR)
		return FALSE;

	DevicePtr->SetStreamStatus(dwStreamFlag);

	return TRUE;
}

void NRS::CNRSManage::DisconnectStream( LPCTSTR lpszDeviceID )
{
	std::map<wstring, std::tr1::shared_ptr<CNRSStream>>::iterator pos;
	SCOPE_TRY_LOCK_START(&m_csLive);
	pos = m_StreamMap.find(lpszDeviceID);
	if(pos != m_StreamMap.end())
		pos->second->Disconnect();
	SCOPE_LOCK_END();
}

void NRS::CNRSManage::DisconnectStreamAll()
{
	SCOPE_TRY_LOCK_START(&m_csLive);
	std::map<wstring, std::tr1::shared_ptr<CNRSStream>>::iterator pos = m_StreamMap.begin();
	while(pos != m_StreamMap.end())
	{
		pos->second->Disconnect();
		pos++;
	}
	SCOPE_LOCK_END();

	time_t t1 = time(NULL);
	time_t t2 = t1;

	while(t2 <= t1)
	{
		APP_PUMP_MESSAGE(NULL, 0, 0);
		t2 = time(NULL);
	}

	Sleep(100);
}

BOOL NRS::CNRSManage::SetDisplay( LPCTSTR lpszDeviceID, CDisplayLib* pDisp, size_t nChannel, BOOL bClearDisplay /*= TRUE*/ )
{
	BOOL bResult = FALSE;
	std::map<wstring, std::tr1::shared_ptr<CNRSStream>>::iterator pos;
	SCOPE_TRY_LOCK_START(&m_csLive);
	pos = m_StreamMap.find(lpszDeviceID);
	if(pos != m_StreamMap.end())
	{
		bResult = pos->second->m_Decode.AddCallbackFunction(
			pos->second->m_sDecodeKey.c_str(),
			pDisp,
			nChannel);

		if(bResult && bClearDisplay)
			pDisp->SetPreview(nChannel);
	}
	SCOPE_LOCK_END();

	return bResult;
}

BOOL NRS::CNRSManage::CheckSafeStreamRelease()
{
	std::map<wstring, std::tr1::shared_ptr<CNRSStream>>::iterator pos;
	SCOPE_TRY_LOCK_START(&m_csLive);
	pos = m_StreamMap.begin();
	while(pos != m_StreamMap.end())
	{
		if(pos->second->m_bIsConnecting || pos->second->m_bIsConnected)
		{
			return FALSE;
		}
		pos++;
	}

	SCOPE_LOCK_END();

	return TRUE;
}

void NRS::CNRSManage::CheckStream( DWORD dwFlags )
{
	if((dwFlags & NRS_RELAY_VIDEO) == NRS_RELAY_VIDEO)
		m_nVideoStreamCount++;
	else
	{
		if(m_nVideoStreamCount > 0)
			m_nVideoStreamCount--;
	}

	DWORD dwNumberOfThread = GetThreadPool().GetNumberOfThread() - 1;

	if(m_nVideoStreamCount >= dwNumberOfThread)
	{
		NRS::CNRSStream::SetEnableVideoSync(FALSE);
	}
	else
	{
		NRS::CNRSStream::SetEnableVideoSync(TRUE);
	}

}

std::tr1::shared_ptr<CNRSStream> NRS::CNRSManage::ClearStream( LPCTSTR lpszDeviceID )
{
	std::tr1::shared_ptr<CNRSStream> StreamPtr;
	CString strDeviceId(lpszDeviceID);

	SCOPE_TRY_LOCK_START(&m_csLive);
	std::map<wstring, std::tr1::shared_ptr<CNRSStream>>::iterator pos = m_StreamMap.find(lpszDeviceID);
	if(pos != m_StreamMap.end())
	{
		StreamPtr = pos->second;
		CheckStream(NRS_RELAY_NONE);
		m_StreamMap.erase(pos);
	}
	SCOPE_LOCK_END();

	return StreamPtr;
}

void NRS::CNRSManage::ClearStreamAll()
{
	SCOPE_TRY_LOCK_START(&m_csLive);
	m_StreamMap.clear();
	m_nVideoStreamCount = 0;
	SCOPE_LOCK_END();
}


BOOL NRS::CNRSManage::GetUpdateStreamInfoReq( std::tr1::shared_ptr<DEVICE_INFO> pDevice, std::string& Str )
{
	CString strXML;
	CString strTemp;

	strXML.Format(_T("%s<UpdateStreamInfoReq req_id=\"%s\">"), 
		XML_UTF8_HEAD_WSTR,
		GetGlobalConfig().GetGUIDW()
		);

	int nIdx = pDevice->GetDeviceType();
	CString strDevType;
	switch(nIdx)
	{
	default:
	case NC_DEVICE_UNKNOWN:
		strDevType = _T("Unknown");
		break;

	case NC_DEVICE_HITRON_CAMERA:
		strDevType = _T("HitronCamera");
		break;

	case NC_DEVICE_ONVIF_CAMERA:
		strDevType = _T("OnvifCamera");
		break;
	}

	strTemp.Format(_T("<Device type=\"%s\">") \
		_T("<StreamID>%s</StreamID>") \
		_T("<MAC>%s</MAC>") \
		_T("<Profile>%s</Profile>") \
		_T("<ModelType>%s</ModelType>") \
		_T("<Model>%s</Model>") \
		_T("<Address>%s</Address>") \
		_T("<URL>%s</URL>") \
		_T("<RTSPPort>%d</RTSPPort>") \
		_T("<HTTPPort>%d</HTTPPort>") \
		_T("<HTTPSPort>%d</HTTPSPort>") \
		_T("<SSL>%d</SSL>") \
		_T("<ConnectType>%d</ConnectType>") \
		_T("<Login id=\"%s\" pwd=\"%s\" />"),

		strDevType,
		pDevice->GetID(),
		pDevice->GetMAC(),
		pDevice->GetProfileName(),
		pDevice->GetModelType(),
		CXML::ConvertSymbol( pDevice->GetModel() ),
		CXML::ConvertSymbol( pDevice->GetAddress() ),
		CXML::ConvertSymbol( pDevice->GetURL() ),

		pDevice->GetRTSPPort(),
		pDevice->GetHTTPPort(),
		pDevice->GetHTTPSPort(),
		pDevice->GetSSL(),
		pDevice->GetConnectionType(),
		CXML::ConvertSymbol( pDevice->GetUser() ),
		CXML::ConvertSymbol( pDevice->GetPassword() ));

	strXML += strTemp;

	strTemp.Format(_T("<ONVIF>") \
		_T("<ServiceUri>%s</ServiceUri>") \
		_T("<PTZ><PTZUri>%s</PTZUri><Token>%s</Token></PTZ>") \
		_T("</ONVIF>"),
		CXML::ConvertSymbol(pDevice->GetOnvifServiceUri()),
		CXML::ConvertSymbol(pDevice->GetOnvifPtzUri()),
		CXML::ConvertSymbol(pDevice->GetOnvifPtzToken()));
	strXML += strTemp;

	strXML += _T("</Device>");
	strXML += _T("</UpdateStreamInfoReq>");

	Str = __WTOUTF8( strXML );

	return TRUE;
}

BOOL NRS::CNRSManage::GetDeleteStreamInfoReq( std::tr1::shared_ptr<DEVICE_INFO> pDevice, std::string& Str )
{
	CString strXML;
	CString strTemp;

	strXML.Format(_T("%s<DeleteStreamInfoReq req_id=\"%s\">"),
		XML_UTF8_HEAD_WSTR,
		GetGlobalConfig().GetGUIDW());

	strTemp.Format(_T("<StreamID>%s</StreamID>"), pDevice->GetID());
	
	strXML += strTemp;	
	strXML += _T("</DeleteStreamInfoReq>");

	Str = __WTOUTF8( strXML );

	return TRUE;
}

BOOL NRS::CNRSManage::GetKillStreamReq(std::tr1::shared_ptr<DEVICE_INFO> pDevice, std::string& Str)
{
	CString strXML, strTemp;
	strXML.Format(_T("%s<KillStreamReq req_id=\"%s\">"), 
		XML_UTF8_HEAD_WSTR, 
		GetGlobalConfig().GetGUIDW());

	strTemp.Format(_T("<StreamID>%s</StreamID>"), pDevice->GetID());
	strXML += strTemp;

	strXML += _T("</KillStreamReq>");

	Str = __WTOUTF8( strXML );

	return TRUE;
}

BOOL NRS::CNRSManage::IsKilledStreamReq( std::tr1::shared_ptr<DEVICE_INFO> pDevice, std::string& Str )
{
	CString strXML, strTemp;

	strXML.Format(_T("%s<IsKilledStreamReq req_id=\"%s\">"),
		XML_UTF8_HEAD_WSTR,
		GetGlobalConfig().GetGUIDW());

	strTemp.Format(_T("<StreamID>%s</StreamID>"), pDevice->GetID());
	strXML += strTemp;

	strXML += _T("</IsKilledStreamReq>");

	Str = __WTOUTF8( strXML );

	return TRUE;
}


BOOL NRS::CNRSManage::GetStreamStatusReq( std::string& Str )
{
	CString strXML, strTemp;
	strXML.Format(_T("%s<GetStreamStatusReq req_id=\"%s\">"),
		XML_UTF8_HEAD_WSTR,
		GetGlobalConfig().GetGUIDW());

	//��� �������� 
	std::map<wstring, std::tr1::shared_ptr<DEVICE_INFO>>::iterator itrDev;	
	itrDev = GetGlobalConfig().m_mapDevices.begin();
	while(itrDev != GetGlobalConfig().m_mapDevices.end())
	{
		strTemp.Format(_T("<StreamID>%s</StreamID>"), itrDev->first.c_str());
		strXML += strTemp;

		itrDev++;
	}

	strXML += _T("</GetStreamStatusReq>");

	Str = __WTOUTF8( strXML );


	return TRUE;
}

// Month
BOOL NRS::CNRSManage::GetYearIndexReq(int nYear, std::vector<std::wstring>& vDevices, CBitArray *pMonthArray)
{
	if(vDevices.empty())
		return FALSE;

	std::string strSend, strRecv;

	CString strXML, strTemp;
	strXML.Format(_T("%s<GetYearIndexReq req_id=\"%s\">"),
		XML_UTF8_HEAD_WSTR,
		GetGlobalConfig().GetGUIDW());

	for(size_t i=0; i<vDevices.size(); i++)
	{
		strTemp.Format(_T("<StreamID>%s</StreamID>"), vDevices[i].c_str());
		strXML += strTemp;
	}

	strTemp.Format(_T("<Year>%d</Year>"), nYear);
	strXML += strTemp;

	strXML += _T("</GetYearIndexReq>");

	strSend = __WTOUTF8(strXML);

	if(SendRecvXML(strSend.c_str(), strRecv) != NO_ERROR)
		return FALSE;
	
	_Proc_GetYearIndexRes(strRecv.c_str(), pMonthArray);

	return TRUE;
}


BOOL NRS::CNRSManage::_Proc_GetYearIndexRes(const char* pXML, CBitArray* pMonthArray)
{
	CXML xml;
	if(!xml.LoadXMLFromString(pXML))
		return FALSE;

	MSXML2::IXMLDOMNodeListPtr pList = xml.FindNodeList(_T("//YearIndex"));
	if(!pList)
		return FALSE;

	pMonthArray->Reset();
	long count = pList->Getlength();
	MSXML2::IXMLDOMNodePtr pNode;
	CString sDeviceID;
	string sIndex;
	for(long i=0; i<count; i++)
	{
		pNode = pList->Getitem(i);
		sDeviceID = CXML::GetAttributeValue(pNode, L"stream_id");

		sIndex = WStringToAString(pNode->Gettext());

		SetMonthIndex(sDeviceID, sIndex.c_str(), pMonthArray);
	}
	return TRUE;
}

void NRS::CNRSManage::SetMonthIndex(LPCTSTR lpDeviceID, const char* pIndexBase64, CBitArray* pMonthArray)
{
	std::tr1::shared_ptr<DEVICE_INFO> DevicePtr;
	if(!GetGlobalConfig().GetDevice(DevicePtr, lpDeviceID))
		return;

	BYTE iMonth[4] = {0};

	int nLen = SIZEOF_ARRAY(iMonth);
	if(Base64Decode(pIndexBase64, strlen(pIndexBase64), iMonth, &nLen))
	{
		DevicePtr->SetRec_idxMonth(iMonth, nLen);
		pMonthArray->ExclusiveOR(iMonth, nLen);
	}
}

// Day
BOOL NRS::CNRSManage::GetMonthIndexReq(int nYear, int nMonth, std::vector<std::wstring>& vDevices, CBitArray* pDayArray)
{
	if(vDevices.empty())
		return FALSE;

	std::string strSend, strRecv;

	CString strXML, strTemp;

	strXML.Format(_T("%s<GetMonthIndexReq req_id=\"%s\">"),
		XML_UTF8_HEAD_WSTR,
		GetGlobalConfig().GetGUIDW());

	for(size_t i=0; i<vDevices.size(); i++)
	{
		strTemp.Format(_T("<StreamID>%s</StreamID>"), vDevices[i].c_str());
		strXML += strTemp;
	}	

	strTemp.Format(_T("<Year>%d</Year><Month>%d</Month>"), nYear, nMonth);
	strXML += strTemp;

	strXML += _T("</GetMonthIndexReq>");

	strSend = __WTOUTF8(strXML);

	if(SendRecvXML(strSend.c_str(), strRecv) != NO_ERROR)
		return FALSE;

	_Proc_GetMonthIndexRes(strRecv.c_str(), pDayArray);

	return TRUE;
}


BOOL NRS::CNRSManage::_Proc_GetMonthIndexRes(const char* pXML, CBitArray* pDayArray)
{
	CXML xml;
	if(!xml.LoadXMLFromString(pXML))
		return FALSE;

	MSXML2::IXMLDOMNodeListPtr pList = xml.FindNodeList(_T("//MonthIndex"));
	if(!pList)
		return FALSE;

	pDayArray->Reset();
	long count = pList->Getlength();
	MSXML2::IXMLDOMNodePtr pNode;
	CString sDeviceID;
	string sIndex;
	for(long i=0; i<count; i++)
	{
		pNode = pList->Getitem(i);
		sDeviceID = CXML::GetAttributeValue(pNode, L"stream_id");

		sIndex = WStringToAString(pNode->Gettext());

		SetDayIndex(sDeviceID, sIndex.c_str(), pDayArray);
	}

	return TRUE;
}

void NRS::CNRSManage::SetDayIndex(LPCTSTR lpDeviceID, const char* pIndexBase64, CBitArray* pDayArray)
{
	std::tr1::shared_ptr<DEVICE_INFO> DevicePtr;
	if(!GetGlobalConfig().GetDevice(DevicePtr, lpDeviceID))
		return;

	BYTE iDay[4] = {0};

	int nLen = SIZEOF_ARRAY(iDay);
	if(Base64Decode(pIndexBase64, strlen(pIndexBase64), iDay, &nLen))
	{
		DevicePtr->SetRec_idxDay(iDay, nLen);
		pDayArray->ExclusiveOR(iDay, nLen);
	}
}

// Hour
BOOL NRS::CNRSManage::GetDayIndexReq(int nYear, int nMonth, int nDay, std::vector<std::wstring>& vDevices, CBitArray* pHourArray)
{
	if(vDevices.empty())
		return FALSE;

	std::string strSend, strRecv;

	CString strXML, strTemp;

	strXML.Format(_T("%s<GetDayIndexReq req_id=\"%s\">"),
		XML_UTF8_HEAD_WSTR,
		GetGlobalConfig().GetGUIDW());

	for(size_t i=0; i<vDevices.size(); i++)
	{
		strTemp.Format(_T("<StreamID>%s</StreamID>"), vDevices[i].c_str());
		strXML += strTemp;
	}

	strTemp.Format(_T("<Year>%d</Year><Month>%d</Month><Day>%d</Day>"), nYear, nMonth, nDay);
	strXML += strTemp;

	strXML += _T("</GetDayIndexReq>");

	strSend = __WTOUTF8(strXML);

	if(SendRecvXML(strSend.c_str(), strRecv) != NO_ERROR)
		return FALSE;

	_Proc_GetDayIndexRes(strRecv.c_str(), pHourArray);

	return TRUE;
}


BOOL NRS::CNRSManage::_Proc_GetDayIndexRes(const char* pXML, CBitArray* pHourArray)
{
	CXML xml;
	if(!xml.LoadXMLFromString(pXML))
		return FALSE;

	MSXML2::IXMLDOMNodeListPtr pList = xml.FindNodeList(_T("//DayIndex"));
	if(!pList)
		return FALSE;

	pHourArray->Reset();
	long count = pList->Getlength();
	MSXML2::IXMLDOMNodePtr pNode;
	CString sDeviceID;
	string sIndex;
	for(long i=0; i<count; i++)
	{
		pNode = pList->Getitem(i);
		sDeviceID = CXML::GetAttributeValue(pNode, L"stream_id");

		sIndex = WStringToAString(pNode->Gettext());

		SetHourIndex(sDeviceID, sIndex.c_str(), pHourArray);
	}
	return TRUE;
}

void NRS::CNRSManage::SetHourIndex(LPCTSTR lpDeviceID, const char* pIndexBase64, CBitArray* pHourArray)
{
	std::tr1::shared_ptr<DEVICE_INFO> DevicePtr;
	if(!GetGlobalConfig().GetDevice(DevicePtr, lpDeviceID))
		return;

	BYTE iHour[8] = {0};

	int nLen = SIZEOF_ARRAY(iHour);
	if(Base64Decode(pIndexBase64, strlen(pIndexBase64), iHour, &nLen))
	{
		DevicePtr->SetRec_idxHour(iHour, nLen);
		pHourArray->ExclusiveOR(iHour, nLen);
	}
}

// Min
BOOL NRS::CNRSManage::GetHourIndexReq(int nYear, int nMonth, int nDay, int nHour, std::vector<std::wstring>& vDevices, CBitArray* pMinArray, CBitArray* pDupMinArray)
{
	if(vDevices.empty())
		return FALSE;

	std::string strSend, strRecv;

	CString strXML, strTemp;

	strXML.Format(_T("%s<GetHourIndexReq req_id=\"%s\">"),
		XML_UTF8_HEAD_WSTR,
		GetGlobalConfig().GetGUIDW());

	for(size_t i=0; i<vDevices.size(); i++)
	{
		strTemp.Format(_T("<StreamID>%s</StreamID>"), vDevices[i].c_str());
		strXML += strTemp;
	}

	strTemp.Format(_T("<Year>%d</Year><Month>%d</Month><Day>%d</Day><Hour>%d</Hour>"), nYear, nMonth, nDay, nHour);
	strXML += strTemp;

	strXML += _T("</GetHourIndexReq>");

	strSend = __WTOUTF8(strXML);

	if(SendRecvXML(strSend.c_str(), strRecv) != NO_ERROR)
		return FALSE;

	_Proc_GetHourIndexRes(strRecv.c_str(), pMinArray, pDupMinArray);

	return TRUE;
}


BOOL NRS::CNRSManage::_Proc_GetHourIndexRes(const char* pXML, CBitArray* pMinArray, CBitArray* pDupMinArray)
{
	CXML xml;
	if(!xml.LoadXMLFromString(pXML))
		return FALSE;

	MSXML2::IXMLDOMNodeListPtr pList = xml.FindNodeList(_T("//HourIndex"));
	if(!pList)
		return FALSE;

	pMinArray->Reset();
	pDupMinArray->Reset();
	long count = pList->Getlength();
	MSXML2::IXMLDOMNodePtr pNode;
	CString sDeviceID;
	string sIndex, sDupIndex;
	for(long i=0; i<count; i++)
	{
		pNode = pList->Getitem(i);
		sDeviceID = CXML::GetAttributeValue(pNode, L"stream_id");

		sIndex		= WStringToAString( CXML::GetChildNodeText(pNode, _T("IsRecorded")) );
		sDupIndex	= WStringToAString( CXML::GetChildNodeText(pNode, _T("IsOverlapped")) );

		SetMinIndex(sDeviceID, sIndex.c_str(), sDupIndex.c_str(), pMinArray, pDupMinArray);
	}
	return TRUE;
}

void NRS::CNRSManage::SetMinIndex(LPCTSTR lpDeviceID, const char* pIndexBase64, const char* pDupIndexBase64, CBitArray* pMinArray, CBitArray* pDupMinArray)
{
	std::tr1::shared_ptr<DEVICE_INFO> DevicePtr;
	if(!GetGlobalConfig().GetDevice(DevicePtr, lpDeviceID))
		return;

	if(!GetGlobalConfig().GetDevice(DevicePtr, lpDeviceID))
		return;

	BYTE iMin[8] = {0};
	BYTE iDup[8] = {0};

	int nLen1 = SIZEOF_ARRAY(iMin);
	if(Base64Decode(pIndexBase64, strlen(pIndexBase64), iMin, &nLen1))
	{
		DevicePtr->SetRec_idxMin(iMin, nLen1);
		pMinArray->ExclusiveOR(iMin, nLen1);
	}

	int nLen2 = SIZEOF_ARRAY(iDup);
	if(Base64Decode(pDupIndexBase64, strlen(pDupIndexBase64), iDup, &nLen2))
	{
		DevicePtr->SetRec_idxDupMin(iDup, nLen2);
		pDupMinArray->ExclusiveOR(iDup, nLen2);
	}
}


BOOL NRS::CNRSManage::ConnectPlayBackStream(CPlaybackStream *pPlaybackStream,
											int nYear, int nMonth, int nDay, int nHour, int nMin, 
											int nDeviceIdx,
											enum PLAYBACK_DIRECTION eDirection,
											DWORD dwStreamFlags, 
											int nOverlapID)
{
	CString strXML, strTemp;

	strXML.Format(_T("%s<StartPlaybackReq req_id=\"%s\">" \
		_T("<ClientID>%d</ClientID>")),
		XML_UTF8_HEAD_WSTR,
		GetGlobalConfig().GetGUIDW(),
		m_pXml->GetClientId());

	std::vector<std::wstring> vDevices;
	std::map<wstring, std::tr1::shared_ptr<DEVICE_INFO>>::iterator pos = GetGlobalConfig().m_mapDevices.begin();	

	int  nIdx = 0;
	while(pos != GetGlobalConfig().m_mapDevices.end())
	{			
		if(nIdx == nDeviceIdx){
			vDevices.push_back((LPCTSTR)pos->second->GetID());
			break;
		}

		pos++;
		nIdx++;
	}

	for(size_t i=0; i<vDevices.size(); i++)
	{
		strTemp.Format(_T("<StreamID>%s</StreamID>"), vDevices[i].c_str());
		strXML += strTemp;
	}

	strTemp.Format(_T("<StartDateTime>%.4d-%.2d-%.2dT%.2d:%.2d:00</StartDateTime>"), nYear, nMonth, nDay, nHour, nMin);
	strXML += strTemp;

	strTemp.Format(_T("<Type>%d</Type>"), dwStreamFlags);
	strXML += strTemp;

	strTemp.Format(_T("<OverlapID>%d</OverlapID>"), nOverlapID);
	strXML += strTemp;

	if (eDirection != PLAYBACK_DIRECTION_NONE)
	{
		strTemp.Format(_T("<Direction>%s</Direction>"), (eDirection == PLAYBACK_DIRECTION_FORWARD) ? _T("Forward") : _T("Backward"));
		strXML += strTemp;
	}

	strXML += _T("</StartPlaybackReq>");

	std::string utf8 = WStringToUTF8(strXML);

	m_pStream = Live5_ConnectStream(GetNRSHandle(), m_nId, utf8.c_str(), pPlaybackStream);

	if(m_pStream == NULL)
	{
		DisconnectPlaybackStream();
		return FALSE;
	}
	
	return TRUE;
}

void NRS::CNRSManage::DisconnectPlaybackStream()
{
	Live5_DisconnectStream(GetNRSHandle(), m_nId, m_pStream);
	m_pStream = NULL;
}

BOOL NRS::CNRSManage::Pause(size_t nPlaybackID)
{
	std::string strSend;

	CString strXML;
	strXML.Format(_T("%s<PausePlaybackReq req_id=\"%s\">") \
		_T("<PlaybackID>%d</PlaybackID>") \
		_T("</PausePlaybackReq>"),
		XML_UTF8_HEAD_WSTR,
		GetGlobalConfig().GetGUIDW(),
		nPlaybackID);

	strSend = __WTOUTF8(strXML);

	return (SendXML(strSend.c_str()) == NO_ERROR);
}

BOOL NRS::CNRSManage::Resume(size_t nPlaybackID)
{
	std::string strSend;

	CString strXML;
	strXML.Format(_T("%s<ResumePlaybackReq req_id=\"%s\">") \
		_T("<PlaybackID>%d</PlaybackID>") \
		_T("</ResumePlaybackReq>"),
		XML_UTF8_HEAD_WSTR,
		GetGlobalConfig().GetGUIDW(),
		nPlaybackID);

	strSend = __WTOUTF8(strXML);

	return (SendXML(strSend.c_str()) == NO_ERROR);
}

BOOL NRS::CNRSManage::Stop(size_t nPlaybackID)
{
	std::string strSend;

	CString strXML;
	strXML.Format(_T("%s<StopPlaybackReq req_id=\"%s\">") \
		_T("<PlaybackID>%d</PlaybackID>") \
		_T("</StopPlaybackReq>"),
		XML_UTF8_HEAD_WSTR,
		GetGlobalConfig().GetGUIDW(),
		nPlaybackID);

	strSend = __WTOUTF8(strXML);

	return (SendXML(strSend.c_str()) == NO_ERROR);
}

BOOL NRS::CNRSManage::ControlPlayback(size_t nPlaybackID, LPCTSTR lpDirection, LPCTSTR lpSpeed, BOOL bOnlyKeyFrame)
{
	std::string strSend;

	CString strXML ;
	strXML.Format(_T("%s<ControlPlaybackReq req_id=\"%s\">") \
		_T("<PlaybackID>%d</PlaybackID>") \
		_T("<Direction>%s</Direction>") \
		_T("<Speed>%s</Speed>") \
		_T("<OnlyKeyFrame>%d</OnlyKeyFrame>") \
		_T("</ControlPlaybackReq>"),
		XML_UTF8_HEAD_WSTR,
		GetGlobalConfig().GetGUIDW(),
		nPlaybackID,
		lpDirection,
		lpSpeed,
		bOnlyKeyFrame);

	strSend = __WTOUTF8(strXML);

	return (SendXML(strSend.c_str()) == NO_ERROR);
}

// Nest Step
BOOL NRS::CNRSManage::NextStep(size_t nPlaybackID)
{
	std::string strSend;

	CString strXML;
	strXML.Format(_T("%s<NextStepPlaybackReq req_id=\"%s\">") \
		_T("<PlaybackID>%d</PlaybackID>") \
		_T("</NextStepPlaybackReq>"),
		XML_UTF8_HEAD_WSTR,
		GetGlobalConfig().GetGUIDW(),
		nPlaybackID);

	strSend = __WTOUTF8(strXML);

	return (SendXML(strSend.c_str()) == NO_ERROR);
}

// Prev Step
BOOL NRS::CNRSManage::PrevStep(size_t nPlaybackID)
{
	std::string strSend;

	CString strXML;
	strXML.Format(_T("%s<PrevStepPlaybackReq req_id=\"%s\">") \
		_T("<PlaybackID>%d</PlaybackID>") \
		_T("</PrevStepPlaybackReq>"),
		XML_UTF8_HEAD_WSTR,
		GetGlobalConfig().GetGUIDW(),
		nPlaybackID);

	strSend = __WTOUTF8(strXML);

	return (SendXML(strSend.c_str()) == NO_ERROR);
}

BOOL NRS::CNRSManage::RemoteDiskInfo(std::map<std::wstring, LOCAL_DISK_INFO>& DiskMap)
{
	std::map<std::wstring, LOCAL_DISK_INFO> RevDiskMap;

	string SendStr, RecvStr;
	_sprintf_string(SendStr, "%s<GetDiskInfoReq req_id=\"%s\" />",
		XML_UTF8_HEAD_STR,
		GetGlobalConfig().GetGUIDA());


	if(SendRecvXML(SendStr.c_str(), RecvStr) != NO_ERROR)
	{
		ASSERT(FALSE);
		return FALSE;
	}

	CXML xml;
	if(!xml.LoadXMLFromString(RecvStr.c_str()))
	{
		ASSERT(FALSE);
		return FALSE;
	}

	MSXML2::IXMLDOMNodeListPtr pDriveList;
	pDriveList = xml.FindNodeList(_T("//Drive"));
	if(pDriveList == NULL)
	{
		ASSERT(FALSE);
		return FALSE;
	}

	LOCAL_DISK_INFO DiskInfo;

	MSXML2::IXMLDOMNodePtr pDriveNode;
	long count = pDriveList->Getlength();
	for(long i=0; i<count; i++)
	{
		pDriveNode = pDriveList->Getitem(i);
		
		DiskInfo.strRootPath		= CXML::GetChildNodeText(pDriveNode, _T("RootPath"));
		DiskInfo.strRootPath.MakeUpper();
		DiskInfo.strDrive			= CXML::GetChildNodeText(pDriveNode, _T("Name"));
		DiskInfo.strDrive.MakeUpper();
		DiskInfo.strVolumeSerial	= CXML::GetChildNodeText(pDriveNode, _T("VolumeSerial"));
		DiskInfo.dbTotal			= DOUBLE( _ttoi64( CXML::GetChildNodeText(pDriveNode, _T("Total")) ) / GIGABYTE );
		DiskInfo.dbUsed				= DOUBLE( _ttoi64( CXML::GetChildNodeText(pDriveNode, _T("TotalUsage")) ) / GIGABYTE );
		DiskInfo.dbTotalFree		= DiskInfo.dbTotal - DiskInfo.dbUsed;
		DiskInfo.nRecordReserved	= _ttoi64( CXML::GetChildNodeText(pDriveNode, _T("Reserved")) );
		DiskInfo.nCommitReserved	= DiskInfo.nRecordReserved;
		DiskInfo.nRecordUsed		= _ttoi64( CXML::GetChildNodeText(pDriveNode, _T("Usage")) );
		DiskInfo.nDriveType			= DRIVE_FIXED;	// ��Ʈ������ ���°� �� �̰ɷ� �����Ѵ�.
		
		RevDiskMap.insert( pair<wstring, LOCAL_DISK_INFO>((LPCTSTR)DiskInfo.strVolumeSerial, DiskInfo) );
	}

	DiskMap.insert(RevDiskMap.begin(), RevDiskMap.end());

	return TRUE;
}

BOOL NRS::CNRSManage::UpdateRecordingScheduleReq(std::vector<std::wstring>& vDevices)
{
	if(vDevices.empty())
		return FALSE;

	std::string strSend, strRecv;

	CString strXML, strTemp;

	strXML.Format(_T("%s<UpdateRecordingScheduleReq req_id=\"%s\">"),
		XML_UTF8_HEAD_WSTR,
		GetGlobalConfig().GetGUIDW());

	for(size_t i=0; i<vDevices.size(); i++)
	{
		strTemp.Format(_T("<RecordingSchedule stream_id=\"%s\">") \
			_T("<Pre>%d</Pre>") \
			_T("<Post>%d</Post>") \
			_T("<Schedule>"),
			vDevices[i].c_str(),
			0, /* ���� ���ڵ� �ð�(��) */
			10/* ����Ʈ ���ڵ� �ð�(��) */);

		strXML += strTemp;

		strXML += _T("<Time type=\"normal\">\r\n");

		strTemp.Format(_T("<Sch id=\"%s\" adv=\"%d\" audio=\"%d\" type=\"%d\" ") \
			_T("sun=\"%d\" mon=\"%d\" tue=\"%d\" wed=\"%d\" thu=\"%d\" fri=\"%d\" sat=\"%d\"></Sch>\r\n"),
			_T(""), 0, 1, 1,
			16777215,  /* 0000 0000 1111 1111 1111 1111 1111 1111 */
			16777215,
			16777215,
			16777215,
			16777215,
			16777215,
			16777215);

		strXML += strTemp;
		strXML += _T("</Time>\r\n");
		strXML += _T("</Schedule></RecordingSchedule>");
		strXML += _T("</UpdateRecordingScheduleReq>");

		strSend = __WTOUTF8(strXML);

		if(SendRecvXML(strSend.c_str(), strRecv) != NO_ERROR)
			return FALSE;

		Remote_CheckError(strRecv.c_str());
	}

	return TRUE;
}

void NRS::CNRSManage::Remote_CheckError(const char* pRecvStr)
{
	CXML xml;
	if(!xml.LoadXMLFromString(pRecvStr))
		return;

	MSXML2::IXMLDOMNodeListPtr pErrorList = xml.FindNodeList(_T("//NRSError"));
	if(pErrorList)
	{
		long count = pErrorList->Getlength();
		for(long i=0; i<count; i++)
		{
			MSXML2::IXMLDOMNodePtr pNode = pErrorList->Getitem(i);

			if(pNode->Gettext() != bstr_t(L"OK"))
			{
				assert(0);
			}
		}
	}
}

BOOL NRS::CNRSManage::RecordingOverwriteReq()
{
	CString strXML;

	std::string strSend, strRecv;

	strXML.Format(_T("%s<RecordingOverwriteReq req_id=\"%s\" onoff=\"%d\" />"),
		XML_UTF8_HEAD_WSTR,
		GetGlobalConfig().GetGUIDW(),
		1);

	strSend = __WTOUTF8(strXML);

	if(SendRecvXML(strSend.c_str(), strRecv) != NO_ERROR)
		return FALSE;

	Remote_CheckError(strRecv.c_str());

	return TRUE;
}

BOOL NRS::CNRSManage::ReserveDiskSizeReq(std::map<std::wstring, LOCAL_DISK_INFO> DiskMap)
{
	CString strXML, strTemp;

	std::string strSend, strRecv;
	
	strXML.Format(_T("%s<ReserveDiskSizeReq req_id=\"%s\">"),
		XML_UTF8_HEAD_WSTR,
		GetGlobalConfig().GetGUIDW());

	map<wstring, LOCAL_DISK_INFO>::iterator itrDisk = DiskMap.begin();
	while(itrDisk != DiskMap.end())
	{
		if(!itrDisk->first.empty())
		{
			strTemp.Format(_T("<Drive volume_serial=\"%s\"><Size>%I64d</Size></Drive>"),
				itrDisk->first.c_str(),
				itrDisk->second.nCommitReserved);
			strXML += strTemp;
		}

		itrDisk++;
	}

	strXML += _T("</ReserveDiskSizeReq>");

	strSend = __WTOUTF8(strXML);

	if(SendRecvXML(strSend.c_str(), strRecv) != NO_ERROR)
		return FALSE;

	Remote_CheckError(strRecv.c_str());

	return TRUE;
}

BOOL NRS::CNRSManage::UpdateDiskPolicyReq(std::vector<std::wstring> Mac,
							std::map<std::wstring, LOCAL_DISK_INFO> DiskMap)
{
	if(Mac.empty())
		return FALSE;

	if(DiskMap.empty())
		return FALSE;

	CString strXML, strTemp;
	std::string strSend, strRecv;
	
	map<wstring, LOCAL_DISK_INFO>::iterator itrDrive = DiskMap.begin();

	strXML.Format(_T("%s<UpdateDiskPolicyReq req_id=\"%s\">"),
		XML_UTF8_HEAD_WSTR,
		GetGlobalConfig().GetGUIDW());


	// ����̺꿡 ���� ��ġ ��� ������ �����ϹǷ� ����̺꺰 Mac List�� ���� �����ؾ� ��.
	// ���� �ؿ� �ڵ�� � �Ѱ��� ����̺꿡�� Mac List�� �����Ѱ� ��.
	map<wstring, LOCAL_DISK_INFO>::iterator itrDisk = DiskMap.begin();
	while(itrDisk != DiskMap.end())
	{
		if(!itrDisk->first.empty() && itrDisk->second.nCommitReserved > 0)
		{
			strTemp.Format(_T("<Drive volume_serial=\"%s\">"), itrDisk->first.c_str());
			strXML += strTemp;
		}

		itrDisk++;
	}

	for(size_t i=0; i<Mac.size(); i++){
		strTemp.Format(_T("<MAC>%s</MAC>"), Mac[i].c_str());
		strXML += strTemp;
	}
	strXML += _T("</Drive>");
	
	strXML += _T("</UpdateDiskPolicyReq>");

	strSend = __WTOUTF8(strXML);

	if(SendRecvXML(strSend.c_str(), strRecv) != NO_ERROR)
		return FALSE;

	Remote_CheckError(strRecv.c_str());

	return TRUE;
}

BOOL NRS::CNRSManage::StartRecordingAllReq()
{
	std::string strSend, strRecv;

	_sprintf_string(strSend, "%s<StartRecordingAllReq req_id=\"%s\" />",
		XML_UTF8_HEAD_STR,
		GetGlobalConfig().GetGUIDA());
	if(SendRecvXML(strSend.c_str(), strRecv) != NO_ERROR)
		return FALSE;

	return TRUE;
}

BOOL NRS::CNRSManage::StopRecordingAllReq()
{
	std::string strSend, strRecv;

	_sprintf_string(strSend, "%s<StopRecordingAllReq req_id=\"%s\" />",
		XML_UTF8_HEAD_STR,
		GetGlobalConfig().GetGUIDA());

	if(SendRecvXML(strSend.c_str(), strRecv) != NO_ERROR)
		return FALSE;

	return TRUE;
}