#include "StdAfx.h"
#include "NRSBase.h"
#include "ScopeLock.h"


using namespace NRS;

CNRSBase::CNRSBase(size_t nId)
: m_nId(nId)
, m_bIsConnecting(FALSE)
, m_bIsConnected(FALSE)
, m_bBlockMode(FALSE)
, m_Protocol(NAUTILUS_V2)
, m_bAsyncrousConnection(TRUE)
, m_pXml(NULL)
{
	InitializeCriticalSection(&m_cs);
	InitializeCriticalSection(&m_csCallback);
	m_hEvent = CreateEvent(NULL, TRUE, TRUE, NULL);

	m_pXml = new CNRSXmlParser(this);
}

CNRSBase::~CNRSBase(void)
{
	Disconnect();
	CloseHandle(m_hEvent);
	DeleteCriticalSection(&m_csCallback);
	DeleteCriticalSection(&m_cs);

	if(m_pXml)
	{
		delete m_pXml;
		m_pXml = NULL;
	}
}

void CNRSBase::LockWork()
{
}

void CNRSBase::UnlockWork()
{
}

BOOL CNRSBase::Connect(const CString& strAddress /*= _T("127.0.0.1")*/, const UINT nPort /*= DEFAULT_NCSERVICE_PORT*/,
					   const CString& strUser /*= _T("admin")*/, const CString& strPassword /*= _T("admin")*/,
					   LiveProtocol Protocol /*= NAUTILUS_V2*/, BOOL bAsync /*= TRUE*/
					   )
{
	LiveConnect Conn;
	BOOL bConnect;

	m_strAddress		= strAddress;
	m_nPort				= nPort;
	m_strUserId			= strUser;
	m_strUserPassword	= strPassword;
	m_Protocol				= Protocol;
	m_bAsyncrousConnection	= bAsync;
	
	ZeroMemory(&Conn, sizeof(Conn));

	std::string addr = WStringToUTF8(strAddress);
	std::string user = WStringToUTF8(strUser);
	std::string pass = WStringToUTF8(strPassword);

	Conn.nIdx			= m_nId;
	Conn.sAddress		= addr.c_str();
	Conn.nPort			= nPort;
	Conn.bAsync			= bAsync;
	Conn.Protocol		= Protocol;
	Conn.pReceiver		= this;
	Conn.pUserId		= user.c_str();
	Conn.pUserPassword	= pass.c_str();
	Conn.nVersion		= MAKE_LIVEVERSION(NAUTILUS_FILE_VERSION, NAUTILUS_DB_VERSION);

	m_bIsConnecting = bAsync;

	bConnect = Live5_ConnectEx(GetNRSHandle(), &Conn);
	
	if(!bAsync)
		m_bIsConnected = bConnect;

	return bConnect;
}

BOOL CNRSBase::Reconnect()
{
	return Connect(m_strAddress, m_nPort, m_strUserId, m_strUserPassword, m_Protocol, m_bAsyncrousConnection);
}

void CNRSBase::OnNotifyMessage(LiveNotifyMsg* pNotify)
{
	//TRACE(">>>> CNRSBase::OnNotifyMessage: %d, err: %d\n", pNotify->nMessage, pNotify->nError);

	while(!TryEnterCriticalSection(&m_cs))
	{
		// ���������ÿ���....
		if(pNotify->nMessage == LIVE_DISCONNECT)
		{
			m_bIsConnecting	= FALSE;
			m_bIsConnected	= FALSE;
		}
	}

	EnterCriticalSection(&m_csCallback);
	m_CallbackFuncMap.clear();
	LeaveCriticalSection(&m_csCallback);

	if(pNotify->nMessage == LIVE_CONNECT)
	{
		m_bIsConnecting = FALSE;
		if(pNotify->nError == NO_ERROR)
			m_bIsConnected = TRUE;
		else
			m_bIsConnected = FALSE;
	}
	else if(pNotify->nMessage == LIVE_DISCONNECT)
	{
		m_bIsConnecting	= FALSE;
		m_bIsConnected	= FALSE;
	}

	LeaveCriticalSection(&m_cs);
}

void CNRSBase::Disconnect()
{
	Live5_Disconnect(GetNRSHandle(), m_nId);
}

void CNRSBase::SetAddress(const CString& strAddress)
{
	m_strAddress = strAddress;
}

void CNRSBase::SetPort(const UINT nPort)
{
	m_nPort = nPort;
}

void CNRSBase::SetUser(const CString& strUserId, const CString& strUserPassword)
{
	m_strUserId = strUserId;
	m_strUserPassword = strUserPassword;
}

CString CNRSBase::GetUserId() const
{
	return m_strUserId;
}

CString CNRSBase::GetUserPassword() const
{
	return m_strUserPassword;
}

void CNRSBase::OnReceive(LPStreamData Data)
{
	if(Data->Type == FRAME_XML)
	{
		m_pXml->Process((const char*)Data->pData, Data->nDataSize);
		if(m_bBlockMode)
		{
			if(m_pXml->IsEqualReqId(m_strReqID))
			{
				m_sRecvStr = (const char*)Data->pData;
				m_strReqID.IsEmpty();
				m_bBlockMode = FALSE;

				SetEvent(m_hEvent);
			}
		}

		std::wstring req_Id = (LPCTSTR) m_pXml->GetReqId();
		if(!req_Id.empty())
		{
			std::map<std::wstring, NRS_RECEIVEDATAFUNCTION_T>::iterator pos;
			EnterCriticalSection(&m_csCallback);

			pos = m_CallbackFuncMap.find(req_Id);
			if(pos != m_CallbackFuncMap.end())
			{
				pos->second.func( Data->pData, Data->nDataSize, pos->second.pUserContext );
				m_CallbackFuncMap.erase(pos);
			}

			LeaveCriticalSection(&m_csCallback);
		}
	}
}

int CNRSBase::SendXML(const wchar_t* pXML)
{
	std::string utf8 = WStringToUTF8(pXML);

	return SendXML(utf8.c_str());
}

int CNRSBase::SendXML(const char* pXML)
{
	return Live5_SendXML(GetNRSHandle(), m_nId, pXML);
}

int CNRSBase::SendXML(const wchar_t* pXML, LPNRS_RECEIVEDATAFUNCTION Func, void* pUserContext)
{
	std::string utf8 = WStringToUTF8(pXML);

	return SendXML(utf8.c_str());
}

int CNRSBase::SendXML(const char* pXML, LPNRS_RECEIVEDATAFUNCTION Func, void* pUserContext)
{
	int nErr;
	CXML xml;

	if(!xml.LoadXMLFromString(pXML))
		return -1;

	MSXML2::IXMLDOMNodePtr pRoot = xml.GetRootElementPtr();
	CString strId = CXML::GetAttributeValue(pRoot, L"req_id");

	if(strId.IsEmpty())
		return -1;

	NRS_RECEIVEDATAFUNCTION_T f;
	f.func			= Func;
	f.pUserContext	= pUserContext;
	_ftime64(&f.t);

	EnterCriticalSection(&m_csCallback);
	m_CallbackFuncMap.insert( pair<std::wstring, NRS_RECEIVEDATAFUNCTION_T>((LPCTSTR)strId, f) );

	nErr = Live5_SendXML(GetNRSHandle(), m_nId, pXML);
	if(nErr != NO_ERROR)
		m_CallbackFuncMap.erase( (LPCTSTR)strId );

	LeaveCriticalSection(&m_csCallback);

	return nErr;
}

int CNRSBase::SendRecvXML(std::string& sSend, std::string& sRecv, DWORD dwTimeout /*= 3000*/)
{
	return SendRecvXML(sSend.c_str(), sRecv, dwTimeout);
}

int CNRSBase::SendRecvXML(const wchar_t* pSendXML, std::string& sRecv, DWORD dwTimeout /*= 3000*/)
{
	std::string utf8 = WStringToUTF8(pSendXML);

	return SendRecvXML(utf8.c_str(), sRecv, dwTimeout);
}

BOOL CNRSBase::IsConnected(BOOL bNoSync /*= FALSE*/)
{
	if(bNoSync)
		return m_bIsConnected;

	BOOL bConnected;
	{
		CScopeLock scope_lock(&m_cs);
		bConnected = m_bIsConnected;
	}
	return bConnected; 
}
	
BOOL CNRSBase::IsConnecting(BOOL bNoSync /*= FALSE*/)
{
	if(bNoSync)
		return m_bIsConnecting;

	BOOL bConnecting;
	{
		CScopeLock scope_lock(&m_cs);
		bConnecting = m_bIsConnecting;
	}

	return bConnecting;
}

int CNRSBase::SendRecvXML(const char* pSendXML, std::string& sRecv, DWORD dwTimeout /*= 3000*/)
{
	CScopeLock scope_lock(&m_cs);
	if(!m_bIsConnected)
		return -1;

	int nError = NO_ERROR;
	CXML xml;
	if(!xml.LoadXMLFromString(pSendXML))
		return -1;

	MSXML2::IXMLDOMNodePtr pRoot = xml.GetRootElementPtr();
	m_strReqID = CXML::GetAttributeValue(pRoot, L"req_id");
	if(m_strReqID.IsEmpty())
	{
		return -1;
	}

	m_bBlockMode = TRUE;
	ResetEvent(m_hEvent);

	nError = Live5_SendXML(GetNRSHandle(), m_nId, pSendXML);
	if(nError != NO_ERROR)
		return nError;

	DWORD dwTime = 0;
	DWORD dwWait;
	DWORD dwSleep = 500;

	do
	{
		dwWait = WaitForSingleObject(m_hEvent, dwSleep);
		if(dwWait == WAIT_TIMEOUT)
		{
			if(dwTimeout != INFINITE)
			{
			        dwTime += dwSleep;
			        if(dwTime > dwTimeout)
			        {
				        nError = ERROR_TIMEOUT;
				        TRACE(_T("SendRecvXML Ÿ�Ӿƿ�~~~\n"));
				        break;
			        }
			}

			if(m_bIsConnected == FALSE)
			{
				nError = ERROR_CONNECTION_INVALID;
				break;
			}

		}
		else if(dwWait == WAIT_OBJECT_0)
		{
			sRecv = m_sRecvStr;
			nError = NO_ERROR;
			break;
		}	

	} while(1);

	m_bBlockMode = FALSE;

	return nError;
}

void CNRSBase::SetProtocol(LiveProtocol Protocol)
{
	m_Protocol = Protocol;
}

void CNRSBase::SetAsyncrousConnection(BOOL bAsync)
{
	m_bAsyncrousConnection = bAsync;
}

LiveProtocol CNRSBase::GetProtocol() const
{
	return m_Protocol;
}

BOOL CNRSBase::IsAsyncrousConnection() const
{
	return m_bAsyncrousConnection;
}

size_t CNRSBase::GetClientID() const
{
	return m_pXml->GetClientId();
}

void CNRSBase::AddNotifyCallback(LPCTSTR pNodeName, LPNRS_RECEIVEDATAFUNCTION Func, void* pUserContext)
{
	m_pXml->AddNotifyCallback(pNodeName, Func, pUserContext);
}

void CNRSBase::RemoveNotifyCallback(LPCTSTR pNodeName)
{
	m_pXml->RemoveNotifyCallback(pNodeName);
}

size_t CNRSBase::GetID() const
{
	return m_nId;
}
