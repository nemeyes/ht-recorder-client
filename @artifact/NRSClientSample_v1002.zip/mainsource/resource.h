//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by NRSClientSample.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MAIN_DIALOG                 102
#define IDR_MAINFRAME                   128
#define IDD_DLG_SUB_VIEW                129
#define IDD_DIALOG_DEVICE_LIST          130
#define IDD_DLG_PLAYBACK_VIEW           131
#define IDD_DLG_RECORDING_VIEW          132
#define IDC_BUTTON1                     1000
#define IDC_BTN_DEV_SEARCH_START        1000
#define IDC_BTN_ALL_RESTART             1000
#define IDC_BUTTON_NRS_CONNECT          1000
#define IDC_BTN_DEV_ADD                 1000
#define IDC_BTN_REC_START               1000
#define IDC_BTN_DEV_SEARCH_STOP         1001
#define IDC_BTN_ALL_RESET               1001
#define IDC_BTN_DEV_MODIFY              1001
#define IDC_BTN_REC_STOP                1001
#define IDC_COMBO_CONNECT_TYPE          1002
#define IDC_BTN_ALL_DEFAULT             1002
#define IDC_BTN_DEV_DELETE              1002
#define IDC_COMBO_LAYOUT                1003
#define IDC_BTN_ALL_DELETE              1003
#define IDC_LIST_CAMERA_CONFIG          1004
#define IDC_LIST_DEVS                   1004
#define IDC_BTN_CAM_INFO                1005
#define IDC_BTN_ALL_FW_UPDATE           1005
#define IDC_BTN_CLEAR                   1005
#define IDC_BTN_EXIT                    1006
#define IDC_LIST_LOG                    1007
#define IDC_BUTTON2                     1008
#define IDC_BTN_TEST                    1008
#define IDC_BUTTON_MAKE_STREAMID        1008
#define IDC_BTN_PERV_SPLIT_GROUP        1009
#define IDC_BTN_ALL_REFRESH             1010
#define IDC_BUTTON4                     1010
#define IDC_BTN_NEXT_SPLIT_GROUP        1010
#define IDC_BTN_ALL_REFRESH2            1011
#define IDC_BTN_ALL_CMD_STOP            1011
#define IDC_EDIT_NRS_IP                 1014
#define IDC_EDIT_USER_ID                1015
#define IDC_EDIT_USER_PW                1016
#define IDC_BUTTON_CAMERA_REGISTER      1017
#define IDC_STATIC_1                    1018
#define IDC_STATIC_2                    1019
#define IDC_STATIC_3                    1020
#define IDC_EDIT_STREAMID               1021
#define IDC_EDIT_MAC                    1022
#define IDC_EDIT_PROFILE                1023
#define IDC_COMBO_MODEL_TYPE            1024
#define IDC_EDIT_MODEL_NAME             1025
#define IDC_EDIT_DEV_IP                 1026
#define IDC_EDIT_DEV_URL                1027
#define IDC_COMBO_CONN_TYPE             1028
#define IDC_EDIT_ONVIF_URL              1029
#define IDC_EDIT_DEV_PORT               1030
#define IDC_EDIT_DEV_TYPE               1031
#define IDC_BTN_PLAYBACK_VIEW           1032
#define IDC_COMBO_DEVICE                1033
#define IDC_COMBO_YEAR                  1034
#define IDC_COMBO_MONTH                 1035
#define IDC_COMBO_DAY                   1036
#define IDC_COMBO_HOUR                  1037
#define IDC_COMBO_MIN                   1038
#define IDC_BTN_PLAY                    1039
#define IDC_BTN_STOP                    1040
#define IDC_BTN_PREV_STEP               1041
#define IDC_BTN_NEXT_STEP               1042
#define IDC_BTN_BACKWARD                1043
#define IDC_BTN_PAUSE                   1044
#define IDC_EDIT_STATUS                 1045
#define IDC_COMBO_DRIVE                 1048
#define IDC_EDIT_DISK_ALLOC             1049
#define IDC_BTN_RECORDING_SETUP         1050

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1050
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
