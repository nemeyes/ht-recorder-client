#pragma once
#include "NRSXmlParser.h"


namespace NRS
{
	class CNRSBase : public IStreamReceiver5
	{
	public:
		CNRSBase(size_t nId);
		virtual ~CNRSBase(void);

		virtual void OnNotifyMessage(LiveNotifyMsg* pNotify);
		virtual void OnReceive(LPStreamData Data);
		virtual BOOL Connect(const CString& strAddress = _T("127.0.0.1"), const UINT nPort = DEFAULT_NCSERVICE_PORT,
			const CString& strUser = _T("admin"), const CString& strPassword = _T("admin"),
			LiveProtocol Protocol = NAUTILUS_V2, BOOL bAsync = TRUE);
		virtual BOOL Reconnect();
		virtual void Disconnect();
		virtual void	LockWork();
		virtual void	UnlockWork();

		void			SetProtocol(LiveProtocol Protocol);
		void		SetAsyncrousConnection(BOOL bAsync);
		LiveProtocol	GetProtocol() const;
		BOOL		IsAsyncrousConnection() const;

		BOOL			IsConnected(BOOL bNoSync = FALSE);
		BOOL			IsConnecting(BOOL bNoSync = FALSE);
		void		SetAddress(const CString& strAddress);
		void		SetPort(const UINT nPort);
		void		SetUser(const CString& strUserId, const CString& strUserPassword);
		CString		GetAddress() const { return m_strAddress; }
		UINT		GetPort() const { return m_nPort; }
		CString		GetUserId() const;
		CString		GetUserPassword() const;

		int			SendXML(const wchar_t* pXML);
		int			SendXML(const char* pXML);
		int				SendXML(const wchar_t* pXML, LPNRS_RECEIVEDATAFUNCTION Func, void* pUserContext);
		int				SendXML(const char* pXML, LPNRS_RECEIVEDATAFUNCTION Func, void* pUserContext);

		int			SendRecvXML(const wchar_t* pSendXML, std::string& sRecv, DWORD dwTimeout = 3000);
		int			SendRecvXML(const char* pSendXML, std::string& sRecv, DWORD dwTimeout = 3000);
		int				SendRecvXML(std::string& sSend, std::string& sRecv, DWORD dwTimeout = 3000);

		size_t		GetClientID() const;
		void			AddNotifyCallback(LPCTSTR pNodeName, LPNRS_RECEIVEDATAFUNCTION Func, void* pUserContext);
		void			RemoveNotifyCallback(LPCTSTR pNodeName);

		size_t			GetID() const;

	protected:
		size_t		m_nId;
		CString		m_strAddress;
		UINT		m_nPort;
		CString		m_strUserId;
		CString		m_strUserPassword;
		BOOL		m_bIsConnecting;
		BOOL		m_bIsConnected;
		CNRSXmlParser*	m_pXml;

		// Block ��忡�� req_id ������ �̿��ؼ� ������.
		HANDLE		m_hEvent;
		CString		m_strReqID;
		BOOL		m_bBlockMode;
		std::string	m_sRecvStr;

		LiveProtocol	m_Protocol;
		BOOL		m_bAsyncrousConnection;

		CRITICAL_SECTION m_cs;
		CRITICAL_SECTION m_csCallback;

		std::map<std::wstring, NRS_RECEIVEDATAFUNCTION_T>	m_CallbackFuncMap;
	};

};
