#pragma once

#include "NRSManageII.h"

// CDlgRecordingView ��ȭ �����Դϴ�.
class CDlgDeviceRegister;

class CDlgRecordingView : public CDialog
{
	DECLARE_DYNAMIC(CDlgRecordingView)

public:
	CDlgRecordingView(NRS::CNRSManage *pNrs, CDlgDeviceRegister *pDlgDevReg, CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CDlgRecordingView();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DLG_RECORDING_VIEW };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	NRS::CNRSManage *m_pNrsManage;
	CDlgDeviceRegister *m_pDlgDevReg;

	// ��ũ ���� 
	std::map<std::wstring, LOCAL_DISK_INFO>	m_DiskMap;
	
	CComboBox m_cbDrive;

	BOOL RecordingSetup();
	BOOL m_bRecordingStart;
	
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg void OnBnClickedBtnRecStart();
	afx_msg void OnBnClickedBtnRecStop();
};
