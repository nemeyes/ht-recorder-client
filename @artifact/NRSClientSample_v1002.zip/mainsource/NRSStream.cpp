#include "StdAfx.h"
#include "NRSStream.h"
#include "../Include/DeviceInfo.h"
#include <ScopeLock.h>

using namespace NRS;

////////////////////////////////////////////////////////////////////////////////////
// CNRSStream

LONG CNRSStream::m_nCount = 0;

BOOL CNRSStream::m_bEnableVideoSync = TRUE;

CNRSStream::CNRSStream(CNRSManage& NRS, size_t nId, LPCTSTR lpszDeviceID, DWORD dwStreamFlags /*= NRS_RELAY_VIDEO | NRS_RELAY_AUDIO | NRS_RELAY_META*/)
: m_NRS(NRS)
, m_nId(nId)
, m_dwStreamFlags(dwStreamFlags)
, m_sDeviceID(lpszDeviceID)
, m_pHandle(NULL)
, m_VideoType(AVMEDIA_UNKNOWN)
, m_AudioType(AVMEDIA_UNKNOWN)
, m_bIsConnecting(FALSE)
, m_bIsConnected(FALSE)
, m_bFindFirstKey(FALSE)
, m_lRunWorker(0)
, m_bMetaOnly(FALSE)
, m_tVideo(0)
, m_nVideoCount(0)
, m_tVideoClock(0)
, m_nVideoFrameRate(0)
, m_tAudio(0)
, m_nAudioCount(0)
, m_bNoDeviceStream(FALSE)
, m_bIsConnectionStop(FALSE)
//, m_pAudioCapture(NULL)
, m_bCaptureAudio(FALSE)
, m_bIsResponseRelay(FALSE)
, m_nVideoFilter(0)
{
	InitializeCriticalSection(&m_cs);
	InitializeCriticalSection(&m_cs2);

	ZeroMemory(m_Key, sizeof(m_Key));

	
	std::tr1::shared_ptr<DEVICE_INFO> DevicePtr;
	if(GetGlobalConfig().GetDevice(DevicePtr, lpszDeviceID))
	{
		m_Key[7] = (BYTE)DevicePtr->GetKeyID();
		_sprintf_string(m_sDecodeKey, "%02X%02X%02X%02X%02X%02X%02X%02X",
			m_Key[0],m_Key[1],m_Key[2],m_Key[3],m_Key[4],m_Key[5],m_Key[6],m_Key[7]);
	}

	m_nCount++;
	m_nThreadId = m_nCount % (GetThreadPool().GetNumberOfThread() - 1);
	m_nWorkKey	= m_nCount;

	m_VideoSize.cx	= 704;
	m_VideoSize.cy	= 480;

	ZeroMemory(&m_tLastUpdate, sizeof(m_tLastUpdate));
	m_nArIndex = 0;
	ZeroMemory(m_fArVideoRate, sizeof(m_fArVideoRate));

	m_Decode.SetVideoOutput(DISP_YUY2);
	m_Decode.SetEnableDecodeMode(TRUE);
}

LONG CNRSStream::IncreaseWorkKey()
{
	LONG count = InterlockedIncrement(&m_nCount);

	return count;
}

CNRSStream::~CNRSStream()
{
	//StopAudioCapture();
	Disconnect();
	ClearBuffer();

	while(InterlockedExchange(&m_lRunWorker, 1) == 1)
		Sleep(10);

	DeleteCriticalSection(&m_cs);
	DeleteCriticalSection(&m_cs2);
}

CNRSStream* CNRSStream::CreateStream(CNRSManage& NRS, size_t nId, LPCTSTR lpszDeviceID, DWORD dwStreamFlags /*= NRS_RELAY_VIDEO | NRS_RELAY_AUDIO | NRS_RELAY_META*/)
{
	return new CNRSStream(NRS, nId, lpszDeviceID, dwStreamFlags);
}

void CNRSStream::DeleteStream(CNRSStream* pStream)
{
	delete pStream;
}

void CNRSStream::ClearBuffer(BOOL bAfterMetaOnly /*= FALSE*/, BOOL bCloseCodec /*= FALSE*/)
{
	std::list<NCStreamBuffer*>::iterator pos;

	Lock();
	m_bFindFirstKey = FALSE;
	GetThreadPool().ClearWorkerFunction(m_nThreadId, m_nWorkKey);

	pos = m_Queue.begin();
	while(pos != m_Queue.end())
	{
		delete (*pos);
		pos++;
	}
	m_Queue.clear();

	m_bMetaOnly = bAfterMetaOnly;

	if(bCloseCodec)
		m_Decode.Close();

	Unlock();
}

void CNRSStream::OnNotifyMessage(LiveNotifyMsg* pNotify)
{
	std::tr1::shared_ptr<DEVICE_INFO> DevicePtr;
	GetGlobalConfig().GetDevice(DevicePtr, m_sDeviceID.c_str());

	if(pNotify->nMessage == LIVE_STREAM_CONNECT)
	{
		m_bIsConnecting = FALSE;
		if(pNotify->nError == enLIVE_NO_ERROR)
		{
			m_bIsConnected = TRUE;
			
		}
		else
		{
			m_bIsConnected = FALSE;
			ClearBuffer();
			m_Decode.RemoveCallbackFunctionAll();
			m_NRS.ClearStream(m_sDeviceID.c_str());

		}

		TRACE("NCLIVE_STREAM_CONNECT : Error( %d )\n", pNotify->nError);
	}
	else if(pNotify->nMessage == LIVE_STREAM_DISCONNECT)
	{
		TRACE("NCLIVE_STREAM_DISCONNECT : Error( %d )\n", pNotify->nError);
		m_bIsConnecting = FALSE;
		m_bIsConnected = FALSE;

		ClearBuffer();
		m_Decode.RemoveCallbackFunctionAll();

		BOOL bNoDeviceStream = m_bNoDeviceStream;
		BOOL bIsConnectionStop	= m_bIsConnectionStop;

		m_NRS.ClearStream(m_sDeviceID.c_str());

		if(DevicePtr.get())
		{
			CString str;
			str.Format(_T("%s"), DevicePtr->GetName());
			TRACE(_T("Disconnect ~~~~ (%s)\n"), DevicePtr->GetName());
		}

		if(pNotify->nError != 0 && !bNoDeviceStream && bIsConnectionStop == FALSE)
		{
			TRACE(_T("������ ����Ȱ���~~~~ (%s)\n"), DevicePtr->GetName());
		}
	}
	else
	{
		TRACE(_T("CNRSStream::OnNotifyMessage �̻��� �޼���?\n"));
	}
}

void CNRSStream::OnReceive(LPStreamData Data)
{
	if(Data->Type == FRAME_XML)
	{
		TRACE("CNRSStream XML Recv: %s\n", (const char*)Data->pData);
		CXML xml;
		if(xml.LoadXMLFromString((const char*)Data->pData))
		{
			MSXML2::IXMLDOMNodePtr pRoot = xml.GetRootElementPtr();
			_bstr_t baseName = pRoot->GetbaseName();
			
			if(baseName == _bstr_t(L"StartRelayRes"))
			{
			        CString str;
			        str.Format(_T("//NRSError[@stream_id=\"%s\"]"), m_sDeviceID.c_str());
        
			        MSXML2::IXMLDOMNodePtr pNode = xml.FindNode( str );
			        if(pNode)
			        {
				        if(pNode->Gettext() == _bstr_t(_T("NoDeviceStreamInformation")))
					        m_bNoDeviceStream = TRUE;
				        else if(pNode->Gettext() == _bstr_t(_T("OK")))
						{
							m_bIsResponseRelay = TRUE;
					        m_bNoDeviceStream = FALSE;
						}
        
						std::tr1::shared_ptr<DEVICE_INFO> DevicePtr;
						if(GetGlobalConfig().GetDevice(DevicePtr, m_sDeviceID.c_str()))
							DevicePtr->SetNoDevice(m_bNoDeviceStream);
			        }

				m_bIsConnectionStop = FALSE;
			}
			else if(baseName == _bstr_t(L"ConnectionStop"))
			{
				// TODO:: ���󿬰� ����Ȱ����� �Ǵ�����..
				m_bIsConnectionStop = TRUE;
			}
		}
	}
	else if(Data->Type == FRAME_VIDEO_CODEC)
	{
		VIDEO_CODEC *pVideo = (VIDEO_CODEC*)Data->pData;
		switch(pVideo->type)
		{
		case VIDEO_MJPEG:
			m_VideoType	= AVMEDIA_JPEG;
			break;

		case VIDEO_MPEG4:
			m_VideoType	= AVMEDIA_MPEG4;
			break;

		case VIDEO_H264:
			m_VideoType	= AVMEDIA_H264;
			break;

		default:
			m_VideoType	= AVMEDIA_UNKNOWN;
			break;
		}

		m_VideoSize.cx	= pVideo->width;
		m_VideoSize.cy	= pVideo->height;

		if(pVideo->extra_size > 0)
		{
			m_VideoExtraData.Assign((const char*)Data->pData + sizeof(VIDEO_CODEC), pVideo->extra_size);

			// H.264�� ��� PPS, SPS
			//std::tr1::shared_ptr<NCStreamBuffer> p(new NCStreamBuffer(m_VideoExtraData.GetPtr(), m_VideoExtraData.GetSize()));	
			NCStreamBuffer *p = new NCStreamBuffer(m_VideoExtraData.GetPtr(), m_VideoExtraData.GetSize());
			CopyMemory(p->mac, m_Key, sizeof(p->mac));
			p->nLength		= m_VideoExtraData.GetSize();
			p->pBuffer		= (BYTE*) p->Buffer.GetPtr();
			p->nWidth		= m_VideoSize.cx;
			p->nHeight		= m_VideoSize.cy;
			p->br			= m_AudioBitRate;
			p->sr			= m_AudioSampleRate;
			p->mediaType	= m_VideoType;
			p->tReceived	= Data->tReceived;
			p->nFrameType	= CODED_SPS;
			p->bNoSkip			= TRUE;
			p->streamType		= INFO_STREAM_TYPE;

			Lock();
			m_Queue.push_back(p);
			GetThreadPool().AddWorkerFunction(_Work, this, m_nThreadId, m_nWorkKey);
			Unlock();
		}
	}
	else if(Data->Type == FRAME_AUDIO_CODEC)
	{
		AUDIO_CODEC *pAudio = (AUDIO_CODEC*)Data->pData;
		AVMEDIA_TYPE AudioType = AVMEDIA_UNKNOWN;
		switch(pAudio->type)
		{
		case AUDIO_PCM8:
		case AUDIO_PCM16:
			AudioType	= AVMEDIA_PCM;
			break;

		case AUDIO_G711U:
			AudioType	= AVMEDIA_PCMU;
			break;

		case AUDIO_G711A:
			AudioType	= AVMEDIA_PCMA;
			break;
			
		case AUDIO_G726:
			{
				if(pAudio->bit_rate == 16000)
					AudioType = AVMEDIA_G726_16;
				else if(pAudio->bit_rate == 24000)
					AudioType = AVMEDIA_G726_24;
				else if(pAudio->bit_rate == 32000)
					AudioType = AVMEDIA_G726_32;
				else if(pAudio->bit_rate == 40000)
					AudioType = AVMEDIA_G726_40;
				else
					AudioType = AVMEDIA_UNKNOWN;
			}
			break;

		case AUDIO_AAC:
			AudioType = AVMEDIA_AAC;
			break;

		default:
			AudioType = AVMEDIA_UNKNOWN;
			break;
		}

		if(m_AudioType != AudioType ||
			m_AudioBitRate != pAudio->bit_rate ||
			m_AudioSampleRate != pAudio->sample_rate)
		{
			m_AudioType			= AudioType;
	        m_AudioBitRate		= pAudio->bit_rate;
	        m_AudioSampleRate	= pAudio->sample_rate;
        
	        if(pAudio->extra_size)
		        m_AudioExtraData.Assign((const char*)Data->pData + sizeof(AUDIO_CODEC), pAudio->extra_size);

			if(m_bCaptureAudio)
			{
				//Audio Play()~~~
				//StopAudioCapture();
				//StartAudioCapture();
			}
		}
	}
	else if(Data->Type == FRAME_DATA)
	{
		FRAME_HEADER *pHeader = (FRAME_HEADER*)Data->pData;		
		AVMEDIA_TYPE MediaType = AVMEDIA_UNKNOWN;

		const char* pData = (const char*)Data->pData + sizeof(FRAME_HEADER);
		NCStreamBuffer *p = new NCStreamBuffer(pData, pHeader->frame_size);

		switch(pHeader->type)
		{
		case FRAME_UNKNOWN:
			return;

		case FRAME_VIDEO:
			MediaType	= m_VideoType;
			p->streamType = VIDEO_STREAM_TYPE;
			break;

		case FRAME_AUDIO:
			MediaType	= m_AudioType;
			p->streamType = AUDIO_STREAM_TYPE;
			if(m_AudioType == AVMEDIA_AAC)
			{
				p->pExtraData = (BYTE*) m_AudioExtraData.GetPtr();
				p->nExtraData = m_AudioExtraData.GetSize();
			}
			break;
			
		default:
			MediaType	= (AVMEDIA_TYPE) (AVMEDIA_NRS_META + pHeader->type);
			break;
		}

		CopyMemory(p->mac, m_Key, sizeof(p->mac));
		p->nLength		= pHeader->frame_size;
		p->pBuffer		= (BYTE*) p->Buffer.GetPtr();
		p->nWidth		= m_VideoSize.cx;
		p->nHeight		= m_VideoSize.cy;
		p->br			= m_AudioBitRate;
		p->sr			= m_AudioSampleRate;
		p->mediaType	= MediaType;
		p->tReceived	= Data->tReceived;
		if(pHeader->keyframe)
		{
			if(MediaType == AVMEDIA_H264)
				p->nFrameType	= CODED_IDR;
			else if(MediaType == AVMEDIA_MPEG4)
				p->nFrameType	= CODING_TYPE_INTRA;
			else if(MediaType == AVMEDIA_JPEG)
				p->nFrameType	= 0;
			else
				p->nFrameType = -1;

			Lock();
			if(!m_bFindFirstKey)
				m_bFindFirstKey = TRUE;
			Unlock();
		}

		Lock();
		if(m_bFindFirstKey || MediaType > AVMEDIA_NRS_META)
		{
			m_Queue.push_back(p);
		        GetThreadPool().AddWorkerFunction(_Work, this, m_nThreadId, m_nWorkKey);
		}
		else
			delete p;

		Unlock();

		time_t now = time(NULL);
		if(MediaType == AVMEDIA_H264 ||
			MediaType == AVMEDIA_MPEG4 ||
			MediaType == AVMEDIA_JPEG)
		{
			m_nVideoCount++;
			if(m_tVideo != now)
			{
#if 1
				m_fArVideoRate[ m_nArIndex++ % 3 ] = m_nVideoCount;
				if(m_fArVideoRate[0]>0 && m_fArVideoRate[1]>0 && m_fArVideoRate[2]>0)
					m_nVideoFrameRate = ((m_fArVideoRate[0] + m_fArVideoRate[1] + m_fArVideoRate[2]) + 0.5) / 3;
#else
				m_nVideoFrameRate = m_nVideoCount;
#endif
				m_tVideo = now;
				m_nVideoCount = 0;
			}
		}
		else
		{
			m_nAudioCount++;
			if(m_tAudio != now)
			{
				m_tAudio = now;
				m_nAudioCount = 0;
			}
		}

	}
}

void __stdcall CNRSStream::_Work(void* arg, size_t key)
{
	CNRSStream* p = (CNRSStream*)arg;

	InterlockedExchange(&p->m_lRunWorker, 1);
	p->Work(key);
	InterlockedExchange(&p->m_lRunWorker, 0);
}

void CNRSStream::Work(size_t key)
{
	Lock();
	if(m_Queue.empty())
	{
		Unlock();
		return;
	}

	NCStreamBuffer *p = m_Queue.front();

#if 0	// test �� ����
	if(m_bEnableVideoSync && 
		(p->mediaType == AVMEDIA_H264 || p->mediaType == AVMEDIA_MPEG4 || p->mediaType == AVMEDIA_JPEG)
		)
	{
		if(m_nVideoFrameRate > 0)
		{
			clock_t tt = clock();
			DWORD fr = (1000 / m_nVideoFrameRate);
			DWORD tick = tt - m_tVideoClock;

			if(fr > tick)
			{
				//TRACE("fr: %d, tick: %d\n", fr,tick);
				m_tVideoClock -= 1;
				Sleep(0);
				GetThreadPool().AddWorkerFunction(_Work, this, m_nThreadId, m_nWorkKey);

				Unlock();
				return;
			}
			m_tVideoClock = tt;
		}
	}
#endif

	m_Queue.pop_front();
	Unlock();

	if(m_bMetaOnly && (p->mediaType < AVMEDIA_NRS_META))
	{
		delete p;
		return;
	}

	struct __timeb64 tReceived;
	_ftime64_s(&tReceived);

	p->tReceivedTime = p->tReceived.time;

	if(p->bNoSkip == FALSE && (tReceived.time - 2 > p->tReceived.time))
	{
		TRACE("��Ŷ �ð� �ʰ� (%s)\n", m_sDecodeKey.c_str());
		ClearBuffer();
		m_Decode.Restore();
		
		delete p;
		return;
	}

	if(p->mediaType > AVMEDIA_NRS_META)
	{
		/*
		�̺�Ʈ ���� : 
		�̺�Ʈ�� 1�ʿ� �ѹ� �� ����´�. �̺�Ʈ�� �߻�������.
		�̺�Ʈ�� �߻����� �ʴ´ٸ� ���̻� �̺�Ʈ�� ������� �ʴ´�.
		���⼭ 1�� ������ �ش� �̺�Ʈ�� ������Ʈ �Ǿ����� Ȯ��. �̺�Ʈ�� ���ٸ� �̺�Ʈ�� ���� ������ �Ѵ�.
		
		Event ȯ�漳�� ����
		1. Dwell Time�� Event ���� �������� �����Ͽ� �ð��� �����Ѵ�.
		2. Event View, Layout ó���� Dwell Time ���� ������ ��������, ���Ŀ� ��������� ó���Ѵ�.
		3. Event Dwell Time �������� 5���̳��� �ٸ� ��ġ���� Event�� �߻��ϸ� ������ �������� �������� ó���� ���� �ʵ��� �Ѵ�.
		4. Dwell Time �������� 5���Ŀ� �ٸ� ��ġ���� Event�� �߻��ϸ� ���� �������� �������� �ش� Event�� ó���ϵ��� �Ѵ�.
		5. Dwell Time�� ���� ����, ���� Event�� ��� �߻��ϸ� ���ο� Event�� ó���ϵ��� �Ѵ�.
		*/

		// �̺�Ʈ ����ü�� �ݵ�� 4Byte ���� �̾�߸� �Ѵ�!!!
		NTOH32((int*)p->Buffer.GetPtr(), p->Buffer.GetSize());

		// �̺�Ʈ ó��
		NRS::FRAME_TYPE frameType = (NRS::FRAME_TYPE) (p->mediaType - AVMEDIA_NRS_META);

		//GetEventManager()->AddEvent(frameType, m_sDeviceID.c_str(), tReceived, p->Buffer.GetPtr());

		BOOL bEventOn = FALSE;
		if(frameType == NRS::FRAME_META_ALARMIN)
		{
			// �˶� �߻�
			FRAME_ALARMIN* alarm = (FRAME_ALARMIN*)p->Buffer.GetPtr();
			m_EventUpdate.tAlarmUpdated = tReceived;

			if(!m_EventUpdate.bAlarm)
			{
				m_EventUpdate.bAlarm = TRUE;
				m_MetaFrame.alarm = *alarm;

				//GetEventManager()->AddEventLog(frameType, m_sDeviceID.c_str(), tReceived, TRUE);
				bEventOn = TRUE;
			}
		}
		else if(frameType == NRS::FRAME_META_MOTION)
		{
			// ��� �߻�
			FRAME_MOTION* motion = (FRAME_MOTION*)p->Buffer.GetPtr();
			m_EventUpdate.tMotionUpdated = tReceived;

			if(!m_EventUpdate.bMotion)
			{
				m_EventUpdate.bMotion = TRUE;
				m_MetaFrame.motion = *motion;

				//GetEventManager()->AddEventLog(frameType, m_sDeviceID.c_str(), tReceived, TRUE);
				bEventOn = TRUE;
			}
		}
		else if(frameType == NRS::FRAME_META_TRIGGER)
		{
			FRAME_TRIGGER* trigger = (FRAME_TRIGGER*)p->Buffer.GetPtr();
			m_EventUpdate.tTriggerUpdated = tReceived;

			if(!m_EventUpdate.bTrigger)
			{
				m_EventUpdate.bTrigger = TRUE;
				m_MetaFrame.trigger = *trigger;

				//GetEventManager()->AddEventLog(frameType, m_sDeviceID.c_str(), tReceived, TRUE);
				bEventOn = TRUE;
			}
		}

		if(bEventOn)
		{
			// TODO:: Record ������ ���߿�, ���� ���ɶ��� EventManager�� �ű� �� �� ����.
			
			//std::tr1::shared_ptr<DEVICE_INFO> DevicePtr;
			//if(GetGlobalConfig().GetDevice( DevicePtr, m_sDeviceID.c_str() ))
			//	DevicePtr->SetDeviceStatus( ITEM_EVENT );
		}

		SetNRSEvent(frameType, &m_MetaFrame);

	}
	else if(p)
		m_Decode.Process(p, m_nVideoFilter);

	
	delete p;
}

void CNRSStream::CheckEventStatus(__timeb64& tReceived)
{
	m_tLastUpdate = tReceived;

	int frType = NRS::FRAME_UNKNOWN;
	BOOL bChangedEvent = FALSE;

	if(m_EventUpdate.TimeLag(&m_EventUpdate.tAlarmUpdated, &m_tLastUpdate, 2000))
	{
		// �˶� ����
		if(m_EventUpdate.bAlarm)
	        {
			m_EventUpdate.bAlarm = FALSE;
			frType |= NRS::FRAME_META_ALARMIN;

			//GetEventManager()->AddEventLog(NRS::FRAME_META_ALARMIN, m_sDeviceID.c_str(), tReceived, FALSE);

			bChangedEvent = TRUE;
		}
	}
	if(m_EventUpdate.TimeLag(&m_EventUpdate.tMotionUpdated, &m_tLastUpdate, 2000))
	{
		// ��� ����
		if(m_EventUpdate.bMotion)
		{
			m_EventUpdate.bMotion = FALSE;
			frType |= NRS::FRAME_META_MOTION;

			//GetEventManager()->AddEventLog(NRS::FRAME_META_MOTION, m_sDeviceID.c_str(), tReceived, FALSE);

			bChangedEvent = TRUE;
		}
	}
	if(m_EventUpdate.TimeLag(&m_EventUpdate.tTriggerUpdated, &m_tLastUpdate, 2000))
	{
		// Ʈ���� ����
		if(m_EventUpdate.bTrigger)
		{
			m_EventUpdate.bTrigger = FALSE;
			frType |= NRS::FRAME_META_TRIGGER;

			//GetEventManager()->AddEventLog(NRS::FRAME_META_TRIGGER, m_sDeviceID.c_str(), tReceived, FALSE);

			bChangedEvent = TRUE;
		}
	}

	if(bChangedEvent)
	{
		// �̺�Ʈ ������ �Ǿ���, �˶�, ��� �Ѵ� ���� ���, (TODO:: �ٸ� �̺�Ʈ-������ �� ���߿�...)
		if(!m_EventUpdate.bAlarm && !m_EventUpdate.bMotion && !m_EventUpdate.bTrigger)
		{
			// TODO:: Record���û����� ���߿�..
			//std::tr1::shared_ptr<DEVICE_INFO> DevicePtr;
			//if(GetGlobalConfig().GetDevice( DevicePtr, m_sDeviceID.c_str() ))
			//	DevicePtr->SetDeviceStatus( ITEM_ENABLED );
		}
	}

	if(frType != NRS::FRAME_UNKNOWN)
		SetNRSEvent((NRS::FRAME_TYPE) frType, NULL);
}

void CNRSStream::SetHandle(void* pStreamHandle)
{
	m_pHandle = pStreamHandle;
}

void* CNRSStream::GetHandle()
{
	return m_pHandle;
}

int CNRSStream::Reconnect()
{
	if(m_pHandle)
	{
		Live5_DisconnectStream(GetNRSHandle(), m_nId, m_pHandle);
		m_pHandle = NULL;
	}
	ClearBuffer();

	std::tr1::shared_ptr<DEVICE_INFO> DevicePtr;
	if(!GetGlobalConfig().GetDevice(DevicePtr, m_sDeviceID.c_str()))
		return -1;

	if(!IsCameraDevice(DevicePtr->GetDeviceType()))
		return -1;

	CString strXML;
	strXML.Format(_T("%s<StartRelayReq req_id=\"%s\">") \
		_T("<ClientID>%d</ClientID>") \
		_T("<DeviceStream><MAC>%s</MAC><Profile>%s</Profile></DeviceStream>") \
		_T("<Type>%d</Type>") \
		_T("</StartRelayReq>"),

		XML_UTF8_HEAD_WSTR,
		GetGlobalConfig().GetGUIDW(),
		m_NRS.GetClientID(),
		DevicePtr->GetMAC(),
		DevicePtr->GetProfileName(),
		m_dwStreamFlags
		);

	std::string utf8 = __WTOUTF8(strXML);
	void* stream = Live5_ConnectStream(GetNRSHandle(), m_NRS.m_nId, utf8.c_str(), this);
	if(stream == NULL)
	{
		// ���� �����ε�...
	}

	m_pHandle = stream;

	return NO_ERROR;
}

void CNRSStream::Disconnect()
{
	if(m_pHandle)
	{
		Live5_DisconnectStream(GetNRSHandle(), m_nId, m_pHandle);
		m_pHandle = NULL;
	}

	ClearBuffer();
	m_Decode.Restore();
	m_Decode.RemoveCallbackFunctionAll();
}

size_t CNRSStream::GetDisplayCount()
{
	return m_Decode.GetDisplayCount(m_sDecodeKey.c_str());
}

SIZE CNRSStream::GetVideoSize() const
{
	return m_VideoSize;
}

void CNRSStream::EnableDecodeAudio(BOOL bEnable)
{
	m_Decode.SetDecodeAudio(bEnable);
}

BOOL CNRSStream::IsDecodeAudio()
{
	return m_Decode.IsDecodeAudio();
}

void CNRSStream::Lock()
{
	EnterCriticalSection(&m_cs);
}

void CNRSStream::TryLock()
{
	while(!TryEnterCriticalSection(&m_cs))
	{
		APP_PUMP_MESSAGE(NULL, 0, 0);
		Sleep(1);
	}
}

void CNRSStream::Unlock()
{
	LeaveCriticalSection(&m_cs);
}

void CNRSStream::Lock2()
{
	EnterCriticalSection(&m_cs2);
}

void CNRSStream::TryLock2()
{
	while(!TryEnterCriticalSection(&m_cs2))
	{
		APP_PUMP_MESSAGE(NULL, 0, 0);
		Sleep(1);
	}
}
		
void CNRSStream::Unlock2()
{
	LeaveCriticalSection(&m_cs2);
}

#if 0
void CNRSStream::AddDisplayWindow(CDisplayBase* pDisplayWnd)
{
	TryLock2();
	m_DisplaySet.insert(pDisplayWnd);
	Unlock2();
}

void CNRSStream::RemoveDisplayWindow(CDisplayBase* pDisplayWnd)
{
	TryLock2();
	m_DisplaySet.erase(pDisplayWnd);
	Unlock2();
}
#endif

void CNRSStream::GetCaptureAudio(char *pData, unsigned long lDataLen, LPVOID arg)
{
	char	*pIn	= pData;
	size_t	nIn		= lDataLen;
	char	*pOut	= NULL;
	size_t	nOut	= 0;
	
	if(m_pHandle == NULL)
		return;

	if(m_Encoder.IsOpendAudio())
	{
		if(m_Encoder.EncodeAudio(pIn, nIn, pOut, nOut))
		{
			Live5_SendDataStream(GetNRSHandle(), m_NRS.m_nId, m_pHandle, FRAME_BINARY, pOut, nOut);
		}
	}
}

void CNRSStream::GetAudioInfo(AVMEDIA_TYPE &AudioType, int &nBitrate, int &nSampleRate)
{
	//StopAudioCapture();

	AudioType	= m_AudioType;
	nBitrate	= m_AudioBitRate;
	nSampleRate	= m_AudioSampleRate;

}

BOOL CNRSStream::StartAudioCapture()
{
	if(m_AudioType == AVMEDIA_UNKNOWN)
		return FALSE;

	DWORD dwCaptureSamples = 640;
	switch(m_AudioType)
	{
	case AVMEDIA_PCM:
		dwCaptureSamples = 1300;
		break;

	case AVMEDIA_PCMU:
	case AVMEDIA_PCMA:
		dwCaptureSamples = 512;
		break;

	case AVMEDIA_G726_16:
	case AVMEDIA_G726_24:
	case AVMEDIA_G726_32:
	case AVMEDIA_G726_40:
		dwCaptureSamples = 512;
		break;

	case AVMEDIA_AAC:
		// AAC�� ���� �������� ����.
		return FALSE;
		break;
	}

	//m_pAudioCapture = new CAudioCapture;
	//if(!m_pAudioCapture->Init(m_AudioSampleRate, 16, 1, dwCaptureSamples, this))
	//	return FALSE;

	m_Encoder.OpenAudio(m_AudioType, m_AudioSampleRate, m_AudioBitRate);

	//m_pAudioCapture->Start();

	m_bCaptureAudio = TRUE;

	return TRUE;
}

void CNRSStream::StopAudioCapture()
{
//	if(m_pAudioCapture)
//	{
// 		m_pAudioCapture->Stop();
// 		m_pAudioCapture->Destroy();
// 		delete m_pAudioCapture;
// 		m_pAudioCapture = NULL;
// 	}
	m_Encoder.CloseAudio();

	m_bCaptureAudio = FALSE;
}

void CNRSStream::SetVideoFilter(UINT nFilter /*= 0*/)
{
	m_nVideoFilter = nFilter;
}

UINT CNRSStream::GetVideoFilter() const
{
	return m_nVideoFilter;
}

void CNRSStream::SetNRSEvent(NRS::FRAME_TYPE FrameType, NRS::MetaFrameUnion* pFrame, BOOL bUpdateNow /*= FALSE*/)
{
#if 0
	CScopeLock lock2(&m_cs2);
	for(set<CDisplayBase*>::iterator pos = m_DisplaySet.begin();
		pos != m_DisplaySet.end(); pos++)
		(*pos)->SetNRSEvent(m_sDeviceID.c_str(), FrameType, pFrame, bUpdateNow);
#endif
}