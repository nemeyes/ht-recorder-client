// DlgCameraInfo.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "LGcnsSample.h"
#include "DlgLGcnsSample.h"
#include "DlgCameraInfo.h"
#include "HTTPRequest.h"
#include "string_helper.h"

using namespace std;
// CDlgCameraInfo ��ȭ �����Դϴ�.
static const UINT MENUID_CMD_SETRESTART	= 5000;
static const UINT MENUID_CMD_SETRESET		= 5001;
static const UINT MENUID_CMD_SETDEFAULT	= 5002;
static const UINT MENUID_CMD_SETDELETE	= 5003;
static const UINT MENUID_CMD_SETUPDATE	= 5004;

const UINT UM_CHANGE_BTN_INIT = RegisterWindowMessage(L"UM_CHANGE_BTN_INIT");
const UINT UM_CHANGE_LIST_STATUS = RegisterWindowMessage(L"UM_CHANGE_LIST_STATUS");

#define LIST_STATUS_SEL    (6)

IMPLEMENT_DYNAMIC(CDlgCameraInfo, CDialog)

CDlgCameraInfo::CDlgCameraInfo(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgCameraInfo::IDD, pParent)
{
	
	m_pDlgCat = (CDlgLGcnsSample *)pParent;

	m_hThreadAllCmd = NULL;
	m_acCmd = CMD_INIT;
	m_strFwFileName = _T("");
	m_nSelectedDevice = -1;
	//m_bStartAllCmd = FALSE;
}

CDlgCameraInfo::~CDlgCameraInfo()
{
}

void CDlgCameraInfo::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST_CAMERA_CONFIG, m_listCamList);
	//DDX_Control(pDX, IDC_LISTBOX_LOG, m_listLog);
}


BEGIN_MESSAGE_MAP(CDlgCameraInfo, CDialog)
	ON_NOTIFY(NM_RCLICK, IDC_LIST_CAMERA_CONFIG, &CDlgCameraInfo::OnNMRClickListCameraConfig)
	ON_BN_CLICKED(IDC_BTN_ALL_RESTART, &CDlgCameraInfo::OnBnClickedBtnAllRestart)
	ON_BN_CLICKED(IDC_BTN_ALL_RESET, &CDlgCameraInfo::OnBnClickedBtnAllReset)
	ON_BN_CLICKED(IDC_BTN_ALL_DEFAULT, &CDlgCameraInfo::OnBnClickedBtnAllDefault)
	ON_BN_CLICKED(IDC_BTN_ALL_DELETE, &CDlgCameraInfo::OnBnClickedBtnAllDelete)
	ON_BN_CLICKED(IDC_BTN_ALL_FW_UPDATE, &CDlgCameraInfo::OnBnClickedBtnAllFwUpdate)
	ON_BN_CLICKED(IDC_BTN_ALL_REFRESH, &CDlgCameraInfo::OnBnClickedBtnAllRefresh)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BTN_ALL_CMD_STOP, &CDlgCameraInfo::OnBnClickedBtnAllCmdStop)
	ON_REGISTERED_MESSAGE(UM_CHANGE_BTN_INIT, OnChangeBtnInit)
	ON_REGISTERED_MESSAGE(UM_CHANGE_LIST_STATUS, OnChangeListStatus)
	ON_BN_CLICKED(IDOK, &CDlgCameraInfo::OnBnClickedOk)
	ON_NOTIFY(NM_CLICK, IDC_LIST_CAMERA_CONFIG, &CDlgCameraInfo::OnNMClickListCameraConfig)
END_MESSAGE_MAP()


// CDlgCameraInfo �޽��� ó�����Դϴ�.

BOOL CDlgCameraInfo::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	InitializeCriticalSection(&m_cs);

	m_listCamList.SetExtendedStyle(LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);

	m_listCamList.InsertColumn(0, _T("No."), LVCFMT_LEFT, 35);
	m_listCamList.InsertColumn(1, _T("Model"), LVCFMT_LEFT, 140);
	m_listCamList.InsertColumn(2, _T("IP Address"), LVCFMT_LEFT, 140);
	m_listCamList.InsertColumn(3, _T("ZenoConf IP"), LVCFMT_LEFT, 140);
	m_listCamList.InsertColumn(4, _T("MAC Address"), LVCFMT_LEFT, 140);
	m_listCamList.InsertColumn(5, _T("F/W Version"), LVCFMT_LEFT, 140);
	//m_listCamList.InsertColumn(6, _T("Resolution"), LVCFMT_LEFT, 120);
	m_listCamList.InsertColumn(LIST_STATUS_SEL, _T("Status"), LVCFMT_LEFT, 120);

	
	CString strIdx = _T("");
	for(int i=0; i<MAX_LIVE_CHANNEL; i++){
		strIdx.Format(L"%d", i+1);
		m_listCamList.InsertItem(i, strIdx, 0);
		m_listCamList.SetItemText(i, 1, m_pDlgCat->m_ciCommInfo[i].strModelName);
		m_listCamList.SetItemText(i, 2, m_pDlgCat->m_ciCommInfo[i].strIp);
		m_listCamList.SetItemText(i, 3, m_pDlgCat->m_ciCommInfo[i].strZeroConfIp);
		m_listCamList.SetItemText(i, 4, m_pDlgCat->m_ciCommInfo[i].strMac);
		m_listCamList.SetItemText(i, 5, m_pDlgCat->m_ciCommInfo[i].strFwVersion);
		//m_listCamList.SetItemText(i, 6, m_pDlgCat->m_ciCommInfo[i].strResolution);
		m_listCamList.SetItemText(i, LIST_STATUS_SEL, _T(""));
	}

	m_pDlgCat->SetDlgCamInfo(this);

	GetDlgItem(IDC_BTN_ALL_CMD_STOP)->EnableWindow(FALSE);
		 	
	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CDlgCameraInfo::OnDestroy()
{
	CDialog::OnDestroy();

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	DeleteCriticalSection(&m_cs);

	if(m_acCmd != CMD_INIT){  
		m_acCmd = CMD_INIT;   
		MSG msg;

		while(m_hThreadAllCmd != NULL){
			while(::PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
			{
				TranslateMessage(&msg);
				DispatchMessage(&msg);
			}
		}
	}
}


void CDlgCameraInfo::OnNMRClickListCameraConfig(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	//if(m_hThreadAllCmd) return;   // ��ü �����尡 ���ư��� ������ ���� ������ �ȵǰ�....
	
	CString strModelname = m_listCamList.GetItemText(pNMItemActivate->iItem, 1);

	if(strModelname == _T("")) return;
	
	CMenu menu;
	if(pNMItemActivate->iItem > -1 && menu.CreatePopupMenu())
	{
		POINT pt = pNMItemActivate->ptAction;
		m_listCamList.ClientToScreen(&pt);
		menu.AppendMenuW(MF_SEPARATOR);
		menu.AppendMenuW(MF_STRING | MF_ENABLED, MENUID_CMD_SETRESTART, _T("Restart"));
		menu.AppendMenuW(MF_STRING | MF_ENABLED, MENUID_CMD_SETRESET, _T("Reset"));
		menu.AppendMenuW(MF_STRING | MF_ENABLED, MENUID_CMD_SETDEFAULT, _T("Default"));
		menu.AppendMenuW(MF_SEPARATOR);
		menu.AppendMenuW(MF_STRING | MF_ENABLED, MENUID_CMD_SETDELETE, _T("Delete"));
		menu.AppendMenuW(MF_SEPARATOR);
		menu.AppendMenuW(MF_STRING | MF_ENABLED, MENUID_CMD_SETUPDATE, _T("F/W Update"));

		menu.TrackPopupMenu(TPM_LEFTALIGN, pt.x, pt.y, this);
		menu.DestroyMenu();

	}

	*pResult = 0;
}

static UINT WINAPI AllCmdThread(LPVOID pParam)
{
	((CDlgCameraInfo *)pParam)->AllCmd();

	return 0;
}

BOOL CDlgCameraInfo::OnCommand(WPARAM wParam, LPARAM lParam)
{
	WORD wID = LOWORD(wParam);
	WORD wMsg = HIWORD(wParam);
	
	switch(wMsg)
	{
	case BN_CLICKED :
		HWND hWnd = (HWND)lParam;
		if(hWnd == NULL)
		{
			
			int nItem = m_listCamList.GetSelectionMark();
			
			switch(wID)
			{
			case MENUID_CMD_SETRESTART :
				{
					if(!m_pDlgCat->GetStartStatus()) return FALSE;
					//if(m_hThreadAllCmd) return;
					if(m_hThreadAllCmd){
						AfxMessageBox(L"���� ������ �Դϴ�.", MB_OK | MB_ICONWARNING);

						return FALSE;
					}

					m_nSelectedDevice = m_listCamList.GetSelectionMark();

					m_acCmd = CMD_RESTART;

					OnBnClickedBtnAllRefresh();

					if(m_hThreadAllCmd == NULL){
						UINT dwThread;
						m_hThreadAllCmd = (HANDLE)_beginthreadex(NULL, 0, AllCmdThread, this, 0, &dwThread);
					}
					/*
					if(nItem > -1)
					{
						CHTTPRequest http;
						if(!http.SendRequest(m_pDlgCat->m_ciCommInfo[nItem].strZeroConfIp, _T("/system/restart.php?app=set"), m_pDlgCat->m_ciCommInfo[nItem].nHttpPort, NULL, 0, CHTTPRequest::HTTP_GET,
							_T("admin"), _T("admin"), 0, 7000)){
								m_listCamList.SetItemText(nItem, LIST_STATUS_SEL, _T("Restart ����"));
								CString strLog = _T("");
								strLog.Format(L"%s(%s) ��ġ�� Restart�� ���� �Ͽ����ϴ�.", m_pDlgCat->m_ciCommInfo[nItem].strModelName, m_pDlgCat->m_ciCommInfo[nItem].strMac);
								m_pDlgCat->WriteLog(strLog, RGB(255, 0, 0));
						}
						if(http.GetResponseCode() != 200){	
							m_listCamList.SetItemText(nItem, LIST_STATUS_SEL, _T("Restart ����"));
							CString strLog = _T("");
							strLog.Format(L"%s(%s) ��ġ�� Restart�� ���� �Ͽ����ϴ�.", m_pDlgCat->m_ciCommInfo[nItem].strModelName, m_pDlgCat->m_ciCommInfo[nItem].strMac);
							m_pDlgCat->WriteLog(strLog, RGB(255, 0, 0));
						} else {
							m_listCamList.SetItemText(nItem, LIST_STATUS_SEL, _T("Restart ����"));
							CString strLog = _T("");
							strLog.Format(L"%s(%s) ��ġ�� Restart�� ���� �Ͽ����ϴ�.", m_pDlgCat->m_ciCommInfo[nItem].strModelName, m_pDlgCat->m_ciCommInfo[nItem].strMac);
							m_pDlgCat->WriteLog(strLog, RGB(0, 0, 0));
						}
					}
					*/
				}
				break;
			case MENUID_CMD_SETRESET :
				{
					if(!m_pDlgCat->GetStartStatus()) return FALSE;
					//	if(m_hThreadAllCmd) return;
					if(m_hThreadAllCmd){
						AfxMessageBox(L"���� ������ �Դϴ�.", MB_OK | MB_ICONWARNING);

						return FALSE;
					}

					m_nSelectedDevice = m_listCamList.GetSelectionMark();

					m_acCmd = CMD_RESET;

					OnBnClickedBtnAllRefresh();

					if(m_hThreadAllCmd == NULL){
						UINT dwThread;
						m_hThreadAllCmd = (HANDLE)_beginthreadex(NULL, 0, AllCmdThread, this, 0, &dwThread);
					}
					/*
					if(nItem > -1)
					{
						CHTTPRequest http;
						if(!http.SendRequest(m_pDlgCat->m_ciCommInfo[nItem].strZeroConfIp, _T("/system/reset.php?app=set"), m_pDlgCat->m_ciCommInfo[nItem].nHttpPort, NULL, 0, CHTTPRequest::HTTP_GET,
							_T("admin"), _T("admin"), 0, 7000)){
								m_listCamList.SetItemText(nItem, LIST_STATUS_SEL, _T("Reset ����"));
								CString strLog = _T("");
								strLog.Format(L"%s(%s) ��ġ�� Reset�� ���� �Ͽ����ϴ�.", m_pDlgCat->m_ciCommInfo[nItem].strModelName, m_pDlgCat->m_ciCommInfo[nItem].strMac);
								m_pDlgCat->WriteLog(strLog, RGB(255, 0, 0));
						}
						if(http.GetResponseCode() != 200){	
							m_listCamList.SetItemText(nItem, LIST_STATUS_SEL, _T("Reset ����"));
							CString strLog = _T("");
							strLog.Format(L"%s(%s) ��ġ�� Reset�� ���� �Ͽ����ϴ�.", m_pDlgCat->m_ciCommInfo[nItem].strModelName, m_pDlgCat->m_ciCommInfo[nItem].strMac);
							m_pDlgCat->WriteLog(strLog, RGB(255, 0, 0));
						} else {
							m_listCamList.SetItemText(nItem, LIST_STATUS_SEL, _T("Reset ����"));
							CString strLog = _T("");
							strLog.Format(L"%s(%s) ��ġ�� Reset�� ���� �Ͽ����ϴ�.", m_pDlgCat->m_ciCommInfo[nItem].strModelName, m_pDlgCat->m_ciCommInfo[nItem].strMac);
							m_pDlgCat->WriteLog(strLog, RGB(0, 0, 0));
						}
					}
					*/
				}
				break;
			case MENUID_CMD_SETDEFAULT :	
				{
					if(!m_pDlgCat->GetStartStatus()) return FALSE;
					//	if(m_hThreadAllCmd) return;
					if(m_hThreadAllCmd){
						AfxMessageBox(L"���� ������ �Դϴ�.", MB_OK | MB_ICONWARNING);

						return FALSE;
					}

					m_nSelectedDevice = m_listCamList.GetSelectionMark();

					m_acCmd = CMD_DEFAULT;

					OnBnClickedBtnAllRefresh();

					if(m_hThreadAllCmd == NULL){
						UINT dwThread;
						m_hThreadAllCmd = (HANDLE)_beginthreadex(NULL, 0, AllCmdThread, this, 0, &dwThread);
					}
					/*
					if(nItem > -1)
					{
						CHTTPRequest http;
						if(!http.SendRequest(m_pDlgCat->m_ciCommInfo[nItem].strZeroConfIp, _T("/system/default.php?app=set"), m_pDlgCat->m_ciCommInfo[nItem].nHttpPort, NULL, 0, CHTTPRequest::HTTP_GET,
							_T("admin"), _T("admin"), 0, 7000)){
								m_listCamList.SetItemText(nItem, LIST_STATUS_SEL, _T("Default ����"));
								CString strLog = _T("");
								strLog.Format(L"%s(%s) ��ġ�� Default�� ���� �Ͽ����ϴ�.", m_pDlgCat->m_ciCommInfo[nItem].strModelName, m_pDlgCat->m_ciCommInfo[nItem].strMac);
								m_pDlgCat->WriteLog(strLog, RGB(255, 0, 0));
						}
						if(http.GetResponseCode() != 200){	
							m_listCamList.SetItemText(nItem, LIST_STATUS_SEL, _T("Default ����"));
							CString strLog = _T("");
							strLog.Format(L"%s(%s) ��ġ�� Default�� ���� �Ͽ����ϴ�.", m_pDlgCat->m_ciCommInfo[nItem].strModelName, m_pDlgCat->m_ciCommInfo[nItem].strMac);
							m_pDlgCat->WriteLog(strLog, RGB(255, 0, 0));
						} else {
							m_listCamList.SetItemText(nItem, LIST_STATUS_SEL, _T("Default ����"));
							CString strLog = _T("");
							strLog.Format(L"%s(%s) ��ġ�� Default�� ���� �Ͽ����ϴ�.", m_pDlgCat->m_ciCommInfo[nItem].strModelName, m_pDlgCat->m_ciCommInfo[nItem].strMac);
							m_pDlgCat->WriteLog(strLog, RGB(0, 0, 0));
						}
					}
					*/
				}
				break;
			case MENUID_CMD_SETDELETE :	
				{
					CString strLog = _T("");
					strLog.Format(L"%s(%s) ��ġ�� ���� �Ǿ����ϴ�.", m_pDlgCat->m_ciCommInfo[nItem].strModelName, m_pDlgCat->m_ciCommInfo[nItem].strMac);
					m_pDlgCat->WriteLog(strLog, RGB(0, 0, 255));

					m_pDlgCat->LiveDisConnection(nItem);
					m_pDlgCat->m_pLive1Disp->ClearVideo(nItem);
					m_pDlgCat->InitCommonInfo(nItem);
					m_pDlgCat->DeleteLiveStream(nItem);
					//OnBnClickedBtnAllRefresh();
					//m_listCamList.DeleteItem(nItem);
				}
				break;
			case MENUID_CMD_SETUPDATE :	
				{
					if(!m_pDlgCat->GetStartStatus()) return FALSE;
					//if(m_hThreadAllCmd) return FALSE;
					if(m_hThreadAllCmd){
						AfxMessageBox(L"���� ������ �Դϴ�.", MB_OK | MB_ICONWARNING);

						return FALSE;
					}

					TCHAR Filter[] = _T("Firmware files (*.bin;*.cab;*.img)|*.bin;*.cab;*.img|All files (*.*)|*.*|");
					CFileDialog Dlg(TRUE, NULL, NULL,
						OFN_HIDEREADONLY | OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST, Filter);
					if (Dlg.DoModal() != IDOK)
						return FALSE;

					CString strFWFileName = Dlg.GetPathName();
					if (strFWFileName.IsEmpty())
						return FALSE;

					m_strFwFileName.Format(L"%s", strFWFileName);
					m_nSelectedDevice = m_listCamList.GetSelectionMark();

					m_acCmd = CMD_UPDATTE;

					OnBnClickedBtnAllRefresh();

					if(m_hThreadAllCmd == NULL){
						UINT dwThread;
						m_hThreadAllCmd = (HANDLE)_beginthreadex(NULL, 0, AllCmdThread, this, 0, &dwThread);
					}
					/*
					if(nItem > -1)
					{
						TCHAR Filter[] = _T("Firmware files (*.bin;*.cab;*.img)|*.bin;*.cab;*.img|All files (*.*)|*.*|");
						CFileDialog Dlg(TRUE, NULL, NULL,
							OFN_HIDEREADONLY | OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST, Filter);
						if (Dlg.DoModal() != IDOK)
							return FALSE;

						CString strFWFileName = Dlg.GetPathName();
						if (strFWFileName.IsEmpty())
							return FALSE;

						CHTTPRequest http;
						http.InitUpload();
						http.AddUploadData(_T("fimage"), strFWFileName, FALSE);
						if(http.UploadProc(GetSafeHwnd(), m_pDlgCat->m_ciCommInfo[nItem].strZeroConfIp,  _T("/system/update.php?app=set"),
							m_pDlgCat->m_ciCommInfo[nItem].nHttpPort, L"admin", L"admin")){
								CString strResponse = UTF8ToWString(http.GetResponse()).c_str();

								if (strResponse.Find(_T("res=200")) >= 0){
									m_listCamList.SetItemText(nItem, LIST_STATUS_SEL, _T("Update ����"));
									CString strLog = _T("");
									strLog.Format(L"%s(%s) ��ġ�� Update�� ���� �Ͽ����ϴ�.", m_pDlgCat->m_ciCommInfo[nItem].strModelName, m_pDlgCat->m_ciCommInfo[nItem].strMac);
									m_pDlgCat->WriteLog(strLog, RGB(0, 0, 0));
								} else {
									m_listCamList.SetItemText(nItem, LIST_STATUS_SEL, _T("Update ����"));
									CString strLog = _T("");
									strLog.Format(L"%s(%s) ��ġ�� Update�� ���� �Ͽ����ϴ�.", m_pDlgCat->m_ciCommInfo[nItem].strModelName, m_pDlgCat->m_ciCommInfo[nItem].strMac);
									m_pDlgCat->WriteLog(strLog, RGB(255, 0, 0));
								}
						} else {
							m_listCamList.SetItemText(nItem, LIST_STATUS_SEL, _T("Update ����"));
							CString strLog = _T("");
							strLog.Format(L"%s(%s) ��ġ�� Update�� ���� �Ͽ����ϴ�.", m_pDlgCat->m_ciCommInfo[nItem].strModelName, m_pDlgCat->m_ciCommInfo[nItem].strMac);
							m_pDlgCat->WriteLog(strLog, RGB(255, 0, 0));
						}
					}
					*/
				}
				break;
			}
		}
		break;
	}
	return CDialog::OnCommand(wParam, lParam);
}

void CDlgCameraInfo::OnBnClickedBtnAllRestart()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	//m_bStartAllCmd = TRUE;
	if(!m_pDlgCat->GetStartStatus()) return;
	//if(m_hThreadAllCmd) return;
	if(m_hThreadAllCmd){
		AfxMessageBox(L"���� ������ �Դϴ�.", MB_OK | MB_ICONWARNING);

		return;
	}
	
	m_acCmd = CMD_RESTART;
	
	OnBnClickedBtnAllRefresh();

	if(m_hThreadAllCmd == NULL){
		UINT dwThread;
		m_hThreadAllCmd = (HANDLE)_beginthreadex(NULL, 0, AllCmdThread, this, 0, &dwThread);
	}

	m_pDlgCat->WriteLog(L"��ü Restart ������ �����մϴ�.", RGB(0, 0, 0));

	GetDlgItem(IDC_BTN_ALL_RESTART)->EnableWindow(TRUE);
	GetDlgItem(IDC_BTN_ALL_RESET)->EnableWindow(FALSE);
	GetDlgItem(IDC_BTN_ALL_DEFAULT)->EnableWindow(FALSE);
	GetDlgItem(IDC_BTN_ALL_DELETE)->EnableWindow(FALSE);
	GetDlgItem(IDC_BTN_ALL_FW_UPDATE)->EnableWindow(FALSE);
	GetDlgItem(IDC_BTN_ALL_CMD_STOP)->EnableWindow(TRUE);
	GetDlgItem(IDC_BTN_ALL_REFRESH)->EnableWindow(FALSE);
	GetDlgItem(IDOK)->EnableWindow(FALSE);
	
	
	/*
	if(!m_pDlgCat->GetStartStatus()) return;

	CHTTPRequest http;
	MSG msg;

	for(int i=0; i<MAX_LIVE_CHANNEL; i++){

		if(!m_pDlgCat->m_ciCommInfo[i].bExist) continue;
		
		if(!http.SendRequest(m_pDlgCat->m_ciCommInfo[i].strZeroConfIp, _T("/system/restart.php?app=set"), m_pDlgCat->m_ciCommInfo[i].nHttpPort, NULL, 0, CHTTPRequest::HTTP_GET,
			_T("admin"), _T("admin"), 0, 7000)){
				m_listCamList.SetItemText(i, LIST_STATUS_SEL, _T("Restart ����"));
				CString strLog = _T("");
				strLog.Format(L"%s(%s) ��ġ�� Restart�� ���� �Ͽ����ϴ�.", m_pDlgCat->m_ciCommInfo[i].strModelName, m_pDlgCat->m_ciCommInfo[i].strMac);
				m_pDlgCat->WriteLog(strLog, RGB(255, 0, 0));
		}
		if(http.GetResponseCode() != 200){	
			m_listCamList.SetItemText(i, LIST_STATUS_SEL, _T("Restart ����"));
			CString strLog = _T("");
			strLog.Format(L"%s(%s) ��ġ�� Restart�� ���� �Ͽ����ϴ�.", m_pDlgCat->m_ciCommInfo[i].strModelName, m_pDlgCat->m_ciCommInfo[i].strMac);
			m_pDlgCat->WriteLog(strLog, RGB(255, 0, 0));
		} else {
			m_listCamList.SetItemText(i, LIST_STATUS_SEL, _T("Restart ����"));
			CString strLog = _T("");
			strLog.Format(L"%s(%s) ��ġ�� Restart�� ���� �Ͽ����ϴ�.", m_pDlgCat->m_ciCommInfo[i].strModelName, m_pDlgCat->m_ciCommInfo[i].strMac);
			m_pDlgCat->WriteLog(strLog, RGB(0, 0, 0));
		}
	}
	*/
}

void CDlgCameraInfo::OnBnClickedBtnAllReset()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	if(!m_pDlgCat->GetStartStatus()) return;
//	if(m_hThreadAllCmd) return;
	if(m_hThreadAllCmd){
		AfxMessageBox(L"���� ������ �Դϴ�.", MB_OK | MB_ICONWARNING);

		return;
	}

	m_acCmd = CMD_RESET;

	OnBnClickedBtnAllRefresh();

	if(m_hThreadAllCmd == NULL){
		UINT dwThread;
		m_hThreadAllCmd = (HANDLE)_beginthreadex(NULL, 0, AllCmdThread, this, 0, &dwThread);
	}

	m_pDlgCat->WriteLog(L"��ü Reset ������ �����մϴ�.", RGB(0, 0, 0));

	GetDlgItem(IDC_BTN_ALL_RESTART)->EnableWindow(FALSE);
	GetDlgItem(IDC_BTN_ALL_RESET)->EnableWindow(TRUE);
	GetDlgItem(IDC_BTN_ALL_DEFAULT)->EnableWindow(FALSE);
	GetDlgItem(IDC_BTN_ALL_DELETE)->EnableWindow(FALSE);
	GetDlgItem(IDC_BTN_ALL_FW_UPDATE)->EnableWindow(FALSE);
	GetDlgItem(IDC_BTN_ALL_CMD_STOP)->EnableWindow(TRUE);
	GetDlgItem(IDC_BTN_ALL_REFRESH)->EnableWindow(FALSE);
	GetDlgItem(IDOK)->EnableWindow(FALSE);
	/*
	if(!m_pDlgCat->GetStartStatus()) return;
	
	CHTTPRequest http;
	MSG msg;

	for(int i=0; i<MAX_LIVE_CHANNEL; i++){

		if(!m_pDlgCat->m_ciCommInfo[i].bExist) continue;
		
		if(!http.SendRequest(m_pDlgCat->m_ciCommInfo[i].strZeroConfIp, _T("/system/reset.php?app=set"), m_pDlgCat->m_ciCommInfo[i].nHttpPort, NULL, 0, CHTTPRequest::HTTP_GET,
			_T("admin"), _T("admin"), 0, 7000)){
				m_listCamList.SetItemText(i, LIST_STATUS_SEL, _T("Restart ����"));
				CString strLog = _T("");
				strLog.Format(L"%s(%s) ��ġ�� Reset�� ���� �Ͽ����ϴ�.", m_pDlgCat->m_ciCommInfo[i].strModelName, m_pDlgCat->m_ciCommInfo[i].strMac);
				m_pDlgCat->WriteLog(strLog, RGB(255, 0, 0));
		}
		if(http.GetResponseCode() != 200){	
			m_listCamList.SetItemText(i, LIST_STATUS_SEL, _T("Restart ����"));
			CString strLog = _T("");
			strLog.Format(L"%s(%s) ��ġ�� Reset�� ���� �Ͽ����ϴ�.", m_pDlgCat->m_ciCommInfo[i].strModelName, m_pDlgCat->m_ciCommInfo[i].strMac);
			m_pDlgCat->WriteLog(strLog, RGB(255, 0, 0));
		} else {
			m_listCamList.SetItemText(i, LIST_STATUS_SEL, _T("Restart ����"));
			CString strLog = _T("");
			strLog.Format(L"%s(%s) ��ġ�� Reset�� ���� �Ͽ����ϴ�.", m_pDlgCat->m_ciCommInfo[i].strModelName, m_pDlgCat->m_ciCommInfo[i].strMac);
			m_pDlgCat->WriteLog(strLog, RGB(0, 0, 0));
		}
	}
	*/
}

void CDlgCameraInfo::OnBnClickedBtnAllDefault()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	if(!m_pDlgCat->GetStartStatus()) return;
//	if(m_hThreadAllCmd) return;
	if(m_hThreadAllCmd){
		AfxMessageBox(L"���� ������ �Դϴ�.", MB_OK | MB_ICONWARNING);

		return;
	}

	m_acCmd = CMD_DEFAULT;

	OnBnClickedBtnAllRefresh();

	if(m_hThreadAllCmd == NULL){
		UINT dwThread;
		m_hThreadAllCmd = (HANDLE)_beginthreadex(NULL, 0, AllCmdThread, this, 0, &dwThread);
	}

	m_pDlgCat->WriteLog(L"��ü Default ������ �����մϴ�.", RGB(0, 0, 0));

	GetDlgItem(IDC_BTN_ALL_RESTART)->EnableWindow(FALSE);
	GetDlgItem(IDC_BTN_ALL_RESET)->EnableWindow(FALSE);
	GetDlgItem(IDC_BTN_ALL_DEFAULT)->EnableWindow(TRUE);
	GetDlgItem(IDC_BTN_ALL_DELETE)->EnableWindow(FALSE);
	GetDlgItem(IDC_BTN_ALL_FW_UPDATE)->EnableWindow(FALSE);
	GetDlgItem(IDC_BTN_ALL_CMD_STOP)->EnableWindow(TRUE);
	GetDlgItem(IDC_BTN_ALL_REFRESH)->EnableWindow(FALSE);
	GetDlgItem(IDOK)->EnableWindow(FALSE);
	/*
	if(!m_pDlgCat->GetStartStatus()) return;
	
	CHTTPRequest http;
	MSG msg;

	for(int i=0; i<MAX_LIVE_CHANNEL; i++){

		if(!m_pDlgCat->m_ciCommInfo[i].bExist) continue;
	
		if(!http.SendRequest(m_pDlgCat->m_ciCommInfo[i].strZeroConfIp, _T("/system/default.php?app=set"), m_pDlgCat->m_ciCommInfo[i].nHttpPort, NULL, 0, CHTTPRequest::HTTP_GET,
			_T("admin"), _T("admin"), 0, 7000)){
				m_listCamList.SetItemText(i, LIST_STATUS_SEL, _T("Default ����"));
				CString strLog = _T("");
				strLog.Format(L"%s(%s) ��ġ�� Default�� ���� �Ͽ����ϴ�.", m_pDlgCat->m_ciCommInfo[i].strModelName, m_pDlgCat->m_ciCommInfo[i].strMac);
				m_pDlgCat->WriteLog(strLog, RGB(255, 0, 0));
		}
		if(http.GetResponseCode() != 200){	
			m_listCamList.SetItemText(i, LIST_STATUS_SEL, _T("Default ����"));
			CString strLog = _T("");
			strLog.Format(L"%s(%s) ��ġ�� Default�� ���� �Ͽ����ϴ�.", m_pDlgCat->m_ciCommInfo[i].strModelName, m_pDlgCat->m_ciCommInfo[i].strMac);
			m_pDlgCat->WriteLog(strLog, RGB(255, 0, 0));
		} else {
			m_listCamList.SetItemText(i, LIST_STATUS_SEL, _T("Default ����"));
			CString strLog = _T("");
			strLog.Format(L"%s(%s) ��ġ�� Default�� ���� �Ͽ����ϴ�.", m_pDlgCat->m_ciCommInfo[i].strModelName, m_pDlgCat->m_ciCommInfo[i].strMac);
			m_pDlgCat->WriteLog(strLog, RGB(0, 0, 0));
		}
	}
	*/
}

void CDlgCameraInfo::OnBnClickedBtnAllDelete()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	if(!m_pDlgCat->GetStartStatus()) return;
	if(m_hThreadAllCmd){
		AfxMessageBox(L"���� ������ �Դϴ�.", MB_OK | MB_ICONWARNING);

		return;
	}
	
	m_pDlgCat->WriteLog(L"��ü Delete ������ �����մϴ�.", RGB(0, 0, 0));

	//m_pDlgCat->OnBnClickedBtnDevSearchStop();

	m_pDlgCat->InitAllLiveStream();
	m_listCamList.DeleteAllItems();

	//m_pDlgCat->OnBnClickedBtnDevSearchStart();
}

void CDlgCameraInfo::OnBnClickedBtnAllFwUpdate()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	if(!m_pDlgCat->GetStartStatus()) return;
//	if(m_hThreadAllCmd) return;
	if(m_hThreadAllCmd){
		AfxMessageBox(L"���� ������ �Դϴ�.", MB_OK | MB_ICONWARNING);

		return;
	}

	TCHAR Filter[] = _T("Firmware files (*.bin;*.cab;*.img)|*.bin;*.cab;*.img|All files (*.*)|*.*|");
	CFileDialog Dlg(TRUE, NULL, NULL,
		OFN_HIDEREADONLY | OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST, Filter);
	if (Dlg.DoModal() != IDOK)
		return;

	CString strFWFileName = Dlg.GetPathName();
	if (strFWFileName.IsEmpty())
		return;

	m_strFwFileName.Format(L"%s", strFWFileName);

	m_acCmd = CMD_UPDATTE;

	OnBnClickedBtnAllRefresh();

	if(m_hThreadAllCmd == NULL){
		UINT dwThread;
		m_hThreadAllCmd = (HANDLE)_beginthreadex(NULL, 0, AllCmdThread, this, 0, &dwThread);
	}

	GetDlgItem(IDC_BTN_ALL_RESTART)->EnableWindow(FALSE);
	GetDlgItem(IDC_BTN_ALL_RESET)->EnableWindow(FALSE);
	GetDlgItem(IDC_BTN_ALL_DEFAULT)->EnableWindow(FALSE);
	GetDlgItem(IDC_BTN_ALL_DELETE)->EnableWindow(FALSE);
	GetDlgItem(IDC_BTN_ALL_FW_UPDATE)->EnableWindow(TRUE);
	GetDlgItem(IDC_BTN_ALL_CMD_STOP)->EnableWindow(TRUE);
	GetDlgItem(IDC_BTN_ALL_REFRESH)->EnableWindow(FALSE);
	GetDlgItem(IDOK)->EnableWindow(FALSE);
	/*
	if(!m_pDlgCat->GetStartStatus()) return;
	
	CHTTPRequest http;
	MSG msg;
	
	TCHAR Filter[] = _T("Firmware files (*.bin;*.cab;*.img)|*.bin;*.cab;*.img|All files (*.*)|*.*|");
	CFileDialog Dlg(TRUE, NULL, NULL,
		OFN_HIDEREADONLY | OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST, Filter);
	if (Dlg.DoModal() != IDOK)
		return ;

	CString strFWFileName = Dlg.GetPathName();
	if (strFWFileName.IsEmpty())
		return ;

	http.InitUpload();
	http.AddUploadData(_T("fimage"), strFWFileName, FALSE);

	for(int i=0; i<MAX_LIVE_CHANNEL; i++){

		if(!m_pDlgCat->m_ciCommInfo[i].bExist) continue;
		
		if(http.UploadProc(GetSafeHwnd(), m_pDlgCat->m_ciCommInfo[i].strZeroConfIp,  _T("/system/update.php?app=set"),
			m_pDlgCat->m_ciCommInfo[i].nHttpPort, L"admin", L"admin")){
				CString strResponse = UTF8ToWString(http.GetResponse()).c_str();

				if (strResponse.Find(_T("res=200")) >= 0){
					m_listCamList.SetItemText(i, LIST_STATUS_SEL, _T("Update ����"));
					CString strLog = _T("");
					strLog.Format(L"%s(%s) ��ġ�� Update�� ���� �Ͽ����ϴ�.", m_pDlgCat->m_ciCommInfo[i].strModelName, m_pDlgCat->m_ciCommInfo[i].strMac);
					m_pDlgCat->WriteLog(strLog, RGB(0, 0, 0));
				} else {
					m_listCamList.SetItemText(i, LIST_STATUS_SEL, _T("Update ����"));
					CString strLog = _T("");
					strLog.Format(L"%s(%s) ��ġ�� Update�� ���� �Ͽ����ϴ�.", m_pDlgCat->m_ciCommInfo[i].strModelName, m_pDlgCat->m_ciCommInfo[i].strMac);
					m_pDlgCat->WriteLog(strLog, RGB(255, 0, 0));
				}
		} else {
			m_listCamList.SetItemText(i, LIST_STATUS_SEL, _T("Update ����"));
			CString strLog = _T("");
			strLog.Format(L"%s(%s) ��ġ�� Update�� ���� �Ͽ����ϴ�.", m_pDlgCat->m_ciCommInfo[i].strModelName, m_pDlgCat->m_ciCommInfo[i].strMac);
			m_pDlgCat->WriteLog(strLog, RGB(255, 0, 0));
		}
	}
	*/
}

void CDlgCameraInfo::OnBnClickedBtnAllRefresh()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	if(!m_pDlgCat->GetStartStatus()) return;

	m_listCamList.DeleteAllItems();
	CString strIdx = _T("");
	for(int i=0; i<MAX_LIVE_CHANNEL; i++){
		strIdx.Format(L"%d", i+1);
		m_listCamList.InsertItem(i, strIdx, 0);
		m_listCamList.SetItemText(i, 1, m_pDlgCat->m_ciCommInfo[i].strModelName);
		m_listCamList.SetItemText(i, 2, m_pDlgCat->m_ciCommInfo[i].strIp);
		m_listCamList.SetItemText(i, 3, m_pDlgCat->m_ciCommInfo[i].strZeroConfIp);
		m_listCamList.SetItemText(i, 4, m_pDlgCat->m_ciCommInfo[i].strMac);
		m_listCamList.SetItemText(i, 5, m_pDlgCat->m_ciCommInfo[i].strFwVersion);
		//m_listCamList.SetItemText(i, 6, m_pDlgCat->m_ciCommInfo[i].strResolution);
		m_listCamList.SetItemText(i, LIST_STATUS_SEL, _T(""));
	}
}

int CDlgCameraInfo::AllCmd()
{
	Lock();
	switch(m_acCmd)
	{
	case CMD_RESTART :
		{
			if(m_pDlgCat->GetStartStatus()){
				CHTTPRequest http;
				MSG msg;

				int nIdx = 0;
				int nMaxIdx = 0;
				if(m_nSelectedDevice > -1){    // ���� �ϋ�
					nIdx = m_nSelectedDevice;
					nMaxIdx = m_nSelectedDevice + 1;
				} else {                            // ��ü �϶�
					nIdx = 0;
					nMaxIdx = MAX_LIVE_CHANNEL;
				}

				for(int i=nIdx; i<nMaxIdx; i++){
					if(m_acCmd == CMD_INIT) break;

					if(!m_pDlgCat->m_ciCommInfo[i].bExist) continue;
					
					CString *strMsg = new CString(_T("Restart ��...."));
					//m_listCamList.SetItemText(i, LIST_STATUS_SEL, _T("Restart ��...."));
					PostMessage(UM_CHANGE_LIST_STATUS, (WPARAM)strMsg, (LPARAM)i);
					if(!http.SendRequest(m_pDlgCat->m_ciCommInfo[i].strZeroConfIp, _T("/system/restart.php?app=set"), m_pDlgCat->m_ciCommInfo[i].nHttpPort, NULL, 0, CHTTPRequest::HTTP_GET,
						_T("admin"), _T("admin"), 0, 7000)){
							CString *strMsg = new CString(_T("Restart ����"));
							//m_listCamList.SetItemText(i, LIST_STATUS_SEL, _T("Restart ����"));
							PostMessage(UM_CHANGE_LIST_STATUS, (WPARAM)strMsg, (LPARAM)i);

							CString strLog = _T("");
							strLog.Format(L"%s(%s) ��ġ�� Restart�� ���� �Ͽ����ϴ�.", m_pDlgCat->m_ciCommInfo[i].strModelName, m_pDlgCat->m_ciCommInfo[i].strMac);
							m_pDlgCat->WriteLog(strLog, RGB(255, 0, 0));
					}
					if(http.GetResponseCode() != 200){	
						CString *strMsg = new CString(_T("Restart ����"));
						//m_listCamList.SetItemText(i, LIST_STATUS_SEL, _T("Restart ����"));
						PostMessage(UM_CHANGE_LIST_STATUS, (WPARAM)strMsg, (LPARAM)i);
						CString strLog = _T("");
						strLog.Format(L"%s(%s) ��ġ�� Restart�� ���� �Ͽ����ϴ�.", m_pDlgCat->m_ciCommInfo[i].strModelName, m_pDlgCat->m_ciCommInfo[i].strMac);
						m_pDlgCat->WriteLog(strLog, RGB(255, 0, 0));
					} else {
						CString *strMsg = new CString(_T("Restart ����"));
						//m_listCamList.SetItemText(i, LIST_STATUS_SEL, _T("Restart ����"));
						PostMessage(UM_CHANGE_LIST_STATUS, (WPARAM)strMsg, (LPARAM)i);
						CString strLog = _T("");
						strLog.Format(L"%s(%s) ��ġ�� Restart�� ���� �Ͽ����ϴ�.", m_pDlgCat->m_ciCommInfo[i].strModelName, m_pDlgCat->m_ciCommInfo[i].strMac);
						m_pDlgCat->WriteLog(strLog, RGB(0, 0, 0));
					}
				}
			}
		}
		break;
	case CMD_RESET :
		{
			if(m_pDlgCat->GetStartStatus()){
				CHTTPRequest http;
				MSG msg;

				int nIdx = 0;
				int nMaxIdx = 0;
				if(m_nSelectedDevice > -1){    // ���� �ϋ�
					nIdx = m_nSelectedDevice;
					nMaxIdx = m_nSelectedDevice + 1;
				} else {                            // ��ü �϶�
					nIdx = 0;
					nMaxIdx = MAX_LIVE_CHANNEL;
				}

				for(int i=nIdx; i<nMaxIdx; i++){
					if(m_acCmd == CMD_INIT) break;

					if(!m_pDlgCat->m_ciCommInfo[i].bExist) continue;

					CString *strMsg = new CString(_T("Reset ��....."));
					//m_listCamList.SetItemText(i, LIST_STATUS_SEL, _T("Reset ��....."));
					PostMessage(UM_CHANGE_LIST_STATUS, (WPARAM)strMsg, (LPARAM)i);
					if(!http.SendRequest(m_pDlgCat->m_ciCommInfo[i].strZeroConfIp, _T("/system/reset.php?app=set"), m_pDlgCat->m_ciCommInfo[i].nHttpPort, NULL, 0, CHTTPRequest::HTTP_GET,
						_T("admin"), _T("admin"), 0, 7000)){
							CString *strMsg = new CString(_T("Reset ����"));
							PostMessage(UM_CHANGE_LIST_STATUS, (WPARAM)strMsg, (LPARAM)i);
							//m_listCamList.SetItemText(i, LIST_STATUS_SEL, _T("Reset ����"));
							CString strLog = _T("");
							strLog.Format(L"%s(%s) ��ġ�� Reset�� ���� �Ͽ����ϴ�.", m_pDlgCat->m_ciCommInfo[i].strModelName, m_pDlgCat->m_ciCommInfo[i].strMac);
							m_pDlgCat->WriteLog(strLog, RGB(255, 0, 0));
					}
					if(http.GetResponseCode() != 200){	
						CString *strMsg = new CString(_T("Reset ����"));
						PostMessage(UM_CHANGE_LIST_STATUS, (WPARAM)strMsg, (LPARAM)i);
						//m_listCamList.SetItemText(i, LIST_STATUS_SEL, _T("Reset ����"));
						CString strLog = _T("");
						strLog.Format(L"%s(%s) ��ġ�� Reset�� ���� �Ͽ����ϴ�.", m_pDlgCat->m_ciCommInfo[i].strModelName, m_pDlgCat->m_ciCommInfo[i].strMac);
						m_pDlgCat->WriteLog(strLog, RGB(255, 0, 0));
					} else {
						CString *strMsg = new CString(_T("Reset ����"));
						PostMessage(UM_CHANGE_LIST_STATUS, (WPARAM)strMsg, (LPARAM)i);
						//m_listCamList.SetItemText(i, LIST_STATUS_SEL, _T("Reset ����"));
						CString strLog = _T("");
						strLog.Format(L"%s(%s) ��ġ�� Reset�� ���� �Ͽ����ϴ�.", m_pDlgCat->m_ciCommInfo[i].strModelName, m_pDlgCat->m_ciCommInfo[i].strMac);
						m_pDlgCat->WriteLog(strLog, RGB(0, 0, 0));
					}
				}
			}
		}
		break;
	case CMD_DEFAULT :
		{
			if(m_pDlgCat->GetStartStatus()){
				CHTTPRequest http;
				MSG msg;

				int nIdx = 0;
				int nMaxIdx = 0;
				if(m_nSelectedDevice > -1){    // ���� �ϋ�
					nIdx = m_nSelectedDevice;
					nMaxIdx = m_nSelectedDevice + 1;
				} else {                            // ��ü �϶�
					nIdx = 0;
					nMaxIdx = MAX_LIVE_CHANNEL;
				}

				for(int i=nIdx; i<nMaxIdx; i++){
					if(m_acCmd == CMD_INIT) break;

					if(!m_pDlgCat->m_ciCommInfo[i].bExist) continue;


					CString *strMsg = new CString(_T("Default ��....."));
					PostMessage(UM_CHANGE_LIST_STATUS, (WPARAM)strMsg, (LPARAM)i);
					//m_listCamList.SetItemText(i, LIST_STATUS_SEL, _T("Default ��....."));
					if(!http.SendRequest(m_pDlgCat->m_ciCommInfo[i].strZeroConfIp, _T("/system/default.php?app=set"), m_pDlgCat->m_ciCommInfo[i].nHttpPort, NULL, 0, CHTTPRequest::HTTP_GET,
						_T("admin"), _T("admin"), 0, 7000)){
							CString *strMsg = new CString(_T("Default ����"));
							PostMessage(UM_CHANGE_LIST_STATUS, (WPARAM)strMsg, (LPARAM)i);
							//m_listCamList.SetItemText(i, LIST_STATUS_SEL, _T("Default ����"));
							CString strLog = _T("");
							strLog.Format(L"%s(%s) ��ġ�� Default�� ���� �Ͽ����ϴ�.", m_pDlgCat->m_ciCommInfo[i].strModelName, m_pDlgCat->m_ciCommInfo[i].strMac);
							m_pDlgCat->WriteLog(strLog, RGB(255, 0, 0));
					}
					if(http.GetResponseCode() != 200){	
						CString *strMsg = new CString(_T("Default ����"));
						PostMessage(UM_CHANGE_LIST_STATUS, (WPARAM)strMsg, (LPARAM)i);
						//m_listCamList.SetItemText(i, LIST_STATUS_SEL, _T("Default ����"));
						CString strLog = _T("");
						strLog.Format(L"%s(%s) ��ġ�� Default�� ���� �Ͽ����ϴ�.", m_pDlgCat->m_ciCommInfo[i].strModelName, m_pDlgCat->m_ciCommInfo[i].strMac);
						m_pDlgCat->WriteLog(strLog, RGB(255, 0, 0));
					} else {
						CString *strMsg = new CString(_T("Default ����"));
						PostMessage(UM_CHANGE_LIST_STATUS, (WPARAM)strMsg, (LPARAM)i);
						//m_listCamList.SetItemText(i, LIST_STATUS_SEL, _T("Default ����"));
						CString strLog = _T("");
						strLog.Format(L"%s(%s) ��ġ�� Default�� ���� �Ͽ����ϴ�.", m_pDlgCat->m_ciCommInfo[i].strModelName, m_pDlgCat->m_ciCommInfo[i].strMac);
						m_pDlgCat->WriteLog(strLog, RGB(0, 0, 0));
					}
				}
			}
		}
		break;
	case CMD_UPDATTE :
		{
			if(m_pDlgCat->GetStartStatus()){
				CHTTPRequest http;
				MSG msg;

				http.InitUpload();
				http.AddUploadData(_T("fimage"), m_strFwFileName, FALSE);

				int nIdx = 0;
				int nMaxIdx = 0;
				if(m_nSelectedDevice > -1){    // ���� �ϋ�
					nIdx = m_nSelectedDevice;
					nMaxIdx = m_nSelectedDevice + 1;
				} else {                            // ��ü �϶�
					nIdx = 0;
					nMaxIdx = MAX_LIVE_CHANNEL;
				}

				for(int i=nIdx; i<nMaxIdx; i++){
					if(m_acCmd == CMD_INIT) break;

					if(!m_pDlgCat->m_ciCommInfo[i].bExist) continue;

					CString *strMsg = new CString(_T("Update ��....."));
					PostMessage(UM_CHANGE_LIST_STATUS, (WPARAM)strMsg, (LPARAM)i);
					//m_listCamList.SetItemText(i, LIST_STATUS_SEL, _T("Update ��....."));
					if(http.UploadProc(GetSafeHwnd(), m_pDlgCat->m_ciCommInfo[i].strZeroConfIp,  _T("/system/update.php?app=set"),
						m_pDlgCat->m_ciCommInfo[i].nHttpPort, L"admin", L"admin")){
							CString strResponse = UTF8ToWString(http.GetResponse()).c_str();

							if (strResponse.Find(_T("res=200")) >= 0){
								CString *strMsg = new CString(_T("Update ����"));
								PostMessage(UM_CHANGE_LIST_STATUS, (WPARAM)strMsg, (LPARAM)i);
								//m_listCamList.SetItemText(i, LIST_STATUS_SEL, _T("Update ����"));
								CString strLog = _T("");
								strLog.Format(L"%s(%s) ��ġ�� Update�� ���� �Ͽ����ϴ�.", m_pDlgCat->m_ciCommInfo[i].strModelName, m_pDlgCat->m_ciCommInfo[i].strMac);
								m_pDlgCat->WriteLog(strLog, RGB(0, 0, 0));
							} else {
								CString *strMsg = new CString(_T("Update ����"));
								PostMessage(UM_CHANGE_LIST_STATUS, (WPARAM)strMsg, (LPARAM)i);
								//m_listCamList.SetItemText(i, LIST_STATUS_SEL, _T("Update ����"));
								CString strLog = _T("");
								strLog.Format(L"%s(%s) ��ġ�� Update�� ���� �Ͽ����ϴ�.", m_pDlgCat->m_ciCommInfo[i].strModelName, m_pDlgCat->m_ciCommInfo[i].strMac);
								m_pDlgCat->WriteLog(strLog, RGB(255, 0, 0));
							}
					} else {
						CString *strMsg = new CString(_T("Update ����"));
						PostMessage(UM_CHANGE_LIST_STATUS, (WPARAM)strMsg, (LPARAM)i);
						//m_listCamList.SetItemText(i, LIST_STATUS_SEL, _T("Update ����"));
						CString strLog = _T("");
						strLog.Format(L"%s(%s) ��ġ�� Update�� ���� �Ͽ����ϴ�.", m_pDlgCat->m_ciCommInfo[i].strModelName, m_pDlgCat->m_ciCommInfo[i].strMac);
						m_pDlgCat->WriteLog(strLog, RGB(255, 0, 0));
					}
				}
			}
		}
		break;
	default:
		break;
	}
	Unlock();

	CloseHandle(m_hThreadAllCmd);
	m_hThreadAllCmd = NULL;

	m_acCmd = CMD_INIT;
	m_strFwFileName = _T("");
	m_nSelectedDevice = -1;

	PostMessage(UM_CHANGE_BTN_INIT, NULL, NULL);

	return 0;
}

void CDlgCameraInfo::OnBnClickedBtnAllCmdStop()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	if(m_acCmd != CMD_INIT){  
		switch(m_acCmd)
		{
		case CMD_RESTART :
			{
				m_pDlgCat->WriteLog(L"��ü Restart ���� �۾��� �ߴ��մϴ�.", RGB(255, 0, 0));
			}
			break;
		case CMD_RESET :
			{
				m_pDlgCat->WriteLog(L"��ü Reset ���� �۾��� �ߴ��մϴ�.", RGB(255, 0, 0));
			}
			break;
		case CMD_DEFAULT :
			{
				m_pDlgCat->WriteLog(L"��ü Default ���� �۾��� �ߴ��մϴ�.", RGB(255, 0, 0));
			}
			break;
		case CMD_UPDATTE :
			{	
				m_pDlgCat->WriteLog(L"��ü Update ���� �۾��� �ߴ��մϴ�.", RGB(255, 0, 0));
			}
			break;
		}

		m_acCmd = CMD_INIT;   
		MSG msg;

		while(m_hThreadAllCmd != NULL){
			while(::PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
			{
				TranslateMessage(&msg);
				DispatchMessage(&msg);
			}
		}

		GetDlgItem(IDC_BTN_ALL_RESTART)->EnableWindow(TRUE);
		GetDlgItem(IDC_BTN_ALL_RESET)->EnableWindow(TRUE);
		GetDlgItem(IDC_BTN_ALL_DEFAULT)->EnableWindow(TRUE);
		GetDlgItem(IDC_BTN_ALL_DELETE)->EnableWindow(TRUE);
		GetDlgItem(IDC_BTN_ALL_FW_UPDATE)->EnableWindow(TRUE);
		GetDlgItem(IDC_BTN_ALL_CMD_STOP)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_ALL_REFRESH)->EnableWindow(TRUE);
		GetDlgItem(IDOK)->EnableWindow(TRUE);

		m_strFwFileName = _T("");
	}
}

LRESULT CDlgCameraInfo::OnChangeBtnInit(WPARAM wParam, LPARAM lParam)
{
	GetDlgItem(IDC_BTN_ALL_RESTART)->EnableWindow(TRUE);
	GetDlgItem(IDC_BTN_ALL_RESET)->EnableWindow(TRUE);
	GetDlgItem(IDC_BTN_ALL_DEFAULT)->EnableWindow(TRUE);
	GetDlgItem(IDC_BTN_ALL_DELETE)->EnableWindow(TRUE);
	GetDlgItem(IDC_BTN_ALL_FW_UPDATE)->EnableWindow(TRUE);
	GetDlgItem(IDC_BTN_ALL_CMD_STOP)->EnableWindow(FALSE);
	GetDlgItem(IDC_BTN_ALL_REFRESH)->EnableWindow(TRUE);
	GetDlgItem(IDOK)->EnableWindow(TRUE);
	
	return 0;
}

LRESULT CDlgCameraInfo::OnChangeListStatus(WPARAM wParam, LPARAM lParam)
{
	CString *strMsg = (CString *)wParam;

	int nIdx = (int)lParam;
	m_listCamList.SetItemText(nIdx, LIST_STATUS_SEL, strMsg->GetBuffer(0));

	delete strMsg;
	
	return 0;
}

void CDlgCameraInfo::Lock()
{
	EnterCriticalSection(&m_cs);
}

void CDlgCameraInfo::Unlock()
{
	LeaveCriticalSection(&m_cs);
}

void CDlgCameraInfo::OnBnClickedOk()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	if(m_hThreadAllCmd){
		AfxMessageBox(L"���� ������ �Դϴ�.\n����� �ٽ� �õ��� �ּ���.", MB_OK | MB_ICONWARNING);

		return;
	}

	OnOK();
}

void CDlgCameraInfo::OnNMClickListCameraConfig(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	CString strModelname = m_listCamList.GetItemText(pNMItemActivate->iItem, 1);

	if(strModelname == _T("")) return;

	m_pDlgCat->SetSelectionIndex(m_listCamList.GetSelectionMark());

	*pResult = 0;
}
