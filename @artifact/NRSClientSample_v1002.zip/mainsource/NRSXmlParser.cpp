#include "StdAfx.h"
#include "NRSXmlParser.h"
#include "XML.h"
#include "NRSBase.h"

using namespace NRS;

CNRSXmlParser::CNRSXmlParser(CNRSBase* pNrs)
:m_nClientId(-1)
,m_pNrs(pNrs)
{
	InitializeCriticalSection(&m_csCallback);
}

CNRSXmlParser::~CNRSXmlParser(void)
{
	DeleteCriticalSection(&m_csCallback);
}

int CNRSXmlParser::Process(const char *pXML, size_t nSize)
{
	//TRACE(">> XML <<\n%s\n", pXML);

	CXML xml;
	if(!xml.LoadXMLFromString(pXML))
	{
		m_strReqId = _T("");
		return -1;
	}

	int nError = NO_ERROR;
	MSXML2::IXMLDOMNodePtr pRoot = xml.GetRootElementPtr();

	m_strReqId = CXML::GetAttributeValue(pRoot, L"req_id");
	CString BaseName(pRoot->GetbaseName().GetBSTR());
	if(BaseName == _T("GetClientIDRes"))
		nError = _ProcessXML_GetClientIDRes(pRoot);
	else
	{
		if(!BaseName.IsEmpty())
		{
			map<wstring, NRS_RECEIVEDATAFUNCTION_T>::iterator pos;
			EnterCriticalSection(&m_csCallback);
			pos = m_callbackNotifyMap.find( (LPCTSTR)BaseName );
			if(pos != m_callbackNotifyMap.end())
				pos->second.func(pXML, nSize, pos->second.pUserContext);

			LeaveCriticalSection(&m_csCallback);
		}
	}

	return nError;
}

int CNRSXmlParser::_ProcessXML_GetClientIDRes(MSXML2::IXMLDOMNodePtr pNode)
{
	m_nClientId = _ttoi( CXML::GetChildNodeText(pNode, _T("ClientID")) );

	return NO_ERROR;
}

int CNRSXmlParser::_ProcessXML_GetAllStreamInfoRes(MSXML2::IXMLDOMNodeListPtr pList)
{
	if(pList == NULL) return -1;

	ClearStreamListAll();

	STREAM_INFO *pStream;
	MSXML2::IXMLDOMNodePtr pNode;
	long count = pList->Getlength();
	for(long i=0; i<count; i++)
	{
		pNode = pList->Getitem(i);
		pStream = new STREAM_INFO;
		pStream->nId			= i;
		pStream->strMAC			= CXML::GetChildNodeText(pNode, _T("MAC"));
		pStream->strProfile		= CXML::GetChildNodeText(pNode, _T("Profile"));
		pStream->strAddress		= CXML::GetChildNodeText(pNode, _T("Address"));
		pStream->strModel		= CXML::GetChildNodeText(pNode, _T("Model"));
		pStream->strModelType	= CXML::GetChildNodeText(pNode, _T("ModelType"));
		pStream->strUrl			= CXML::GetChildNodeText(pNode, _T("URL"));

		m_StreamMultiMap.insert( pair<wstring, STREAM_INFO*>( (LPCTSTR)pStream->strMAC, pStream ) );
	}	

	return NO_ERROR;
}

void CNRSXmlParser::ClearStreamListAll()
{
	std::multimap<wstring, STREAM_INFO*>::iterator pos = m_StreamMultiMap.begin();
	while(pos != m_StreamMultiMap.end())
	{
		delete pos->second;
		pos++;
	}
	m_StreamMultiMap.clear();
}

int CNRSXmlParser::_ProcessXML_LoadMSConfigRes(MSXML2::IXMLDOMNodeListPtr pList)
{
	return NO_ERROR;
}

BOOL CNRSXmlParser::IsEqualReqId(CString& strReqId)
{
	if(m_strReqId.IsEmpty())
		return FALSE;

	if(m_strReqId == strReqId)
	{
		m_strReqId.Empty();
		return TRUE;
	}

	return FALSE;
}

void CNRSXmlParser::AddNotifyCallback(LPCTSTR pNodeName, LPNRS_RECEIVEDATAFUNCTION Func, void* pUserContext)
{
	if(pNodeName == NULL)
		return;

	NRS_RECEIVEDATAFUNCTION_T f;
	f.func			= Func;
	f.pUserContext	= pUserContext;
	_ftime64_s(&f.t);

	wstring nodeName(pNodeName);
	EnterCriticalSection(&m_csCallback);
	m_callbackNotifyMap[nodeName] = f;
	LeaveCriticalSection(&m_csCallback);
}

void CNRSXmlParser::RemoveNotifyCallback(LPCTSTR pNodeName)
{
	if(pNodeName == NULL)
	{
		// Remove all
		EnterCriticalSection(&m_csCallback);
		m_callbackNotifyMap.clear();
		LeaveCriticalSection(&m_csCallback);
	}
	else
	{
	        wstring nodeName(pNodeName);
	        EnterCriticalSection(&m_csCallback);
	        m_callbackNotifyMap.erase(nodeName);
	        LeaveCriticalSection(&m_csCallback);
	}
}