
// DlgNRSClientSample.cpp : ���� ����
//

#include "StdAfx.h"
#include "DlgNRSClientSample.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// ���� ���α׷� ������ ���Ǵ� CAboutDlg ��ȭ �����Դϴ�.

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

// �����Դϴ�.
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CDlgNRSClientSample ��ȭ ����
const UINT UM_DISCONNECT = RegisterWindowMessage(L"UM_DISCONNECT");
const UINT UM_CONNECT = RegisterWindowMessage(L"UM_CONNECT");
static const UINT OSD_TIMER_ID = 3100;

CDlgNRSClientSample::CDlgNRSClientSample(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgNRSClientSample::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	m_pDlgDevRegister = NULL;
	m_pLive1Disp = NULL;
	m_pNRSManager = NULL;
	m_bClose = FALSE;
	m_bStop = FALSE;
	m_hEvent = NULL;
	m_hStatusThread = NULL;
}

void CDlgNRSClientSample::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST_LOG, m_listLog);
	DDX_Control(pDX, IDC_EDIT_STATUS, m_edStatus);
	DDX_Control(pDX, IDC_BUTTON_CAMERA_REGISTER, m_btnDevRegister);
	DDX_Control(pDX, IDC_EDIT_NRS_IP, m_edNrsIP);
	DDX_Control(pDX, IDC_EDIT_USER_ID, m_edID);
	DDX_Control(pDX, IDC_EDIT_USER_PW, m_edPW);
}

BEGIN_MESSAGE_MAP(CDlgNRSClientSample, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_WM_SIZE()
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BUTTON_NRS_CONNECT, &CDlgNRSClientSample::OnBnClickedButtonNrsConnect)
	ON_BN_CLICKED(IDC_BUTTON_CAMERA_REGISTER, &CDlgNRSClientSample::OnBnClickedButtonCameraRegister)
	ON_BN_CLICKED(IDC_BTN_PLAYBACK_VIEW, &CDlgNRSClientSample::OnBnClickedBtnPlaybackView)
END_MESSAGE_MAP()


// CDlgNRSClientSample �޽��� ó����

BOOL CDlgNRSClientSample::OnInitDialog()
{
	CDialog::OnInitDialog();

	// �ý��� �޴��� "����..." �޴� �׸��� �߰��մϴ�.

	// IDM_ABOUTBOX�� �ý��� ���� ������ �־�� �մϴ�.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// �� ��ȭ ������ �������� �����մϴ�. ���� ���α׷��� �� â�� ��ȭ ���ڰ� �ƴ� ��쿡��
	//  �����ӿ�ũ�� �� �۾��� �ڵ����� �����մϴ�.
	SetIcon(m_hIcon, TRUE);			// ū �������� �����մϴ�.
	SetIcon(m_hIcon, FALSE);		// ���� �������� �����մϴ�.

	// TODO: ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	InitializeCriticalSection(&m_cs);
	
	// 	int nPrimaryMonitorX = ::GetSystemMetrics(SM_CXSCREEN);
	// 	int nPrimaryMonitorY = ::GetSystemMetrics(SM_CYSCREEN);

	m_pLive1Disp = CDisplayLib::CreateDisplayLib();

	m_pLive1Disp->SetUserContext(this);
	m_pLive1Disp->SetCallbackD3D9DeviceCreated( OnD3DDeviceCreated );
	m_pLive1Disp->SetCallbackD3D9DeviceDestroyed( OnD3DDeviceDestroyed );
	m_pLive1Disp->SetCallbackD3D9CustomDraw( OnD3D9CustomDraw );
	m_pLive1Disp->SetCallbackD3D9DeviceReset( OnD3DDeviceReset );
	m_pLive1Disp->SetCallbackD3D9DeviceLost( OnD3DDeviceLost );
	m_pLive1Disp->SetCallbackDispMsgProc( OnDispMsgProc );
	
	m_pLive1Disp->Create(64, WS_VISIBLE | WS_CHILD | WS_CLIPCHILDREN, CRect(0, 0, 0, 0), NULL, GetSafeHwnd());
	m_pLive1Disp->SetViewLayout(VIEW4x4);

	SetWindowPos(NULL, 0, 0, 1000, 700, NULL);

	m_edNrsIP.SetWindowText(_T("127.0.0.1"));
	m_edID.SetWindowText(_T("admin"));
	m_edPW.SetWindowText(_T("admin"));

	return TRUE;  // ��Ŀ���� ��Ʈ�ѿ� �������� ������ TRUE�� ��ȯ�մϴ�.
}

void CDlgNRSClientSample::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// ��ȭ ���ڿ� �ּ�ȭ ���߸� �߰��� ��� �������� �׸�����
//  �Ʒ� �ڵ尡 �ʿ��մϴ�. ����/�� ���� ����ϴ� MFC ���� ���α׷��� ��쿡��
//  �����ӿ�ũ���� �� �۾��� �ڵ����� �����մϴ�.

void CDlgNRSClientSample::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // �׸��⸦ ���� ����̽� ���ؽ�Ʈ

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Ŭ���̾�Ʈ �簢������ �������� ����� ����ϴ�.
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// �������� �׸��ϴ�.
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// ����ڰ� �ּ�ȭ�� â�� ���� ���ȿ� Ŀ���� ǥ�õǵ��� �ý��ۿ���
//  �� �Լ��� ȣ���մϴ�.
HCURSOR CDlgNRSClientSample::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CDlgNRSClientSample::OnSize(UINT nType, int cx, int cy)
{
	CDialog::OnSize(nType, cx, cy);

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	if(m_pLive1Disp && m_pLive1Disp->m_hWnd)
	{
		m_pLive1Disp->SetWindowSize(cx, cy-150);
		
		GetDlgItem(IDC_STATIC_1)->MoveWindow(10, cy-140, 60, 16);
		GetDlgItem(IDC_STATIC_2)->MoveWindow(10, cy-110, 60, 16);
		GetDlgItem(IDC_STATIC_3)->MoveWindow(10, cy-80, 60, 16);

		GetDlgItem(IDC_EDIT_NRS_IP)->MoveWindow(70, cy-140, 180, 23);
		GetDlgItem(IDC_EDIT_USER_ID)->MoveWindow(70, cy-110, 100, 23);
		GetDlgItem(IDC_EDIT_USER_PW)->MoveWindow(70, cy-80, 100, 23);
		GetDlgItem(IDC_BUTTON_NRS_CONNECT)->MoveWindow(180, cy-110, 105, 50);
		GetDlgItem(IDC_BUTTON_CAMERA_REGISTER)->MoveWindow(10, cy-45, 130, 40);
		GetDlgItem(IDC_LIST_LOG)->MoveWindow(300, cy-150, 300, 150);
		GetDlgItem(IDC_EDIT_STATUS)->MoveWindow(600, cy-150, cx-600, 150);
		GetDlgItem(IDC_BTN_PLAYBACK_VIEW)->MoveWindow(155, cy-45, 130, 40);
		
		Invalidate();
	}
		
}

void CDlgNRSClientSample::OnDestroy()
{
	CDialog::OnDestroy();

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	DeleteCriticalSection(&m_cs);

	if (m_hStatusThread)
	{
		//m_bClose = TRUE;
		SetEvent(m_hEvent);
		SetThreadPriority(m_hStatusThread, THREAD_PRIORITY_ABOVE_NORMAL);
		WaitForSingleObject(m_hStatusThread, INFINITE);

		CloseHandle(m_hStatusThread);
		m_hStatusThread = NULL;

		if (m_hEvent)
		{
			CloseHandle(m_hEvent);
			m_hEvent = NULL;
		}
	}

	if (m_pNRSManager)
	{
		m_pNRSManager->Disconnect();

		delete m_pNRSManager;
		m_pNRSManager = NULL;
	}

	if(m_pDlgDevRegister)
	{
		delete m_pDlgDevRegister;
		m_pDlgDevRegister = NULL;
	}
}

HRESULT WINAPI CDlgNRSClientSample::OnD3DDeviceCreated(LPDIRECT3DDEVICE9 pd3dDevice, LPD3DXSPRITE pd3dSprite, const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext)
{
	CDlgNRSClientSample* pCatDlg = reinterpret_cast<CDlgNRSClientSample*>(pUserContext);
	pCatDlg->OnDxDeviceCreated(pd3dDevice, pd3dSprite, pBackBufferSurfaceDesc);

	return S_OK;
}

HRESULT WINAPI CDlgNRSClientSample::OnD3DDeviceDestroyed(void *pUserContext)
{
	CDlgNRSClientSample* pCatDlg = reinterpret_cast<CDlgNRSClientSample*>(pUserContext);
	pCatDlg->OnDxDeviceDestroyed();

	return S_OK;
}

void WINAPI CDlgNRSClientSample::OnD3DDeviceLost(void *pUserContext)
{
	CDlgNRSClientSample* pCatDlg = reinterpret_cast<CDlgNRSClientSample*>(pUserContext);
	pCatDlg->OnDxDeviceLost();
}

void WINAPI CDlgNRSClientSample::OnD3DDeviceReset(LPDIRECT3DDEVICE9 pd3dDevice,  LPD3DXSPRITE pd3dSprite, const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext)
{
	CDlgNRSClientSample* pCatDlg = reinterpret_cast<CDlgNRSClientSample*>(pUserContext);
	pCatDlg->OnDxDeviceReset(pd3dDevice, pd3dSprite, pBackBufferSurfaceDesc);
}

void WINAPI CDlgNRSClientSample::OnD3D9CustomDraw(DISP_DX3D9* pDisp)
{
	CDlgNRSClientSample* pCatDlg = reinterpret_cast<CDlgNRSClientSample*>(pDisp->pUserContext);
	if(pCatDlg){
		pCatDlg->OnDxCustomDraw(pDisp);
	}
}

void WINAPI CDlgNRSClientSample::OnD3DPannelEvent(UINT nID, UINT nEvent, DX3DUTIL::CDX3DBaseControl* pControl, void* pUserContext)
{
	CDlgNRSClientSample* pCatDlg = reinterpret_cast<CDlgNRSClientSample*>(pUserContext);
	pCatDlg->OnDxPannelEvent(nID, nEvent, pControl);
}

BOOL WINAPI CDlgNRSClientSample::OnDispMsgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, void* pUserContext)
{
	if(!pUserContext)
		return FALSE;

	CDlgNRSClientSample* pCatDlg = reinterpret_cast<CDlgNRSClientSample*>(pUserContext);

	return pCatDlg->OnDxDispMsgProc(hWnd, uMsg, wParam, lParam);
}

void CDlgNRSClientSample::OnDxDeviceCreated(LPDIRECT3DDEVICE9 pd3dDevice, LPD3DXSPRITE pd3dSprite, const D3DSURFACE_DESC* pBackBufferSurfaceDesc)
{
	m_dx3dResource.OnD3D9CreateDevice(pd3dDevice, pd3dSprite);

	if(m_pd3dLine == NULL)
		D3DXCreateLine(pd3dDevice, &m_pd3dLine);
}

void CDlgNRSClientSample::OnDxDeviceDestroyed()
{
	if(m_pd3dLine)
	{
		m_pd3dLine->Release();
		m_pd3dLine = NULL;
	}

	m_dx3dResource.OnD3D9DestroyDevice();
}

void CDlgNRSClientSample::OnDxDeviceLost()
{
	if(m_pd3dLine)
		m_pd3dLine->OnLostDevice();

	m_dx3dResource.OnD3D9LostDevice();
}


void CDlgNRSClientSample::OnDxDeviceReset(LPDIRECT3DDEVICE9 pd3dDevice,  LPD3DXSPRITE pd3dSprite, const D3DSURFACE_DESC* pBackBufferSurfaceDesc)
{
	if(m_pd3dLine)
		m_pd3dLine->OnResetDevice();

	m_dx3dResource.OnD3D9ResetDevice(pd3dDevice, pd3dSprite);
}

void CDlgNRSClientSample::OnDxCustomDraw(DISP_DX3D9* pDisp)
{
	CDlgNRSClientSample* pCatDlg = reinterpret_cast<CDlgNRSClientSample*>(pDisp->pUserContext);
	CString strCh = _T("");

	pCatDlg->m_dx3dResource.Lock();
	if(pCatDlg->m_dx3dResource.GetD3D9Device())
	{
		for(int i=0; i<MAX_LIVE_CHANNEL; i++)
		{
			CRect rt;	
			pCatDlg->m_pLive1Disp->GetRect2(i, &rt);
			strCh.Format(L"Ch %d", i);
			
			if((rt.left ==0) && (rt.top == 0) && (rt.right == 0) && (rt.bottom == 0))
			{   
				// Display�� ���� �κ�
				pCatDlg->m_dx3dResource.m_pd3dSprite->Begin(D3DXSPRITE_ALPHABLEND | D3DXSPRITE_SORT_TEXTURE);	
				pCatDlg->m_dx3dResource.GetFont(0)->pFont->DrawText(pCatDlg->m_dx3dResource.m_pd3dSprite, 
					_T(""), -1, CRect(0, 0, 0, 0), 
					DT_NOCLIP, D3DCOLOR_XRGB(0, 0, 0));
				pCatDlg->m_dx3dResource.m_pd3dSprite->End();
			} else 
			{   
				// Display�� �ִ� �κ�
				pCatDlg->m_dx3dResource.m_pd3dSprite->Begin(D3DXSPRITE_ALPHABLEND | D3DXSPRITE_SORT_TEXTURE);	
				pCatDlg->m_dx3dResource.GetFont(0)->pFont->DrawText(pCatDlg->m_dx3dResource.m_pd3dSprite, 
					strCh, -1, CRect(rt.left+10, rt.top+10, 0, 0), 
					DT_NOCLIP, D3DCOLOR_XRGB(255, 255, 255));
/*
				pCatDlg->m_dx3dResource.GetFont(0)->pFont->DrawText(pCatDlg->m_dx3dResource.m_pd3dSprite, 
					_T("CameraName"), -1, CRect(rt.left+10, rt.top+25, 0, 0), 
					DT_NOCLIP, D3DCOLOR_XRGB(255, 255, 255));
*/
				pCatDlg->m_dx3dResource.m_pd3dSprite->End();

			}
		}
	}
	pCatDlg->m_dx3dResource.Unlock();

}

void CDlgNRSClientSample::OnDxPannelEvent(UINT nID, UINT nEvent, DX3DUTIL::CDX3DBaseControl* pControl)
{
}

BOOL CDlgNRSClientSample::OnDxDispMsgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch(uMsg)
	{
	case WM_CREATE :
		m_dx3dResource.AddFont(L"Arial", 15, FW_BOLD, FALSE);
		break;
	default:
		break;
	}
	return FALSE;
}

D3DTLVERTEX CDlgNRSClientSample::CreateD3DTLVERTEX (float X, float Y, float Z, float RHW, D3DCOLOR color, float U, float V)
{	
	D3DTLVERTEX v;
	v.fX = X;	
	v.fY = Y;	
	v.fZ = Z;	
	v.fRHW = RHW;	
	v.Color = color;	
	v.fU = U;	
	v.fV = V;	

	return v;
}    //CreateD3DTLVERTEX

void CDlgNRSClientSample::DrawCircle(CPoint pt, float fRadius, D3DCOLOR color, LPDIRECT3DDEVICE9 lp3dDevice)
{
	D3DTLVERTEX d3dvTex[400];

	float x1 = pt.x;
	float y1 = pt.y;

	lp3dDevice->SetTexture(0, NULL);   

	for(int i=0; i<=363; i+=3)
	{
		float angle = (i / 50.3f);   // 57.3f
		float x2 = pt.x + (fRadius * sin(angle));
		float y2 = pt.y + (fRadius * cos(angle));

		d3dvTex[i] = CreateD3DTLVERTEX(pt.x, pt.y , 0, 1, color, 0, 0);   
		d3dvTex[i+1] = CreateD3DTLVERTEX(x1, y1, 0, 1, color, 0, 0);   
		d3dvTex[i+2] = CreateD3DTLVERTEX(x2, y2, 0, 1, color, 0, 0);   

		y1 = y2;
		x1 = x2;
	}

	lp3dDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 363, d3dvTex, sizeof(D3DTLVERTEX));
	//lp3dDevice->SetStreamSource(0, m_vb, 0, sizeof(CUSTOMVERTEX));
	//lp3dDevice->SetFVF( D3DFVF_CUSTOMVERTEX );

}

void CDlgNRSClientSample::Lock()
{
	EnterCriticalSection(&m_cs);
}

void CDlgNRSClientSample::Unlock()
{
	LeaveCriticalSection(&m_cs);
}

void CDlgNRSClientSample::SetSelectionIndex(int nCh)
{
	m_pLive1Disp->SetSelectIndex(nCh);
}

void CDlgNRSClientSample::OnBnClickedButtonNrsConnect()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	if (m_pNRSManager) 
	{
		AfxMessageBox(_T("�̹� ���� �Ǿ�����."));
		return;
	}


	NRS_SERVER_INFO si;
	si.nId			= 0;
	si.strServerId	= GetGlobalConfig().GetGUIDW();
	si.bEnable		= TRUE;
	si.strName		= _T("Record Service");
	m_edNrsIP.GetWindowText(si.strAddress);
	si.nPort		= DEFAULT_NCSERVICE_PORT;	
	m_edID.GetWindowText(si.strUserId);
	m_edPW.GetWindowText(si.strUserPassword);

	//GetGlobalConfig().m_mapNRS.insert(pair<size_t, NRS_SERVER_INFO>(si.nId, si));
	
	if (! m_pNRSManager)
		m_pNRSManager = new NRS::CNRSManage(si.nId, si.strServerId);

	m_pNRSManager->SetAddress(si.strAddress);
	m_pNRSManager->SetPort(si.nPort);
	m_pNRSManager->SetUser(si.strUserId, si.strUserPassword);
	m_pNRSManager->SetProtocol(NAUTILUS_V2);

	//Login 
	{
		// NRS ���� : GetClientIDReq 
		BOOL bConnected = m_pNRSManager->Connect(si.strAddress, si.nPort, si.strUserId, si.strUserPassword, 
				m_pNRSManager->GetProtocol(), m_pNRSManager->IsAsyncrousConnection());

		if(m_pNRSManager->IsAsyncrousConnection())
		{
			while(m_pNRSManager->IsConnecting())
			{
				APP_PUMP_MESSAGE(NULL, 0, 0);
				Sleep(1);
			}

			bConnected = m_pNRSManager->IsConnected();
			Sleep(300);
		}

		if (!bConnected)
		{
			AfxMessageBox(_T("Failed to connect the NRS"));
			return;
		}
	}	

	m_hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	m_hStatusThread = (HANDLE)_beginthreadex(NULL, 0, ShellCheckStatus, this, 0, NULL);

	//Recording Service�� ��ϵ� ��ġ ������ : GetAllStreamInfoReq
	BOOL bLoaded = m_pNRSManager->LoadRSDevices();  
	if ( bLoaded && GetGlobalConfig().m_mapDevices.size() > 0 )
	{
		m_listLog.ResetContent();
		std::map<wstring, std::tr1::shared_ptr<DEVICE_INFO>>::iterator itrDev;	
		
		CString strText; DWORD dwCnt = 0;
		itrDev = GetGlobalConfig().m_mapDevices.begin();
		while(itrDev != GetGlobalConfig().m_mapDevices.end())
		{
			strText.Format(_T("[%d] - %s \n"), dwCnt, itrDev->second->GetModel());
			m_listLog.AddString(strText);
			dwCnt++;
			itrDev++;
		}
	}
	
	m_btnDevRegister.EnableWindow(TRUE);
	GetDlgItem(IDC_BTN_PLAYBACK_VIEW)->EnableWindow(TRUE);

	//���� �����ϱ� ( ������ ������� 5���� ���� )  : StartRelayReq
	CString strDevID;
	DWORD dwIdx = 0;
	std::map<wstring, std::tr1::shared_ptr<DEVICE_INFO>>::iterator itrDev;	
	itrDev = GetGlobalConfig().m_mapDevices.begin();
	while(itrDev != GetGlobalConfig().m_mapDevices.end())
	{
		//���û� �׳� 5���� �����Ѵ�. 
		if (dwIdx >= 5)
			break;

		strDevID = itrDev->first.c_str();
		BOOL bConnect = m_pNRSManager->ConnectRelayStream(strDevID, NRS_RELAY_ALL);
		if(bConnect > 0)
		{
			m_pNRSManager->SetDisplay(strDevID, m_pLive1Disp, dwIdx);
		}

		dwIdx++;		
		itrDev++;
	}
}

void CDlgNRSClientSample::OnBnClickedButtonCameraRegister()
{
	m_edStatus.SetWindowText(_T(""));
	m_bStop = TRUE;

	CString strAddress;
	CString strUserID;
	CString strPW;
	m_edNrsIP.GetWindowText(strAddress);
	m_edID.GetWindowText(strUserID);
	m_edPW.GetWindowText(strPW);

	m_pDlgDevRegister	= new CDlgDeviceRegister(strAddress, strUserID, strPW, this);
	m_pDlgDevRegister->DoModal();

	m_pLive1Disp->ClearVideoAll();
	Sleep(1000);

	//�ٽ� �ε�
	GetGlobalConfig().RemoveDeviceAll();
	BOOL bLoaded = m_pNRSManager->LoadRSDevices();  

	CString strDevID;
	DWORD dwIdx = 0;
	if ( bLoaded && GetGlobalConfig().m_mapDevices.size() > 0 )
	{
		m_listLog.ResetContent();
		m_listLog.Invalidate();

		std::map<wstring, std::tr1::shared_ptr<DEVICE_INFO>>::iterator itrDev;	

		CString strText; DWORD dwCnt = 0;
		itrDev = GetGlobalConfig().m_mapDevices.begin();
		while(itrDev != GetGlobalConfig().m_mapDevices.end())
		{
			strText.Format(_T("[%d] - %s \n"), dwCnt, itrDev->second->GetModel());
			m_listLog.AddString(strText);

			dwCnt++;
			itrDev++;
		}
	}


	std::map<wstring, std::tr1::shared_ptr<DEVICE_INFO>>::iterator itrDev;	
	itrDev = GetGlobalConfig().m_mapDevices.begin();
	while(itrDev != GetGlobalConfig().m_mapDevices.end())
	{
		strDevID = itrDev->first.c_str();
		BOOL bConnect = m_pNRSManager->ConnectRelayStream(strDevID, NRS_RELAY_ALL);
		if(bConnect > 0)
		{
			m_pNRSManager->SetDisplay(strDevID, m_pLive1Disp, dwIdx);
		}

		dwIdx++;		
		itrDev++;
	}


	m_bStop = FALSE;
}

void CDlgNRSClientSample::OnBnClickedBtnPlaybackView()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	if(m_pNRSManager == NULL){
		AfxMessageBox(L"������ ������ �ּ���!", MB_OK | MB_ICONWARNING);
		return;
	}
	CDlgPlaybackView dlg(m_pNRSManager, this);
	dlg.DoModal();
}




UINT WINAPI CDlgNRSClientSample::ShellCheckStatus( LPVOID pParam )
{
	CDlgNRSClientSample *pCur = (CDlgNRSClientSample*)pParam;

	while (WaitForSingleObject(pCur->m_hEvent, 3000) == WAIT_TIMEOUT)
	{
		if (!pCur->m_bStop)
			pCur->CheckStatus();
	}
	
	return 0;
}

UINT CDlgNRSClientSample::CheckStatus()
{
	if (m_bClose) return 0;

	if ( m_pNRSManager->IsConnected() )
	{
		string SendStr, RecvStr;
		if ( m_pNRSManager->GetStreamStatusReq(SendStr) )
		{
			if (m_pNRSManager->SendRecvXML(SendStr.c_str(), RecvStr, 10000) != NO_ERROR)
			{
				TRACE(_T("Failed to get status all. \n"));
				return 1;
			}
			
			m_edStatus.SetWindowText(_T(""));
			CString strRecvValue;
			strRecvValue = __UTF8TOW(RecvStr.c_str()).c_str();
			m_edStatus.SetWindowText(strRecvValue);

		}

	}

	return 0;
}
