#pragma once

// CDlgCameraInfo ��ȭ �����Դϴ�.
//#include "ColorListBox.h"
#include "DlgLGcnsSample.h"

typedef enum _ALL_COMMAND
{
	CMD_INIT = 0,
	CMD_RESTART,
	CMD_RESET,
	CMD_DEFAULT,
	CMD_UPDATTE,
} ALL_CMD;

class CDlgCameraInfo : public CDialog
{
	DECLARE_DYNAMIC(CDlgCameraInfo)

public:
	CDlgCameraInfo(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.��
	virtual ~CDlgCameraInfo();

	CListCtrl m_listCamList;

	CDlgLGcnsSample *m_pDlgCat;
	//CColorListBox m_listLog;

	HANDLE m_hThreadAllCmd;
	int   AllCmd();
	//BOOL m_bStartAllCmd;

	CRITICAL_SECTION	m_cs;
		
// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DIALOG_CAMERA_LIST };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	ALL_CMD m_acCmd;

	CString m_strFwFileName;
	int m_nSelectedDevice;

	void Lock();
	void Unlock();

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnNMRClickListCameraConfig(NMHDR *pNMHDR, LRESULT *pResult);

protected:
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
public:
	afx_msg void OnBnClickedBtnAllRestart();
	afx_msg void OnBnClickedBtnAllReset();
	afx_msg void OnBnClickedBtnAllDefault();
	afx_msg void OnBnClickedBtnAllDelete();
	afx_msg void OnBnClickedBtnAllFwUpdate();
	afx_msg void OnBnClickedBtnAllRefresh();
	afx_msg void OnDestroy();
	afx_msg void OnBnClickedBtnAllCmdStop();
	afx_msg LRESULT OnChangeBtnInit(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnChangeListStatus(WPARAM wParam, LPARAM lParam);
	afx_msg void OnBnClickedOk();
	afx_msg void OnNMClickListCameraConfig(NMHDR *pNMHDR, LRESULT *pResult);
};
