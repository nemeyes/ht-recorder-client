#pragma once
#include "NRSBase.h"
#include <Buffer.h>
#include <MessageSender.h>

#define NRS_RELAY_NONE	0x00000000
#define NRS_RELAY_VIDEO	0x00000001
#define NRS_RELAY_AUDIO	0x00000002
#define NRS_RELAY_META 	0x00000004
#define NRS_RELAY_ALL       0x00000007

#define KBYTE								1024.0
#define MEGABYTE							1048576.0
#define GIGABYTE							1073741824.0

class CPlaybackStream;

enum PLAYBACK_DIRECTION
{
	PLAYBACK_DIRECTION_NONE	= 0,
	PLAYBACK_DIRECTION_FORWARD,
	PLAYBACK_DIRECTION_BACKWARD
};


typedef struct _NCStreamBuffer : public GRSTREAM_BUFFER
{
	_NCStreamBuffer() {}
	_NCStreamBuffer(const void* pData, size_t nDataSize)
		: Buffer(nDataSize)
		, nDate(0)
		, nTime(0)
		, nDecodeID(0)
		, bNoSkip(FALSE)
		, nCount(0)
		, nDecodeFailCount(0)
	{
		ZeroMemory(this, sizeof(GRSTREAM_BUFFER));
		nFrameType = -1;
		Buffer.Assign(pData, nDataSize);
	}

	CBuffer Buffer;
	struct __timeb64 tReceived;
	UINT	nDate;
	UINT	nTime;
	size_t	nDecodeID;
	BOOL	bNoSkip;
	size_t	nCount;
	int		nDecodeFailCount;

} NCStreamBuffer;

typedef struct _FRAME_SOURCE{
	int Id;
	CString Mac;
	int StreamIdx;
	int ChannelIdx;
	CString Profile;
	CString DeviceName;
}FRAME_SOURCE, *LPFRAME_SOURCE;

typedef struct{
	int nId;
	int nFrameSourceId;
	CString strFrameType;
	CString strDateTime;
	int nFileId;
	CString strDeviceName;
}EventItem;

// Disk ���� (PC�� ��� ��ũ ������ ���� ��������)
typedef struct _LOCAL_DISK_INFO
{
	_LOCAL_DISK_INFO() : nDriveType(DRIVE_UNKNOWN), dbTotal(0), dbUsed(0), dbTotalFree(0)
		, nRecordReserved(0)
		, nRecordUsed(0)
		, nCommitReserved(0)
	{}
	CString		strRootPath;
	CString		strDrive;
	CString		strVolumeSerial;
	UINT		nDriveType;

	double		dbTotal;						// ��ũ �� ũ��
	double		dbUsed;						// ��ũ ��뷮
	double		dbTotalFree;					// ��ũ ��������

	UINT64		nRecordReserved;			// ���ڵ� ���� ������
	UINT64		nRecordUsed;				// ���� ���ڵ� ������

	UINT64		nCommitReserved;			// ������ ���۵� ���ڵ� ������

} LOCAL_DISK_INFO, *LPLOCAL_DISK_INFO;

namespace NRS
{

	class CNRSStream;
	class CNRSManage : public CNRSBase, public CMessageSender
	{
	protected:
		friend class CNRSStream;
		
		NC_DEVICE_TYPE 	m_DeviceType;
		CString			m_strServerID;
		static size_t	 m_nVideoStreamCount;
	

		HANDLE m_hConnWaitEvent;
		CRITICAL_SECTION	m_csLive;
		std::map<std::wstring, std::tr1::shared_ptr<CNRSStream>> m_StreamMap;
		
		void	CheckStream(DWORD dwFlags);
		BOOL	CheckSafeStreamRelease();
		
	public:
		CNRSManage(size_t nId, LPCTSTR lpServerID);
		virtual ~CNRSManage(void);

		virtual void OnNotifyMessage(LiveNotifyMsg* pNotify);
		virtual void OnReceive(LPStreamData Data);
		virtual void Disconnect();
		BOOL IsLoadedConfig() const;
		//void ChangeDecodeVideoOutput(DISP_VIDEO_OUTPUT VideoOutput);
		void SetServerID(LPCTSTR lpServerID);
		CString	GetServerID() const;
		BOOL GetServer(std::tr1::shared_ptr<DEVICE_INFO>& DevicePtr);

		//������ ��ϵ� ��ġ ��� ��������
		BOOL LoadRSDevices();
		BOOL DoLoadRSDevices(MSXML2::IXMLDOMNodeListPtr pList);		//<-- CheckRSDevices

		virtual BOOL ConnectRelayStream(LPCTSTR lpszDeviceID, DWORD dwStreamFlag = NRS_RELAY_VIDEO | NRS_RELAY_AUDIO | NRS_RELAY_META,
														std::tr1::shared_ptr<CNRSStream> *pStreamPtrOut = NULL, std::tr1::shared_ptr<CNRSStream> *pStreamPtrIn = NULL);
		virtual BOOL UpdateRelayStream(LPCTSTR lpszDeviceID, DWORD dwStreamFlag = NRS_RELAY_VIDEO | NRS_RELAY_AUDIO | NRS_RELAY_META);
		void	DisconnectStream(LPCTSTR lpszDeviceID);
		void	DisconnectStreamAll();

		std::tr1::shared_ptr<CNRSStream> ClearStream(LPCTSTR lpszDeviceID);
		void	ClearStreamAll();
		BOOL SetDisplay(LPCTSTR lpszDeviceID, CDisplayLib* pDisp, size_t nChannel, BOOL bClearDisplay = TRUE);


	public:
		//��ġ �߰�, ����, ���� (�Ǵ� ���ڵ� ������ ����) ���� ������ϴ� ����
		BOOL GetKillStreamReq(std::tr1::shared_ptr<DEVICE_INFO> pDevice, std::string& Str);		
		BOOL IsKilledStreamReq(std::tr1::shared_ptr<DEVICE_INFO> pDevice, std::string& Str);

		//��ġ ���, ����
		BOOL GetUpdateStreamInfoReq(std::tr1::shared_ptr<DEVICE_INFO> pDevice, std::string& Str);
		
		//��ġ ����
		BOOL GetDeleteStreamInfoReq(std::tr1::shared_ptr<DEVICE_INFO> pDevice, std::string& Str);

		//��ġ Status ���� ��û
		BOOL GetStreamStatusReq(std::string& Str);		

		/////////////////////// PLAYBACK /////////////////////////
		void *m_pStream;

		// Month
		BOOL GetYearIndexReq(int nYear, std::vector<std::wstring>& vDevices, CBitArray* pMonthArray);
		BOOL _Proc_GetYearIndexRes(const char* pXML, CBitArray* pMonthArray);
		void SetMonthIndex(LPCTSTR lpDeviceID, const char* pIndexBase64, CBitArray* pMonthArray);

		// Day
		BOOL GetMonthIndexReq(int nYear, int nMonth, std::vector<std::wstring>& vDevices, CBitArray* pDayArray);
		BOOL _Proc_GetMonthIndexRes(const char* pXML, CBitArray* pDayArray);
		void SetDayIndex(LPCTSTR lpDeviceID, const char* pIndexBase64, CBitArray* pDayArray);

		// Hour
		BOOL GetDayIndexReq(int nYear, int nMonth, int nDay, std::vector<std::wstring>& vDevices, CBitArray* pHourArray);
		BOOL _Proc_GetDayIndexRes(const char* pXML, CBitArray* pHourArray);
		void SetHourIndex(LPCTSTR lpDeviceID, const char* pIndexBase64, CBitArray* pHourArray);


		// Min
		BOOL GetHourIndexReq(int nYear, int nMonth, int Day, int nHour, std::vector<std::wstring>& vDevices, CBitArray* pMinArray, CBitArray* pDupMinArray);
		BOOL _Proc_GetHourIndexRes(const char* pXML, CBitArray* pMinArray, CBitArray* pDupMinArray);
		void SetMinIndex(LPCTSTR lpDeviceID, const char* pIndexBase64, const char* pDupIndexBase64, CBitArray* pMinArray, CBitArray* pDupMinArray);
		
		// Play Connect
		BOOL ConnectPlayBackStream(CPlaybackStream *pPlaybackStream,
			int nYear, int nMonth, int nDay, int nHour, int nMin, 
			int nDeviceIdx,
			enum PLAYBACK_DIRECTION eDirection = PLAYBACK_DIRECTION_NONE,
			DWORD dwStreamFlags = NRS_RELAY_VIDEO | NRS_RELAY_AUDIO | NRS_RELAY_META, 
			int nOverlapID = 0);

		// Play DisConnect
		void DisconnectPlaybackStream();

		// Pause
		BOOL Pause(size_t nPlaybackID);
		// Resume
		BOOL Resume(size_t nPlaybackID);

		// Stop
		BOOL Stop(size_t nPlaybackID);

		// Play Direction(Playmm Backward Play)
		BOOL ControlPlayback(size_t nPlaybackID, LPCTSTR lpDirection, LPCTSTR lpSpeed, BOOL bOnlyKeyFrame);

		// Nest Step
		BOOL NextStep(size_t nPlaybackID);

		// Prev Step
		BOOL PrevStep(size_t nPlaybackID);


		/////////////////////// RECORDING /////////////////////////
		void Remote_CheckError(const char* pRecvStr);

		BOOL RemoteDiskInfo(std::map<std::wstring, LOCAL_DISK_INFO>& DiskMap);
		BOOL UpdateRecordingScheduleReq(std::vector<std::wstring>& vDevices);
		BOOL RecordingOverwriteReq();
		BOOL ReserveDiskSizeReq(std::map<std::wstring, LOCAL_DISK_INFO> DiskMap);
		BOOL UpdateDiskPolicyReq(std::vector<std::wstring> Mac, 
										 std::map<std::wstring, LOCAL_DISK_INFO> DiskMap);

		BOOL StartRecordingAllReq();
		BOOL StopRecordingAllReq();
	};
};