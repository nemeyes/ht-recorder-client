#pragma once
#include "resource.h"
#include "NRSManageII.h"
#include "DlgRecordingView.h"

// CDlgDeviceRegister ��ȭ �����Դϴ�.

class CDlgDeviceRegister : public CDialog
{
	DECLARE_DYNAMIC(CDlgDeviceRegister)

public:
	CDlgDeviceRegister(CString strAddress, CString strID, CString strPW, CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CDlgDeviceRegister();

	int GetDeviceSelected() { return m_listDevs.GetSelectionMark(); }
	
// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DIALOG_DEVICE_LIST };

protected:
	NRS::CNRSManage *m_pNRSManager;

	CString m_strAddress;
	CString m_strID;
	CString m_strPW;

	CEdit	m_edStreamID;
	CEdit	m_edMAC;
	CEdit m_edProfile;
	CEdit m_edModelName;
	CEdit m_edDevIP;
	CEdit m_edDevUrl;
	CEdit m_edDevRTSPport;
	CEdit m_edOnvifUrl;
	CComboBox m_cbModelType;
	CComboBox m_cbConnType;
	CListCtrl	m_listDevs;

	BOOL m_bConnected;
	BOOL m_bHitronModel;

protected:
	void InitUI();
	void EnableUI(BOOL bOnOff);
	void GetDevListAll();
	CString CheckandNewMac();

	int CheckResValue(std::string RecvStr);

	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:

	virtual BOOL OnInitDialog();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnDestroy();
	afx_msg void OnClose();
	afx_msg void OnBnClickedButtonMakeStreamid();
	afx_msg void OnBnClickedBtnDevAdd();
	afx_msg void OnNMClickListDevs(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedBtnDevModify();
	afx_msg void OnBnClickedBtnDevDelete();
	afx_msg void OnBnClickedBtnClear();
	afx_msg void OnCbnSelchangeComboModelType();
	afx_msg void OnBnClickedBtnRecordingSetup();
};
