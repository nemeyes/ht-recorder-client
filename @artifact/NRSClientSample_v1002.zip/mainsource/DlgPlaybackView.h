#pragma once

#include "NRSManageII.h"

#define MAX_PLAYBACK_CH   (16)
#define  MAX_MONTH		    (12)
#define  MAX_DAY				(31)
#define  MAX_HOUR			(24)
#define  MAX_MINUTE			(60)

class CPlaybackStream;
// CDlgPlaybackView ��ȭ �����Դϴ�.

typedef enum
{
	INIT	= 0,  // STOP
	PLAY,         // RESUME
	BACK_PLAY,
	PAUSE,
	PREV_STEP,
	NEXT_STEP
} PLAYBACK_STATUS;

class CDlgPlaybackView : public CDialog
{
	DECLARE_DYNAMIC(CDlgPlaybackView)

public:
	CDlgPlaybackView(NRS::CNRSManage *pNrs, CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CDlgPlaybackView();

	CDisplayLib *m_pDisp;
	NRS::CNRSManage *m_pNrsManage;
	
	//void *m_pPlaybackStream;
	CPlaybackStream *m_pPlaybackStream;    // Playback Stream Data�� ���� Ŭ����
		
// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DLG_PLAYBACK_VIEW };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
	
	PLAYBACK_STATUS m_PlaybackStatus;
	BOOL m_bPlaybackStart;

	void DeleteDisplayLib();

	CComboBox m_cbDevice;
	
	CComboBox m_cbYear;
	CComboBox m_cbMonth;
	CComboBox m_cbDay;
	CComboBox m_cbHour;
	CComboBox m_cbMin;

	void InitYear();
	BOOL ChangeYear();

	void InitMonth(int nIdx, int nMonth);
	BOOL ChangeMonth();

	void InitDay(int nIdx, int nDay);
	BOOL ChangeDay();

	void InitHour(int nIdx, int nHour);
	BOOL ChangeHour();

	void InitMin(int nIdx, int nMin);

	void InitDataTime(BOOL bMonth=TRUE, BOOL bDay=TRUE, BOOL bHour=TRUE, BOOL bMin=TRUE);
	
	BOOL PlaybackTimeChecker();

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnCbnSelchangeComboDevice();
	afx_msg void OnCbnSelchangeComboYear();
	afx_msg void OnCbnSelchangeComboMonth();
	afx_msg void OnCbnSelchangeComboDay();
	afx_msg void OnCbnSelchangeComboHour();
	afx_msg void OnBnClickedBtnPlay();
	afx_msg void OnBnClickedBtnStop();
	afx_msg void OnBnClickedBtnPause();
	afx_msg void OnBnClickedBtnBackward();
	afx_msg void OnBnClickedBtnPrevStep();
	afx_msg void OnBnClickedBtnNextStep();
};


/////////////////////////////////////////////////////////////
//////////////// Playback Stream ///////////////////////
/////////////////////////////////////////////////////////////
typedef struct
{
	AVMEDIA_TYPE avt_Type;
	UINT32		ui32_Stream;
	SIZE			szVideoSize;
}PLAYBACK_INFO;          // Playback ���� ����ü

class CPlaybackStream : public IStreamReceiver5
{
public:
	CPlaybackStream(CDlgPlaybackView *pDlgPlaybackView);
	virtual ~CPlaybackStream();

	CDlgPlaybackView *m_pDlgPlaybackview;

	virtual void OnNotifyMessage(LiveNotifyMsg* pNotify);     // Playback ���� �޼��� ���� ��
	virtual void OnReceive(LPStreamData Data);		              // Playback Stream Data�� ���� ��

	string m_Keys[MAX_PLAYBACK_CH];                   // Playback ä�� �� ��ŭ Ű ����
	void AddCallbackFunc();       

	queue<NCStreamBuffer*> m_Queue;                 // Playback Stream Data�� ���� ť
	CRITICAL_SECTION	m_cs;                    

	static void __stdcall _Work(void* arg, size_t key);    // ���ڵ� �� ȭ�鿡 �ѷ��� ������
	void Work(size_t key);                         
	
	void	Lock();
	void	Unlock();

	size_t GetPlaybackID(){ return m_nPlaybackID; }
	void SetPlaybackID(int nID)
	{
		if(m_nPlaybackID == nID) return;

		m_nPlaybackID = nID;
	};

	void ClearBuffer();

protected:
	size_t				m_nPlaybackID;

	CDecoder m_Decoder[MAX_PLAYBACK_CH];
	void CloseDecorder();
	void ClearWorkerFunc();

	PLAYBACK_INFO m_PbInfo[MAX_PLAYBACK_CH];

	void InitPbInfo();
	void InsertPbInfo(int nIdx, AVMEDIA_TYPE avt_Type, UINT32 ui32Width, UINT32 ui32Height);
};