#pragma once
#include "DlgNRSClientSample.h"
#include "NRSManageII.h"
#include <LiveSession5/NRS_T.h>


//class CDisplayBase;

namespace NRS
{
	//	Relay Stream Class
	class CNRSStream 	: public IStreamReceiver5
	{
	public:
		CNRSStream(CNRSManage& NRS, size_t nId, LPCTSTR lpszDeviceID, DWORD dwStreamFlags = NRS_RELAY_VIDEO | NRS_RELAY_AUDIO | NRS_RELAY_META);
		virtual ~CNRSStream();

		static CNRSStream* CreateStream(CNRSManage& NRS, size_t nId, LPCTSTR lpszDeviceID, DWORD dwStreamFlags = NRS_RELAY_VIDEO | NRS_RELAY_AUDIO | NRS_RELAY_META);
		static void DeleteStream(CNRSStream* pStream);

		virtual void OnNotifyMessage(LiveNotifyMsg* pNotify);
		virtual void OnReceive(LPStreamData Data);
		virtual void Disconnect();
		virtual	void SetNRSEvent(NRS::FRAME_TYPE FrameType, NRS::MetaFrameUnion* pFrame, BOOL bUpdateNow = FALSE);

		static void __stdcall _Work(void* arg, size_t key);
		void Work(size_t key);

		int		Reconnect();
		void	ClearBuffer(BOOL bAfterMetaOnly = FALSE, BOOL bCloseCodec = FALSE);

		void	SetHandle(void* pStreamHandle);
		void*	GetHandle();

		size_t	GetDisplayCount();
		SIZE	GetVideoSize() const;

		void	EnableDecodeAudio(BOOL bEnable);
		BOOL	IsDecodeAudio();

		//void	AddDisplayWindow(CDisplayBase* pDisplayWnd);
		//void	RemoveDisplayWindow(CDisplayBase* pDisplayWnd);

		wstring	GetDeviceID() const { return m_sDeviceID; }

		static void SetEnableVideoSync(BOOL bEnable) { m_bEnableVideoSync = bEnable; }
		static LONG IncreaseWorkKey();

		virtual void GetCaptureAudio(char *pData, unsigned long lDataLen, LPVOID arg);
		void	GetAudioInfo(AVMEDIA_TYPE &AudioType, int &nBitrate, int &nSampleRate);
		BOOL	StartAudioCapture();
		void	StopAudioCapture();

		BOOL	IsGetResponseRelay() const { return m_bIsResponseRelay; }
		BOOL	IsNoDeviceStream() const { return m_bNoDeviceStream; }

		void	SetVideoFilter(UINT nFilter = 0);
		UINT	GetVideoFilter() const;

		size_t	GetID() const { return m_nId; }

		void CheckEventStatus(__timeb64& tReceived);

	protected:
		void	Lock();
		void	TryLock();
		void	Unlock();

		void	Lock2();
		void	TryLock2();
		void	Unlock2();

		static BOOL			m_bEnableVideoSync;

		size_t		m_nId;
		DWORD		m_dwStreamFlags;
		wstring		m_sDeviceID;
		void*		m_pHandle;
		CNRSManage& m_NRS;
		CDecoder	m_Decode;
		//std::list<shared_ptr<NCStreamBuffer>> m_Queue;
		std::list<NCStreamBuffer*> m_Queue;
		CRITICAL_SECTION	m_cs;
		BOOL		m_bIsConnecting;
		BOOL		m_bIsConnected;
		BOOL				m_bIsConnectionStop;	// ��������� true

		size_t		m_nThreadId;
		size_t		m_nWorkKey;

		std::string		m_sDecodeKey;
		BYTE			m_Key[8];
		AVMEDIA_TYPE	m_VideoType;
		SIZE			m_VideoSize;
		
		AVMEDIA_TYPE	m_AudioType;
		int				m_AudioBitRate;
		int				m_AudioSampleRate;

		CBuffer			m_VideoExtraData;
		CBuffer			m_AudioExtraData;
		__timeb64			m_tLastUpdate;

		BOOL				m_bFindFirstKey;
		BOOL				m_bMetaOnly;
		LONG				m_lRunWorker;

		static LONG			m_nCount;

		// When video or audio status is changed
		HWND			m_hNotifyWnd;

		EVENT_INFO_T		m_EventUpdate;
		NRS::MetaFrameUnion	m_MetaFrame;
		
		// �̺�Ʈ �߻��� ȭ�� ǥ������ ������ ������!!
		//std::set<CDisplayBase*>	m_DisplaySet;
		CRITICAL_SECTION	m_cs2;

		time_t				m_tVideo;
		size_t				m_nVideoCount;
		clock_t				m_tVideoClock;
		size_t				m_nVideoFrameRate;
		size_t				m_nArIndex;
		float				m_fArVideoRate[3];

		time_t				m_tAudio;
		size_t				m_nAudioCount;

		BOOL				m_bNoDeviceStream;
		BOOL				m_bIsResponseRelay;	// StartRelayRes�� �޾Ҵ��� üũ�ϱ� ����!!

		BOOL				m_bCaptureAudio;
		//CAudioCapture		*m_pAudioCapture;
		CEncoder			m_Encoder;

		UINT				m_nVideoFilter;

		friend class CNRSManage;
	};
};
