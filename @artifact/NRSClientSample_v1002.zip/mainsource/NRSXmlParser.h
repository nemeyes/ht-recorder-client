#pragma once

namespace NRS
{
	class CNRSBase;

	typedef void (CALLBACK* LPNRS_RECEIVEDATAFUNCTION)(const void* pData, size_t nDataSize, void* pUserContext);
	typedef struct _NRS_RECEIVEDATAFUNCTION_T
	{
		_NRS_RECEIVEDATAFUNCTION_T() :func(NULL),pNrs(NULL),pUserContext(NULL) {}
		LPNRS_RECEIVEDATAFUNCTION func;
		void* pUserContext;
		__timeb64 t;
		CNRSBase* pNrs;

	} NRS_RECEIVEDATAFUNCTION_T, *LPNRS_RECEIVEDATAFUNCTION_T;

	class CNRSXmlParser
	{
	public:
		typedef struct _STREAM_INFO
		{
			_STREAM_INFO() :pStreamHandel(NULL) {}
			size_t	nId;
			CString	strMAC;
			CString	strProfile;
			CString	strAddress;
			CString	strModel;
			CString strModelType;
			CString strUrl;

			UINT	nRtspPort;
			UINT	nHttpPort;
			UINT	nHttpsPort;
			BOOL	bSSL;
			void*	pStreamHandel;

		} STREAM_INFO;

		CNRSXmlParser(CNRSBase* pNrs);
		virtual ~CNRSXmlParser(void);

		int		Process(const char *pXML, size_t nSize);

		int		GetClientId() const { return m_nClientId; }
		void	ClearStreamListAll();
		BOOL	IsEqualReqId(CString& strReqId);
		CString	GetReqId() const { return m_strReqId; }

		void	AddNotifyCallback(LPCTSTR pNodeName, LPNRS_RECEIVEDATAFUNCTION Func, void* pUserContext);
		void	RemoveNotifyCallback(LPCTSTR pNodeName);

	protected:
		int _ProcessXML_GetClientIDRes(MSXML2::IXMLDOMNodePtr pNode);
		int _ProcessXML_GetAllStreamInfoRes(MSXML2::IXMLDOMNodeListPtr pList);
		int _ProcessXML_LoadMSConfigRes(MSXML2::IXMLDOMNodeListPtr pList);

		int m_nClientId;
		CString	m_strReqId;
		CNRSBase*	m_pNrs;
		std::multimap<wstring, STREAM_INFO*> m_StreamMultiMap;
		std::map<std::wstring, NRS_RECEIVEDATAFUNCTION_T>	m_callbackNotifyMap;

		CRITICAL_SECTION m_csCallback;
	};

};