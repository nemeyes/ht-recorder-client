#include "StdAfx.h"
#include "GlobalConfigII.h"
#include <Crypt.h>
#include <crypt/base64.h>
#include <crypt/md5.h>
#include <string_helper.h>

CGlobalConfig::CGlobalConfig( LPCTSTR lpszConfigXml /*= NULL*/, NRS::CNRSBase* pRemote /*= NULL*/ )
:m_pGUID(NULL)
{
	m_pGUID = new GUID();
}

CGlobalConfig::~CGlobalConfig( void )
{
	if(m_pGUID)
	{
		delete m_pGUID;
		m_pGUID = NULL;
	}

}

CStringW CGlobalConfig::GetGUIDW()
{
	CStringW strGUID;

	CoCreateGuid(m_pGUID);

	RPC_WSTR guid;
	UuidToStringW(m_pGUID, &guid);

	strGUID.Format(_T("%s"), guid);

	RpcStringFreeW(&guid);

	return strGUID;

}

CStringA CGlobalConfig::GetGUIDA()
{
	CStringA strGUID;

	CoCreateGuid(m_pGUID);

	RPC_CSTR guid;
	UuidToStringA(m_pGUID, &guid);

	strGUID.Format("%s", guid);

	RpcStringFreeA(&guid);

	return strGUID;

}

std::string CGlobalConfig::EncodeMD5( const std::string& str )
{
	if(str.empty())
		return "";

	std::string s;
	unsigned char digest[16];
	char sResult[36];
	MD5_CTX context;
	MD5Init(&context);
	MD5Update(&context, (unsigned char*)str.c_str(), str.size());
	MD5Final(digest, &context);

	int nCount = sizeof(digest);
	memset(sResult, 0, sizeof(sResult));
	for(int i=0; i<nCount; i++)
		sprintf(sResult + (i*2), "%02x", digest[i]);

	s = sResult;

	return s;
}

std::wstring CGlobalConfig::EncodeMD5( const std::wstring& str )
{
	string temp = WStringToAString(str.c_str());
	return AStringToWString( EncodeMD5(temp).c_str() );
}

void CGlobalConfig::RemoveDeviceAll()
{
	map<wstring, std::tr1::shared_ptr<DEVICE_INFO>>::iterator itrDevice = m_mapDevices.begin();
	while(itrDevice != m_mapDevices.end())
	{
		itrDevice->second->Free();
		itrDevice++;
	}

	m_mapDevices.clear();
}

BOOL CGlobalConfig::GetDevice( std::tr1::shared_ptr<DEVICE_INFO>& DevicePtr, LPCTSTR lpDeviceID )
{
	if(lpDeviceID)
	{
		map<wstring, std::tr1::shared_ptr<DEVICE_INFO>>::iterator itrDevice = m_mapDevices.find(lpDeviceID);
		if(itrDevice != m_mapDevices.end())
		{
			DevicePtr = itrDevice->second;
			return TRUE;
		}
	}

	DevicePtr.reset();
	return FALSE;

}