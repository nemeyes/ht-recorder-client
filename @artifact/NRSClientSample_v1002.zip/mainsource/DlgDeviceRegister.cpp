// DlgDeviceRegister.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NRSClientSample.h"
#include "DlgNRSClientSample.h"
#include "DlgDeviceRegister.h"
#include "GlobalConfigII.h"


#define HT_SMODEL		_T("SModel")
#define HT_HMODEL		_T("HModel")
#define HT_ONVIF			_T("ONVIF")



// CDlgDeviceRegister ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CDlgDeviceRegister, CDialog)

CDlgDeviceRegister::CDlgDeviceRegister( CString strAddress, CString strID, CString strPW, CWnd* pParent /*= NULL*/ )
	: CDialog(CDlgDeviceRegister::IDD, pParent)
	, m_strAddress(strAddress)
	, m_strID(strID)
	, m_strPW(strPW)
{
	m_pNRSManager = NULL;
	m_bConnected	= FALSE;
	srand( (unsigned int)time(NULL) );
}

CDlgDeviceRegister::~CDlgDeviceRegister()
{
}

void CDlgDeviceRegister::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_STREAMID, m_edStreamID);
	DDX_Control(pDX, IDC_EDIT_MAC, m_edMAC);
	DDX_Control(pDX, IDC_EDIT_PROFILE, m_edProfile);
	DDX_Control(pDX, IDC_EDIT_MODEL_NAME, m_edModelName);
	DDX_Control(pDX, IDC_EDIT_DEV_IP, m_edDevIP);
	DDX_Control(pDX, IDC_EDIT_DEV_URL, m_edDevUrl);
	DDX_Control(pDX, IDC_EDIT_DEV_PORT, m_edDevRTSPport);
	DDX_Control(pDX, IDC_EDIT_ONVIF_URL, m_edOnvifUrl);
	DDX_Control(pDX, IDC_COMBO_MODEL_TYPE, m_cbModelType);
	DDX_Control(pDX, IDC_COMBO_CONN_TYPE, m_cbConnType);
	DDX_Control(pDX, IDC_COMBO_CONN_TYPE, m_cbConnType);
	DDX_Control(pDX, IDC_LIST_DEVS, m_listDevs);

}

BEGIN_MESSAGE_MAP(CDlgDeviceRegister, CDialog)
	ON_WM_SIZE()
	ON_WM_DESTROY()
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_BUTTON_MAKE_STREAMID, &CDlgDeviceRegister::OnBnClickedButtonMakeStreamid)
	ON_BN_CLICKED(IDC_BTN_DEV_ADD, &CDlgDeviceRegister::OnBnClickedBtnDevAdd)
	ON_NOTIFY(NM_CLICK, IDC_LIST_DEVS, &CDlgDeviceRegister::OnNMClickListDevs)
	ON_BN_CLICKED(IDC_BTN_DEV_MODIFY, &CDlgDeviceRegister::OnBnClickedBtnDevModify)
	ON_BN_CLICKED(IDC_BTN_DEV_DELETE, &CDlgDeviceRegister::OnBnClickedBtnDevDelete)
	ON_BN_CLICKED(IDC_BTN_CLEAR, &CDlgDeviceRegister::OnBnClickedBtnClear)
	ON_CBN_SELCHANGE(IDC_COMBO_MODEL_TYPE, &CDlgDeviceRegister::OnCbnSelchangeComboModelType)
	ON_BN_CLICKED(IDC_BTN_RECORDING_SETUP, &CDlgDeviceRegister::OnBnClickedBtnRecordingSetup)
END_MESSAGE_MAP()


// CDlgDeviceRegister �޽��� ó�����Դϴ�.

BOOL CDlgDeviceRegister::OnInitDialog()
{
	CDialog::OnInitDialog();

	NRS_SERVER_INFO si;
	si.nId			= 1;
	si.strServerId	= GetGlobalConfig().GetGUIDW();
	si.bEnable		= TRUE;
	si.strName		= _T("Record Service");
	si.strAddress	= m_strAddress;
	si.nPort			= DEFAULT_NCSERVICE_PORT;	
	si.strUserId		= m_strID;
	si.strUserPassword = m_strPW;

	m_pNRSManager = new NRS::CNRSManage(si.nId, si.strServerId);
	m_pNRSManager->SetAddress(si.strAddress);
	m_pNRSManager->SetPort(si.nPort);
	m_pNRSManager->SetUser(si.strUserId, si.strUserPassword);
	m_pNRSManager->SetProtocol(NAUTILUS_V2_SETUP);
	m_bConnected = m_pNRSManager->Connect(si.strAddress, si.nPort, si.strUserId, si.strUserPassword, m_pNRSManager->GetProtocol(), FALSE);	

	if (! m_bConnected)
		AfxMessageBox(_T("NRS Setup�� ���� ���� \n"));


	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//�ڵ� �˻��� �ƴ� Manual�� ī�޶� ��������� Hitron ������ �����ϰ� ���ð��� ���ϵ��� �ߴ�.
	//���� Hitron ī�޶� �ƴ� ��� �ٸ� �������� Ȱ��ȭ ���Ѽ� �Է��ϰ� �׽�Ʈ �غ���.
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	BOOL m_bHitronModel = TRUE;
	InitUI();

	if (m_bHitronModel)
	{
		m_cbModelType.InsertString(0, HT_SMODEL);
		m_cbModelType.InsertString(1, HT_HMODEL);
		m_cbModelType.InsertString(2, HT_ONVIF);
		m_cbModelType.SetCurSel(0);

		//<!-- 1. RTP over UDP 2. RTP over RTSP (TCP) 3. RTP over RTSP over HTTP (TCP) 4. RTP Multicast -->
		m_cbConnType.InsertString(0, _T("2"));
		m_cbConnType.InsertString(1, _T("etc"));
		m_cbConnType.SetCurSel(0);

		EnableUI(FALSE);
	}
	
	int nCol = 0;
	m_listDevs.InsertColumn(nCol++, _T("StreamID"), LVCFMT_CENTER, 100);
	m_listDevs.InsertColumn(nCol++, _T("Dev Type"), LVCFMT_CENTER, 100);
	m_listDevs.InsertColumn(nCol++, _T("MAC"), LVCFMT_CENTER, 100);
	m_listDevs.InsertColumn(nCol++, _T("Profile"), LVCFMT_CENTER, 100);
	m_listDevs.InsertColumn(nCol++, _T("ModelType"), LVCFMT_CENTER, 100);
	m_listDevs.InsertColumn(nCol++, _T("Dev Name"), LVCFMT_CENTER, 100);
	m_listDevs.InsertColumn(nCol++, _T("Dev IP"), LVCFMT_CENTER, 100);
	m_listDevs.InsertColumn(nCol++, _T("Dev Url"), LVCFMT_CENTER, 100);
	m_listDevs.InsertColumn(nCol++, _T("Dev RTSP port"), LVCFMT_CENTER, 100);
	m_listDevs.InsertColumn(nCol++, _T("Conn Type"), LVCFMT_CENTER, 100);
	m_listDevs.InsertColumn(nCol++, _T("OnvifUrl"), LVCFMT_CENTER, 100);

	GetDevListAll();

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CDlgDeviceRegister::OnSize(UINT nType, int cx, int cy)
{
	CDialog::OnSize(nType, cx, cy);

}

void CDlgDeviceRegister::OnDestroy()
{
	CDialog::OnDestroy();

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	
	int nCnt = GetGlobalConfig().m_mapDevices.size();
	TRACE(_T("\n >> Close : m_mapDevices Count= %d \n"), nCnt);

}

void CDlgDeviceRegister::OnClose()
{
	if (m_pNRSManager)
	{
		m_pNRSManager->Disconnect();

		delete m_pNRSManager;
		m_pNRSManager = NULL;
	}

	EndDialog(IDOK);
}

void CDlgDeviceRegister::OnBnClickedButtonMakeStreamid()
{
	CString strStreamID = GetGlobalConfig().GetGUIDW();
	m_edStreamID.SetWindowText(strStreamID);	
}

void CDlgDeviceRegister::GetDevListAll()
{
	int nCnt = GetGlobalConfig().m_mapDevices.size();
	TRACE(_T("\n >> Init : m_mapDevices Count= %d \n"), nCnt);

	if ( GetGlobalConfig().m_mapDevices.size() > 0 )
	{
		m_listDevs.DeleteAllItems();
		std::map<wstring, std::tr1::shared_ptr<DEVICE_INFO>>::iterator itrDev;	

		CString strText; 
		DWORD dwCnt = 0;
		
		std::tr1::shared_ptr<DEVICE_INFO> pDevice;

		itrDev = GetGlobalConfig().m_mapDevices.begin();
		while(itrDev != GetGlobalConfig().m_mapDevices.end())
		{
			pDevice = itrDev->second;
			
			m_listDevs.InsertItem(dwCnt, pDevice->GetID());
			m_listDevs.SetItemText(dwCnt, 0, pDevice->GetID());

			CString strDevType = pDevice->isDependOnNrs() ? _T("Hitron or Onvif") : _T("Unknown");
			m_listDevs.SetItemText(dwCnt, 1, strDevType);
			m_listDevs.SetItemText(dwCnt, 2, pDevice->GetMAC());
			m_listDevs.SetItemText(dwCnt, 3, pDevice->GetProfileName());
			m_listDevs.SetItemText(dwCnt, 4, pDevice->GetModelType());
			m_listDevs.SetItemText(dwCnt, 5, pDevice->GetModel());
			m_listDevs.SetItemText(dwCnt, 6, pDevice->GetAddress());
			m_listDevs.SetItemText(dwCnt, 7, pDevice->GetURL());
			CString strRTSPport;
			strRTSPport.Format(_T("%d"), pDevice->GetRTSPPort());
			m_listDevs.SetItemText(dwCnt, 8, strRTSPport);
			CString strConnType;
			strConnType.Format(_T("%d"), pDevice->GetConnectionType());
			m_listDevs.SetItemText(dwCnt, 9, strConnType);
			m_listDevs.SetItemText(dwCnt, 10, pDevice->GetOnvifServiceUri());
			
			dwCnt++;
			itrDev++;
		}
	}

}

void CDlgDeviceRegister::OnBnClickedBtnDevAdd()
{
	CString strStreamID(_T(""));
	m_edStreamID.GetWindowText(strStreamID);

	if (! strStreamID.IsEmpty())
	{
		AfxMessageBox(_T("clear ��ư�� ������ Add �ϼ���"));
		return;
	}

	CString strDevIP;
	m_edDevIP.GetWindowText(strDevIP);
	if (strDevIP.GetLength() <= 0)
	{
		AfxMessageBox(_T("��ġ IP �Է��ϼ���. "));
		return;
	}

	strStreamID = GetGlobalConfig().GetGUIDW();
	m_edStreamID.SetWindowText(strStreamID);
	CString strMac = CheckandNewMac();
	m_edMAC.SetWindowText(strMac);

	int nSelect = m_cbModelType.GetCurSel();
	CString strModelType;
	m_cbModelType.GetLBText(nSelect, strModelType);

	OnCbnSelchangeComboModelType();

	CString strDevName;
	m_edModelName.GetWindowText(strDevName);

	if (strDevName.GetLength() <= 0)
		strDevName = _T("DEFAULT");

	m_edModelName.SetWindowText(strDevName);

	CString strProfile;
	m_edProfile.GetWindowText(strProfile);

	CString strDevUrl;	
	if ( nSelect < 2 )
	{
		strDevUrl = _T("rtsp://") + strDevIP + strProfile;
		m_edDevUrl.SetWindowText(strDevUrl);
	} else {
		m_edDevUrl.GetWindowText(strDevUrl);
	}

	m_edDevRTSPport.SetWindowText(_T("554"));

	CString strOnvifUrl;
	m_edOnvifUrl.GetWindowText(strOnvifUrl);

	//��ġ �߰�
	//////////////////////////////////////////////////////////////////////////
	std::tr1::shared_ptr<DEVICE_INFO> pDevice(new DEVICE_INFO);
	
	pDevice->SetDeviceType(NC_DEVICE_HITRON_CAMERA);
	pDevice->SetID( strStreamID );
	pDevice->SetMAC(strMac);
	pDevice->SetProfileName(strProfile);
	pDevice->SetModelType(strModelType);
	pDevice->SetModel(strDevName);
	pDevice->SetAddress(strDevIP);
	pDevice->SetURL(strDevUrl);
	pDevice->SetRTSPPort(554);
	pDevice->SetHTTPPort(80);
	pDevice->SetHTTPSPort(443);
	pDevice->SetSSL(FALSE);
	pDevice->SetConnectionType(2);
	pDevice->SetOnvifServiceUri(strOnvifUrl);
	pDevice->SetName( strDevName + strMac );
	pDevice->SetUser(_T("admin"));
	pDevice->SetPassword(_T("admin"));
	GetGlobalConfig().m_mapDevices.insert( pair<wstring, std::tr1::shared_ptr<DEVICE_INFO>>( (LPCTSTR)strStreamID, pDevice ) );
	//////////////////////////////////////////////////////////////////////////

	//������ �߰��� ��ġ ����
	std::string SendStr, RecvStr;
	if ( m_pNRSManager->GetUpdateStreamInfoReq(pDevice, SendStr) )
	{
		if (m_pNRSManager->SendRecvXML(SendStr.c_str(), RecvStr) != NO_ERROR )
		{
			AfxMessageBox(_T("Failed to Add the device."));
			return;
		}
	}
	CheckResValue(RecvStr);

	InitUI();

	DWORD dwCnt = m_listDevs.GetItemCount();
	m_listDevs.InsertItem(dwCnt, pDevice->GetID());
	m_listDevs.SetItemText(dwCnt, 0, pDevice->GetID());
	CString strDevType = pDevice->isDependOnNrs() ? _T("Hitron or Onvif") : _T("Unknown");
	m_listDevs.SetItemText(dwCnt, 1, strDevType);
	m_listDevs.SetItemText(dwCnt, 2, pDevice->GetMAC());
	m_listDevs.SetItemText(dwCnt, 3, pDevice->GetProfileName());
	m_listDevs.SetItemText(dwCnt, 4, pDevice->GetModelType());
	m_listDevs.SetItemText(dwCnt, 5, pDevice->GetModel());
	m_listDevs.SetItemText(dwCnt, 6, pDevice->GetAddress());
	m_listDevs.SetItemText(dwCnt, 7, pDevice->GetURL());
	CString strRTSPport;
	strRTSPport.Format(_T("%d"), pDevice->GetRTSPPort());
	m_listDevs.SetItemText(dwCnt, 8, strRTSPport);
	CString strConnType;
	strConnType.Format(_T("%d"), pDevice->GetConnectionType());
	m_listDevs.SetItemText(dwCnt, 9, strConnType);
	m_listDevs.SetItemText(dwCnt, 10, pDevice->GetOnvifServiceUri());
}

void CDlgDeviceRegister::OnBnClickedBtnDevModify()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	CString strStreamID;
	m_edStreamID.GetWindowText(strStreamID);

	std::tr1::shared_ptr<DEVICE_INFO> pDevice;
	if(!GetGlobalConfig().GetDevice(pDevice, strStreamID))
	{
		AfxMessageBox(_T("Device is deleted or It is not exist."));
		return;
	}
	
	//���õ� ��ġ�� ������̶�� ���� ���� 
	std::string SendStr, RecvStr;
	if ( m_pNRSManager->GetKillStreamReq(pDevice, SendStr) )
	{
		if (m_pNRSManager->SendRecvXML(SendStr.c_str(), RecvStr) != NO_ERROR )		
		{
			AfxMessageBox(_T("Failed to KillStreamReq"));
			return;
		}
	}


	//�������� ��ġȭ ������ ����Ǿ����� Ȯ���� ���� ���� ����
	int nLoop = 0;
	CString strXML, strTemp;
	do
	{
			Sleep(1000);

			if ( m_pNRSManager->IsKilledStreamReq(pDevice, SendStr))
			{
				if(m_pNRSManager->SendRecvXML(SendStr.c_str(), RecvStr) != NO_ERROR)
					TRACE(_T(" ���� ������?? \n"));
			}
			
			int nRet = CheckResValue(RecvStr);

			if (nRet==1)
				break;
			
			continue;

	} while(nLoop++ < 60);	


	CString strMac;
	m_edMAC.GetWindowText(strMac);

	int nSelect = m_cbModelType.GetCurSel();
	CString strModelType;
	m_cbModelType.GetLBText(nSelect, strModelType);

	OnCbnSelchangeComboModelType();

	CString strDevName;
	m_edModelName.GetWindowText(strDevName);
	if (strDevName.GetLength() <= 0)
		strDevName = _T("DEFALT_NAME");

	CString strProfile;
	m_edProfile.GetWindowText(strProfile);

	CString strDevIP;
	m_edDevIP.GetWindowText(strDevIP);

	CString strDevUrl;	
	if ( nSelect < 2 )
	{
		strDevUrl = _T("rtsp://") + strDevIP + strProfile;
		m_edDevUrl.SetWindowText(strDevUrl);
	} else {
		m_edDevUrl.GetWindowText(strDevUrl);
	}

	m_edDevRTSPport.SetWindowText(_T("554"));

	CString strOnvifUrl;
	m_edOnvifUrl.GetWindowText(strOnvifUrl);

	//pDevice->SetID( strStreamID );
	//pDevice->SetMAC(strMac);
	pDevice->SetModelType(strModelType);
	pDevice->SetModel(strDevName);
	pDevice->SetProfileName(strProfile);
	pDevice->SetAddress(strDevIP);
	pDevice->SetURL(strDevUrl);
	pDevice->SetRTSPPort(554);
	pDevice->SetHTTPPort(80);
	pDevice->SetHTTPSPort(443);
	pDevice->SetSSL(FALSE);
	pDevice->SetConnectionType(2);	
	pDevice->SetOnvifServiceUri(strOnvifUrl);
	pDevice->SetName( strDevName + strMac );
	pDevice->SetUser(_T("admin"));
	pDevice->SetPassword(_T("admin"));

	//������ ��ġ ����
	if ( m_pNRSManager->GetUpdateStreamInfoReq(pDevice, SendStr) )
	{
		if (m_pNRSManager->SendRecvXML(SendStr.c_str(), RecvStr) != NO_ERROR )
		{
			AfxMessageBox(_T("Failed to Modify the device."));
			return;
		}
	}
	CheckResValue(RecvStr);

	POSITION pos = m_listDevs.GetFirstSelectedItemPosition();
	if (pos)
	{
		int nItem = m_listDevs.GetNextSelectedItem(pos);

		//m_listDevs.SetItemText(dwCnt, 0, pDevice->GetID());
		//CString strDevType = pDevice->isDependOnNrs() ? _T("Hitron or Onvif") : _T("Unknown");
		//m_listDevs.SetItemText(dwCnt, 1, strDevType);
		//m_listDevs.SetItemText(dwCnt, 2, pDevice->GetMAC());
		m_listDevs.SetItemText(nItem, 3, pDevice->GetProfileName());
		m_listDevs.SetItemText(nItem, 4, pDevice->GetModelType());
		m_listDevs.SetItemText(nItem, 5, pDevice->GetModel());
		m_listDevs.SetItemText(nItem, 6, pDevice->GetAddress());
		m_listDevs.SetItemText(nItem, 7, pDevice->GetURL());
		CString strRTSPport;
		strRTSPport.Format(_T("%d"), pDevice->GetRTSPPort());
		m_listDevs.SetItemText(nItem, 8, strRTSPport);
		CString strConnType;
		strConnType.Format(_T("%d"), pDevice->GetConnectionType());
		m_listDevs.SetItemText(nItem, 9, strConnType);
		m_listDevs.SetItemText(nItem, 10, pDevice->GetOnvifServiceUri());
	}
	

}

void CDlgDeviceRegister::OnBnClickedBtnDevDelete()
{
	CString strStreamID;
	m_edStreamID.GetWindowText(strStreamID);

	std::tr1::shared_ptr<DEVICE_INFO> pDevice;
	if(!GetGlobalConfig().GetDevice(pDevice, strStreamID))
	{
		AfxMessageBox(_T("Device is deleted or It is not exist."));
		return;
	}

	//���õ� ��ġ�� ������̶�� ���� ���� 
	std::string SendStr, RecvStr;
	if ( m_pNRSManager->GetKillStreamReq(pDevice, SendStr) )
	{
		if (m_pNRSManager->SendRecvXML(SendStr.c_str(), RecvStr) != NO_ERROR )		
		{
			AfxMessageBox(_T("Failed to KillStreamReq"));
			return;
		}
	}

	//�������� ��ġȭ ������ ����Ǿ����� Ȯ���� ���� ���� ����
	int nLoop = 0;
	CString strXML, strTemp;
	do
	{
		Sleep(1000);

		if ( m_pNRSManager->IsKilledStreamReq(pDevice, SendStr))
		{
			if(m_pNRSManager->SendRecvXML(SendStr.c_str(), RecvStr) != NO_ERROR)
				TRACE(_T(" ���� ������?? \n"));
		}

		int nRet = CheckResValue(RecvStr);

		if (nRet==1)
			break;

		continue;

	} while(nLoop++ < 60);	


	if ( m_pNRSManager->GetDeleteStreamInfoReq(pDevice, SendStr) ) 
	{
		if (m_pNRSManager->SendRecvXML(SendStr.c_str(), RecvStr) != NO_ERROR )
		{
			AfxMessageBox(_T("Failed to Add the dsevice."));
			return;
		}
	}

	int nRet = CheckResValue(RecvStr);
	if (! nRet) return;


	pDevice->Free();
	std::wstring sStreamID = (LPCTSTR)strStreamID;
	GetGlobalConfig().m_mapDevices.erase(sStreamID);

	InitUI();

	CString strTarget;
	for (int i=0; i<m_listDevs.GetItemCount(); i++)
	{
		strTarget = m_listDevs.GetItemText(i, 0);
		if (strTarget == strStreamID)
		{
			m_listDevs.DeleteItem(i);
			break;
		}
	}
}

void CDlgDeviceRegister::EnableUI( BOOL bOnOff )
{
	m_edStreamID.EnableWindow(bOnOff);
	m_edMAC.EnableWindow(bOnOff);
	m_edProfile.EnableWindow(bOnOff);
	//m_edModelName.EnableWindow(bOnOff);
	//m_edDevIP.EnableWindow(bOnOff);
	m_edDevUrl.EnableWindow(bOnOff);
	m_edDevRTSPport.EnableWindow(bOnOff);
	//m_edOnvifUrl.EnableWindow(bOnOff);
}

CString CDlgDeviceRegister::CheckandNewMac()
{
	int nKeys[3] = {0, };
	for (int i=0; i<3; i++)
		nKeys[i] = rand() % 10000;

	//MAC - 12 �ڸ�
	CString strID;
	strID.Format(_T("%04d%04d%04d"), nKeys[0], nKeys[1], nKeys[2]);
	
	CString strValue;
	for (int i=0; i<m_listDevs.GetItemCount(); i++)
	{
		strValue = m_listDevs.GetItemText(i, 2);
		if (strID == strValue)
		{
			AfxMessageBox(_T("MAC ���� ���� ���� �����մϴ�. ���� ������ ������ �Է��ϼ���."));
			break;
		}
	}

	return strID;
}

int CDlgDeviceRegister::CheckResValue( std::string RecvStr )
{
	int nRet = -1;
	CXML xml;
	if(xml.LoadXMLFromString(RecvStr.c_str()))
	{
		MSXML2::IXMLDOMNodeListPtr pList = xml.FindNodeList(_T("//NRSError"));
		if(pList)
		{
			MSXML2::IXMLDOMNodePtr pNode;
			CString stream_id, err;
			long count = pList->Getlength();

			for(long i=0; i<count; i++)
			{
				pNode = pList->Getitem(i);
				stream_id	= CXML::GetAttributeValue(pNode, L"stream_id");
				err			= (LPCTSTR)pNode->Gettext();

				if(err != L"OK")
				{
					TRACE(_T("error kind !!  \n"));
					nRet = 0;
				} else 
					nRet = 1;
			}

		}
	}

	return nRet;
}

void CDlgDeviceRegister::OnNMClickListDevs(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	if (pNMItemActivate->iItem < 0) 
		return;
	
	int nSelectedRow = pNMItemActivate->iItem;
	int nSelectedCol = pNMItemActivate->iSubItem;
	
	if (nSelectedRow < 0) return;

	CString strStreamID;
	CString strDevType;
	CString strMac;
	CString strProfileName;
	CString strModelType;
	CString strDevName;
	CString strDevIP;
	CString strDevUrl;
	CString strRTSPport;
	CString strConnType;
	CString strOnvifUrl;

	int nIdx = pNMItemActivate->iItem;
	strStreamID = m_listDevs.GetItemText(nIdx, 0);
	strDevType = m_listDevs.GetItemText(nIdx, 1);	
	strMac = m_listDevs.GetItemText(nIdx, 2);
	strProfileName = m_listDevs.GetItemText(nIdx, 3);
	strModelType = m_listDevs.GetItemText(nIdx, 4);
	strDevName = m_listDevs.GetItemText(nIdx, 5);
	strDevIP = m_listDevs.GetItemText(nIdx, 6);
	strDevUrl = m_listDevs.GetItemText(nIdx, 7);
	strRTSPport = m_listDevs.GetItemText(nIdx, 8);
	strConnType = m_listDevs.GetItemText(nIdx, 9);
	strOnvifUrl = m_listDevs.GetItemText(nIdx, 10);

	m_edStreamID.SetWindowText(strStreamID);
	m_edMAC.SetWindowText(strMac);
	m_edProfile.SetWindowText(strProfileName);
	m_edModelName.SetWindowText(strDevName);
	m_edDevIP.SetWindowText(strDevIP);
	m_edDevUrl.SetWindowText(strDevUrl);
	m_edDevRTSPport.SetWindowText(strRTSPport);
	m_edOnvifUrl.SetWindowText(strOnvifUrl);
	
	if (strModelType == HT_SMODEL)
		m_cbModelType.SetCurSel(0);
	else if (strModelType == HT_HMODEL)
		m_cbModelType.SetCurSel(1);
	else if (strModelType == HT_ONVIF)
		m_cbModelType.SetCurSel(2);

	OnCbnSelchangeComboModelType();

	if ( strConnType == _T("2") )
		m_cbConnType.SetCurSel(0);
	else
		m_cbConnType.SetCurSel(1);


	*pResult = 0;
}

void CDlgDeviceRegister::OnBnClickedBtnClear()
{
	InitUI();
}

void CDlgDeviceRegister::InitUI()
{
	m_edStreamID.SetWindowText(_T(""));
	m_edMAC.SetWindowText(_T(""));
	m_edProfile.SetWindowText(_T(""));
	m_edModelName.SetWindowText(_T(""));
	m_edDevIP.SetWindowText(_T(""));
	m_edDevUrl.SetWindowText(_T(""));
	m_edDevRTSPport.SetWindowText(_T(""));
	m_edOnvifUrl.SetWindowText(_T(""));

	m_cbModelType.SetCurSel(0);
	m_cbConnType.SetCurSel(0);

}
void CDlgDeviceRegister::OnCbnSelchangeComboModelType()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	CString strProfile;
	CString strDevUrl;
	CString strDevIP;
	
	m_edProfile.EnableWindow(FALSE);
	m_edDevUrl.EnableWindow(FALSE);

	int nIdx = m_cbModelType.GetCurSel();
	switch (nIdx)
	{
	case 0 :
		m_edProfile.SetWindowText(_T("/1/stream1"));

		m_edDevIP.GetWindowText(strDevIP);
		m_edProfile.GetWindowText(strProfile);
		
		if (strDevIP.IsEmpty())
			strDevUrl = _T("");
		else
			strDevUrl = _T("rtsp://") + strDevIP + strProfile;
		m_edDevUrl.SetWindowText(strDevUrl);

		break;
	case 1 :
		m_edProfile.SetWindowText(_T("/1/stream0"));

		m_edDevIP.GetWindowText(strDevIP);
		m_edProfile.GetWindowText(strProfile);		
		if (strDevIP.IsEmpty())
			strDevUrl = _T("");
		else
			strDevUrl = _T("rtsp://") + strDevIP + strProfile;
		m_edDevUrl.SetWindowText(strDevUrl);

		break;
	case 2 :

		m_edProfile.EnableWindow(TRUE);
		m_edDevUrl.EnableWindow(TRUE);
		break;
	}
}


void CDlgDeviceRegister::OnBnClickedBtnRecordingSetup()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	if(GetDeviceSelected() < 0){
		AfxMessageBox(L"List���� Stream ID�� �������ּ���.", MB_OK | MB_ICONWARNING);
		return;
	}
	
	CDlgRecordingView dlg(m_pNRSManager, this, NULL);
	dlg.DoModal();
}

