/* ****************************************************************************** *\

INTEL CORPORATION PROPRIETARY INFORMATION
This software is supplied under the terms of a license agreement or nondisclosure
agreement with Intel Corporation and may not be copied or disclosed except in
accordance with the terms of that agreement
Copyright(c) 2008-2012 Intel Corporation. All Rights Reserved.

\* ****************************************************************************** */

#define PRODUCT_NAME "Intel\xae Media SDK"
#define FILE_VERSION 1,0,0,0
#define FILE_VERSION_STRING "1,0,0,0"
#define FILTER_NAME_PREFIX ""
#define FILTER_NAME_SUFFIX ""
#define PRODUCT_COPYRIGHT "Copyright\xa9 2003-2014 Intel Corporation"
#define PRODUCT_VERSION 1,0,0,0
#define PRODUCT_VERSION_STRING "1,0,0,0"
