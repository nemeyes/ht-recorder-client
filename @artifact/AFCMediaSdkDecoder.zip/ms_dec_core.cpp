#include "mfx_config.h"
#include "ms_defs.h"

#if defined(_WIN32) || defined(_WIN64)
#include <tchar.h>
#include <windows.h>
#endif

#include <ctime>
#include <algorithm>
#include "ms_dec_core.h"
#include "sysmem_allocator.h"

#if defined(_WIN32) || defined(_WIN64)
#include "d3d_allocator.h"
#include "d3d11_allocator.h"
#include "d3d_device.h"
#include "d3d11_device.h"
#endif

#if defined LIBVA_SUPPORT
#include "vaapi_allocator.h"
#include "vaapi_device.h"
#endif

#pragma warning(disable : 4100)

#define __SYNC_WA // avoid sync issue on Media SDK side

ms_dec_core::ms_dec_core(void)
{

    MSDK_ZERO_MEMORY(_mfx_bitstream);

    _mfx_decode = NULL;
    MSDK_ZERO_MEMORY(_mfx_video_params);

    _mfx_allocator = NULL;
    _mfx_allocator_params = NULL;
    _mem_type = MEMORY_TYPE_SYSTEM;
    _use_external_alloc = false;
    MSDK_ZERO_MEMORY(_mfx_frame_alloc_response);

    _current_free_surface = NULL;
    _current_free_output_surface = NULL;
    _current_output_surface = NULL;

    _deliver_output_semaphore = NULL;
    _delivered_event = NULL;
    _error = MFX_ERR_NONE;
    _stop_deliver_loop = false;

	_mode = MODE_PERFORMANCE;
    _enable_mvc = false;
    _use_ext_buffers = false;
    _use_video_wall = false;
    _complete_frame = false;
    _print_latency = false;

    _timeout = 0;
    _max_fps = 0;

    _vec_latency.reserve(1000); // reserve some space to reduce dynamic reallocation impact on pipeline execution

    _device = NULL;
}

ms_dec_core::~ms_dec_core(void)
{

}

CAFCMediaSdkDecoder::ERR_CODE ms_dec_core::initialize(unsigned int width, unsigned int height, PixelFormat cs)
{
	CONFIG_T config;
	config.bUseHWLib = true;
	config.videoType = MFX_CODEC_AVC;
	config.memType = MEMORY_TYPE_D3D9;
	config.bLowLat = true;
	config.bCalLat = true;
	//config.gpuCopy = MFX_GPUCOPY_OFF;
	config.nMaxFPS = 60;
	config.width = width;
	config.height = height;
	config.fourcc = MFX_FOURCC_YV12;
	config.nAsyncDepth = 4; //default


    mfxStatus sts = MFX_ERR_NONE;
	_mem_type = config.memType;
    _max_fps = config.nMaxFPS;
    _nframes = config.nFrames ? config.nFrames : MFX_INFINITE;


    mfxInitParam initPar;
    mfxExtThreadsParam threadsPar;
    mfxExtBuffer* extBufs[1];
    mfxVersion version;     // real API version with which library is initialized

    MSDK_ZERO_MEMORY(initPar);
    MSDK_ZERO_MEMORY(threadsPar);

    // we set version to 1.0 and later we will query actual version of the library which will got leaded
    initPar.Version.Major = 1;
    initPar.Version.Minor = 0;

    //initPar.GPUCopy = config.gpuCopy;

    init_ext_buffer(threadsPar);

    bool needInitExtPar = false;

    if (config.nThreadsNum) {
        threadsPar.NumThread = config.nThreadsNum;
        needInitExtPar = true;
    }
    if (config.SchedulingType) {
        threadsPar.SchedulingType = config.SchedulingType;
        needInitExtPar = true;
    }
    if (config.Priority) {
        threadsPar.Priority = config.Priority;
        needInitExtPar = true;
    }
    if (needInitExtPar) {
        extBufs[0] = (mfxExtBuffer*)&threadsPar;
        initPar.ExtParam = extBufs;
        initPar.NumExtParam = 1;
    }

    // Init session
    if (config.bUseHWLib) 
	{
        // try searching on all display adapters
        initPar.Implementation = MFX_IMPL_HARDWARE_ANY;
        // if d3d11 surfaces are used ask the library to run acceleration through D3D11
        // feature may be unsupported due to OS or MSDK API version
		if (MEMORY_TYPE_D3D11 == config.memType)
            initPar.Implementation |= MFX_IMPL_VIA_D3D11;

        sts = _mfx_session.InitEx(initPar);
        // MSDK API version may not support multiple adapters - then try initialize on the default
        if (MFX_ERR_NONE != sts) 
		{
            initPar.Implementation = (initPar.Implementation & !MFX_IMPL_HARDWARE_ANY) | MFX_IMPL_HARDWARE;
            sts = _mfx_session.InitEx(initPar);
        }
    } 
	else 
	{
        initPar.Implementation = MFX_IMPL_SOFTWARE;
        sts = _mfx_session.InitEx(initPar);
    }

	if(sts!=MFX_ERR_NONE)
		return CAFCMediaSdkDecoder::ERR_CODE_FAILED;

    sts = MFXQueryVersion(_mfx_session, &version); // get real API version of the loaded library
	if(sts!=MFX_ERR_NONE)
		return CAFCMediaSdkDecoder::ERR_CODE_FAILED;

    if (config.bIsMVC && !CheckVersion(&version, MSDK_FEATURE_MVC)) {
		//msdk_printf(MSDK_STRING("error: MVC is not supported in the %d.%d API version\n"), version.Major, version.Minor);
        return CAFCMediaSdkDecoder::ERR_CODE_FAILED;

    }
    if (config.bLowLat && !CheckVersion(&version, MSDK_FEATURE_LOW_LATENCY)) {
        //msdk_printf(MSDK_STRING("error: Low Latency mode is not supported in the %d.%d API version\n"), version.Major, version.Minor);
        return CAFCMediaSdkDecoder::ERR_CODE_FAILED;
    }

    // create decoder
    _mfx_decode = new MFXVideoDECODE(_mfx_session);
    // set video type in parameters
    _mfx_video_params.mfx.CodecId = config.videoType;
    // prepare bit stream
    if (MFX_CODEC_CAPTURE != config.videoType)
    {
        sts = InitMfxBitstream(&_mfx_bitstream, 1024 * 1024);
		if(sts!=MFX_ERR_NONE)
			return CAFCMediaSdkDecoder::ERR_CODE_FAILED;
    }

    if (CheckVersion(&version, MSDK_FEATURE_PLUGIN_API)) 
	{
        /* Here we actually define the following codec initialization scheme:
        *  1. If plugin path or guid is specified: we load user-defined plugin (example: VP8 sample decoder plugin)
        *  2. If plugin path not specified:
        *    2.a) we check if codec is distributed as a mediasdk plugin and load it if yes
        *    2.b) if codec is not in the list of mediasdk plugins, we assume, that it is supported inside mediasdk library
        */
        // Load user plug-in, should go after CreateAllocator function (when all callbacks were initialized)
        if (config.pluginParams.type == MFX_PLUGINLOAD_TYPE_FILE && strlen(config.pluginParams.strPluginPath))
        {
            _user_module.reset(new MFXVideoUSER(_mfx_session));
            if (_plugin.get() == NULL) 
				sts = MFX_ERR_UNSUPPORTED;
        }
        else
        {
            if (AreGuidsEqual(config.pluginParams.pluginGuid, MSDK_PLUGINGUID_NULL))
            {
                mfxIMPL impl = config.bUseHWLib ? MFX_IMPL_HARDWARE : MFX_IMPL_SOFTWARE;
                config.pluginParams.pluginGuid = msdkGetPluginUID(impl, MSDK_VDECODE, config.videoType);
            }
            if (!AreGuidsEqual(config.pluginParams.pluginGuid, MSDK_PLUGINGUID_NULL))
            {
                _plugin.reset(LoadPlugin(MFX_PLUGINTYPE_VIDEO_DECODE, _mfx_session, config.pluginParams.pluginGuid, 1));
                if (_plugin.get() == NULL) 
					sts = MFX_ERR_UNSUPPORTED;
            }
        }
		if(sts!=MFX_ERR_NONE)
			return CAFCMediaSdkDecoder::ERR_CODE_FAILED;
    }

    // Populate parameters. Involves DecodeHeader call
    sts = InitMfxParams(&config);
	if(sts!=MFX_ERR_NONE)
		return CAFCMediaSdkDecoder::ERR_CODE_FAILED;

    // create device and allocator
    sts = CreateAllocator();
	if(sts!=MFX_ERR_NONE)
		return CAFCMediaSdkDecoder::ERR_CODE_FAILED;

    // in case of HW accelerated decode frames must be allocated prior to decoder initialization
    sts = AllocFrames();
	if(sts!=MFX_ERR_NONE)
		return CAFCMediaSdkDecoder::ERR_CODE_FAILED;

    sts = _mfx_decode->Init(&_mfx_video_params);
    if (MFX_WRN_PARTIAL_ACCELERATION == sts)
    {
        msdk_printf(MSDK_STRING("WARNING: partial acceleration\n"));
        MSDK_IGNORE_MFX_STS(sts, MFX_WRN_PARTIAL_ACCELERATION);
    }
	if(sts!=MFX_ERR_NONE)
		return CAFCMediaSdkDecoder::ERR_CODE_FAILED;

	return CAFCMediaSdkDecoder::ERR_CODE_SUCCESS;
}

CAFCMediaSdkDecoder::ERR_CODE ms_dec_core::release(void)
{
	return CAFCMediaSdkDecoder::ERR_CODE_SUCCESS;
}

CAFCMediaSdkDecoder::ERR_CODE ms_dec_core::decode(unsigned char * input, unsigned int isize, unsigned int stride, unsigned char * output, unsigned int & osize, PixelFormat cs)
{
	return CAFCMediaSdkDecoder::ERR_CODE_SUCCESS;
}

mfxStatus ms_dec_core::InitMfxParams(CONFIG_T * config)
{
    mfxStatus sts = MFX_ERR_NONE;
    mfxU32 &numViews = config->numViews;

    // try to find a sequence header in the stream
    // if header is not found this function exits with error (e.g. if device was lost and there's no header in the remaining stream)
    for (; MFX_CODEC_CAPTURE != config->videoType;)
    {
        // trying to find PicStruct information in AVI headers
        if ( _mfx_video_params.mfx.CodecId == MFX_CODEC_JPEG )
            MJPEG_AVI_ParsePicStruct(&_mfx_bitstream);

        // parse bit stream and fill mfx params
        sts = _mfx_decode->DecodeHeader(&_mfx_bitstream, &_mfx_video_params);
        if (_plugin.get() && config->videoType == CODEC_VP8 && !sts) {
            // force set format to nv12 as the vp8 plugin uses yv12
            m_mfxVideoParams.mfx.FrameInfo.FourCC = MFX_FOURCC_NV12;
        }
        if (MFX_ERR_MORE_DATA == sts)
        {
            if (m_mfxBS.MaxLength == m_mfxBS.DataLength)
            {
                sts = ExtendMfxBitstream(&m_mfxBS, m_mfxBS.MaxLength * 2);
                MSDK_CHECK_RESULT(sts, MFX_ERR_NONE, sts);
            }
            // read a portion of data
            sts = m_FileReader->ReadNextFrame(&m_mfxBS);
            if (MFX_ERR_MORE_DATA == sts &&
                !(m_mfxBS.DataFlag & MFX_BITSTREAM_EOS))
            {
                m_mfxBS.DataFlag |= MFX_BITSTREAM_EOS;
                sts = MFX_ERR_NONE;
            }
            MSDK_CHECK_RESULT(sts, MFX_ERR_NONE, sts);

            continue;
        }
        else
        {
            // Enter MVC mode
            if (m_bIsMVC)
            {
                // Check for attached external parameters - if we have them already,
                // we don't need to attach them again
                if (NULL != m_mfxVideoParams.ExtParam)
                    break;

                // allocate and attach external parameters for MVC decoder
                sts = AllocateExtBuffer<mfxExtMVCSeqDesc>();
                MSDK_CHECK_RESULT(sts, MFX_ERR_NONE, sts);

                AttachExtParam();
                sts = m_pmfxDEC->DecodeHeader(&m_mfxBS, &m_mfxVideoParams);

                if (MFX_ERR_NOT_ENOUGH_BUFFER == sts)
                {
                    sts = AllocateExtMVCBuffers();
                    SetExtBuffersFlag();

                    MSDK_CHECK_RESULT(sts, MFX_ERR_NONE, sts);
                    MSDK_CHECK_POINTER(m_mfxVideoParams.ExtParam, MFX_ERR_MEMORY_ALLOC);
                    continue;
                }
            }

            // if input is interlaced JPEG stream
            if ( m_mfxBS.PicStruct == MFX_PICSTRUCT_FIELD_TFF || m_mfxBS.PicStruct == MFX_PICSTRUCT_FIELD_BFF)
            {
                m_mfxVideoParams.mfx.FrameInfo.CropH *= 2;
                m_mfxVideoParams.mfx.FrameInfo.Height = MSDK_ALIGN16(m_mfxVideoParams.mfx.FrameInfo.CropH);
                m_mfxVideoParams.mfx.FrameInfo.PicStruct = m_mfxBS.PicStruct;
            }

            switch(pParams->nRotation)
            {
            case 0:
                m_mfxVideoParams.mfx.Rotation = MFX_ROTATION_0;
                break;
            case 90:
                m_mfxVideoParams.mfx.Rotation = MFX_ROTATION_90;
                break;
            case 180:
                m_mfxVideoParams.mfx.Rotation = MFX_ROTATION_180;
                break;
            case 270:
                m_mfxVideoParams.mfx.Rotation = MFX_ROTATION_270;
                break;
            default:
                return MFX_ERR_UNSUPPORTED;
            }

            break;
        }
    }

    // check DecodeHeader status
    if (MFX_WRN_PARTIAL_ACCELERATION == sts)
    {
        msdk_printf(MSDK_STRING("WARNING: partial acceleration\n"));
        MSDK_IGNORE_MFX_STS(sts, MFX_WRN_PARTIAL_ACCELERATION);
    }
    MSDK_CHECK_RESULT(sts, MFX_ERR_NONE, sts);

    // If MVC mode we need to detect number of views in stream
    if (m_bIsMVC)
    {
        mfxExtMVCSeqDesc* pSequenceBuffer;
        pSequenceBuffer = (mfxExtMVCSeqDesc*) GetExtBuffer(m_mfxVideoParams.ExtParam, m_mfxVideoParams.NumExtParam, MFX_EXTBUFF_MVC_SEQ_DESC);
        MSDK_CHECK_POINTER(pSequenceBuffer, MFX_ERR_INVALID_VIDEO_PARAM);

        mfxU32 i = 0;
        numViews = 0;
        for (i = 0; i < pSequenceBuffer->NumView; ++i)
        {
            /* Some MVC streams can contain different information about
               number of views and view IDs, e.x. numVews = 2
               and ViewId[0, 1] = 0, 2 instead of ViewId[0, 1] = 0, 1.
               numViews should be equal (max(ViewId[i]) + 1)
               to prevent crashes during output files writing */
            if (pSequenceBuffer->View[i].ViewId >= numViews)
                numViews = pSequenceBuffer->View[i].ViewId + 1;
        }
    }
    else
    {
        numViews = 1;
    }

    // specify memory type
    m_mfxVideoParams.IOPattern = (mfxU16)(m_memType != SYSTEM_MEMORY ? MFX_IOPATTERN_OUT_VIDEO_MEMORY : MFX_IOPATTERN_OUT_SYSTEM_MEMORY);

    m_mfxVideoParams.AsyncDepth = pParams->nAsyncDepth;

    return MFX_ERR_NONE;
}