#include "AFCMediaSdkDecoder.h"
#include "ms_dec_core.h"

CAFCMediaSdkDecoder::CAFCMediaSdkDecoder(void)
	: _dec_core(0)
{
	_dec_core = new ms_dec_core();
}

CAFCMediaSdkDecoder::~CAFCMediaSdkDecoder(void)
{
	release();
	if(_dec_core)
	{
		delete _dec_core;
		_dec_core = 0;
	}
}

CAFCMediaSdkDecoder::ERR_CODE CAFCMediaSdkDecoder::initialize(unsigned int width, unsigned int height, PixelFormat cs)
{
	return _dec_core->initialize(width, height, cs);
}

CAFCMediaSdkDecoder::ERR_CODE CAFCMediaSdkDecoder::release(void)
{
	return _dec_core->release();
}

CAFCMediaSdkDecoder::ERR_CODE CAFCMediaSdkDecoder::decode(unsigned char * input, unsigned int isize, unsigned int stride, unsigned char * output, unsigned int & osize, PixelFormat cs)
{
	return _dec_core->decode(input, isize, stride, output, osize, cs);
}
