#ifndef _MEDIA_SDK_H264_DECODER_H_
#define _MEDIA_SDK_H264_DECODER_H_

#if defined(_WIN32)
# include <windows.h>
# if defined(EXPORT_LIB)
#  define EXP_DLL __declspec(dllexport)
# else
#  define EXP_DLL __declspec(dllimport)
# endif
#else
# define EXP_DLL
#endif

#include "ffmpeg/pixfmt.h"

class ms_dec_core;
class EXP_DLL CAFCMediaSdkDecoder
{
public:
	typedef enum _ERR_CODE
	{
		ERR_CODE_SUCCESS,
		ERR_CODE_FAILED,
		ERR_CODE_NO_OUTPUT_BITSTREAM
	} ERR_CODE;



	CAFCMediaSdkDecoder(void);
	~CAFCMediaSdkDecoder(void);



	CAFCMediaSdkDecoder::ERR_CODE initialize(unsigned int width, unsigned int height, PixelFormat cs);
	CAFCMediaSdkDecoder::ERR_CODE release(void);

	CAFCMediaSdkDecoder::ERR_CODE decode(unsigned char * input, unsigned int isize, unsigned int stride, unsigned char * output, unsigned int & osize, PixelFormat cs=PIX_FMT_NONE);


private:
	ms_dec_core * _dec_core;
	int _buffer_offset;


private:
    CAFCMediaSdkDecoder(const CAFCMediaSdkDecoder &);
    void operator=(const CAFCMediaSdkDecoder &);
};

#endif