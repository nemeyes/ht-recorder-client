#ifndef _CU_DEC_CORE_H_
#define _CU_DEC_CORE_H_

#if defined(_WIN32)
#include <windows.h>
#endif

#include <nvcuvid.h>
#include <cuda.h>
#include "AFCCudaDecoder.h"
#include "cu_driver_api.h"
#include "FrameQueue.h"
#include <deque>

#define MAX_DECODE_FRAMES 20
#define DISPLAY_DELAY	4
#define MAX_PIC_INDEX 64

typedef struct _FRAME_INFO_T
{
	unsigned char buffer[3110400]; //1920*1080*1.5
	unsigned int buffer_size;
} FRAME_INFO_T;

class cu_context_manager;
class cu_dec_core
{
public:
	cu_dec_core(void);
	~cu_dec_core(void);

	CAFCCudaDecoder::CU_DEC_ERR_CODE initialize(unsigned int width, unsigned int height, PixelFormat cs);
	CAFCCudaDecoder::CU_DEC_ERR_CODE release(void);
	CAFCCudaDecoder::CU_DEC_ERR_CODE decode(unsigned char * input, unsigned int isize, unsigned int stride, unsigned char * output, unsigned int & osize, PixelFormat cs=PIX_FMT_NONE);
private:
	CAFCCudaDecoder::CU_DEC_ERR_CODE flush(void);
	//CUVIDPARSERDISPINFO * get_next_frame(void);
	CAFCCudaDecoder::CU_DEC_ERR_CODE initialize_cuda(void);
	CAFCCudaDecoder::CU_DEC_ERR_CODE release_cuda(void);


	int fetch_video_data(unsigned char * data, unsigned int size);
	void clear_decoded_buffer(void);

	static int __stdcall on_video_sequence(void * user_data, CUVIDEOFORMAT * format);
	static int __stdcall on_picture_decode(void * user_data, CUVIDPICPARAMS * pic_params);
	static int __stdcall on_picture_display(void * user_data, CUVIDPARSERDISPINFO * pic_params);

	bool					_binit;

	CUvideoparser			_parser;
	CUvideodecoder			_decoder;
	CUvideoctxlock			_ctxlock;
	CUcontext				_context;
	CUVIDDECODECREATEINFO	_decode_info;
	CUVIDPARSERPARAMS		_params;

	std::deque<FRAME_INFO_T*> _frame_queue;	
	CRITICAL_SECTION		_cs;

	unsigned int			_width;
	unsigned int			_height;
	int						_device_pitch;
	int						_decoded_buffer_size;

#if defined(WITH_DYNAMIC_CUDA_LOAD)
	cu_driver_api			_driver_api;
#endif
};

#endif