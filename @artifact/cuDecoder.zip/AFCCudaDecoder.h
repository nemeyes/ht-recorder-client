#ifndef _CU_H264_DECODER_H_
#define _CU_H264_DECODER_H_

#if defined(_WIN32)
# include <windows.h>
# if defined(EXPORT_LIB)
#  define EXP_DLL __declspec(dllexport)
# else
#  define EXP_DLL __declspec(dllimport)
# endif
#else
# define EXP_DLL
#endif

#include "ffmpeg/pixfmt.h"

class cu_dec_core;
class EXP_DLL CAFCCudaDecoder
{
public:
	typedef enum _CU_DEC_ERR_CODE
	{
		ERR_CODE_SUCCESS,
		ERR_CODE_FAILED,
		ERR_CODE_NO_OUTPUT_BITSTREAM
	} CU_DEC_ERR_CODE;


	/*typedef enum _CU_DEC_COLOR_SPACE
	{
		COLOR_SPACE_YUY2,
		COLOR_SPACE_YV12,
		COLOR_SPACE_NV12,
		COLOR_SPACE_RGB24,
		COLOR_SPACE_RGB32
	} CU_DEC_COLOR_SPACE;*/

	CAFCCudaDecoder(void);
	~CAFCCudaDecoder(void);



	CAFCCudaDecoder::CU_DEC_ERR_CODE initialize(unsigned int width, unsigned int height, PixelFormat cs);
	CAFCCudaDecoder::CU_DEC_ERR_CODE release(void);

	CAFCCudaDecoder::CU_DEC_ERR_CODE decode(unsigned char * input, unsigned int isize, unsigned int stride, unsigned char * output, unsigned int & osize, PixelFormat cs=PIX_FMT_NONE);

	//static bool is_cuda_nvcuvid_supported(void);


private:
	cu_dec_core * _cu_dec_core;
	int _buffer_offset;
};

#endif