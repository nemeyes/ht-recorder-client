#include <cuda.h>
#include <cuviddec.h>
#include <nvcuvid.h>
#include <cuda_runtime_api.h>

#include "cu_dec_core.h"
#include "cu_auto_lock.h"
#include "TraceLog.h"

#define MAX_CONTEXT				1
#define MAX_DECODER				150 //Context �Ѱ��� �ִ� ���ڴ� ����
#define	MAX_DEVICE				1


#define MAX_BUFFER_REDUNDANCY	20

#define REQUIRED_MINIMUM_CUDA_DRIVER_VERSION 5050

#if !defined(WITH_DYNAMIC_CUDA_LOAD)
#pragma comment(lib, "cuda.lib")
#endif

#pragma comment(lib, "cudart.lib")
#pragma comment(lib, "nvcuvid.lib")

cu_dec_core::cu_dec_core(void)
	: _parser(0)
	, _decoder(0)
	, _device_pitch(0)
	, _binit(false)
{
#if defined(WITH_DYNAMIC_CUDA_LOAD)
	_driver_api.load();
#endif
	::InitializeCriticalSection(&_cs);
}

cu_dec_core::~cu_dec_core(void)
{
	//TRACELOG(LEVEL_DBG, _T("!#!# destroy"));
	release();
	::DeleteCriticalSection(&_cs);
#if defined(WITH_DYNAMIC_CUDA_LOAD)
	_driver_api.free();
#endif
}

CAFCCudaDecoder::CU_DEC_ERR_CODE cu_dec_core::initialize(unsigned int width, unsigned int height, PixelFormat cs)
{
	//TRACELOG(LEVEL_DBG, _T("!#!# initialize"));
	//release();
	if(_binit)
		return CAFCCudaDecoder::ERR_CODE_SUCCESS;

	CUresult result;
	memset(&_params, 0, sizeof(_params));
	memset(&_decode_info, 0, sizeof(_decode_info));

	if(initialize_cuda()!=CAFCCudaDecoder::ERR_CODE_SUCCESS)
		return CAFCCudaDecoder::ERR_CODE_FAILED;

/*
#if defined(WITH_DYNAMIC_CUDA_LOAD)
	CUDA_CONTEXT_T * cu_ctx = cu_context_manager::instance(&_driver_api).context();
#else
	CUDA_CONTEXT_T * cu_ctx = cu_context_manager::instance().context();
#endif
	_context = cu_ctx->context;
	_ctxlock = cu_ctx->ctxlock;
*/

	_params.CodecType = cudaVideoCodec_H264;
	_params.ulMaxNumDecodeSurfaces = MAX_DECODE_FRAMES;    // Limit decode memory to 24MB (16M pixels at 4:2:0 = 24M bytes)
	_params.ulMaxDisplayDelay = 4;  // FIXME, = 4 will trigger repeat pattern
	_params.pUserData = this;
	_params.pfnSequenceCallback = cu_dec_core::on_video_sequence;
	_params.pfnDecodePicture = cu_dec_core::on_picture_decode;
	_params.pfnDisplayPicture = cu_dec_core::on_picture_display;
	_params.ulErrorThreshold = 0;

	result = cuvidCreateVideoParser(&_parser, &_params);
	if (result != CUDA_SUCCESS)
	{
		release_cuda();
		return CAFCCudaDecoder::ERR_CODE_FAILED;
	}

	_width = width;
	_height = height;
	_binit = true;
	return CAFCCudaDecoder::ERR_CODE_SUCCESS;
}

CAFCCudaDecoder::CU_DEC_ERR_CODE cu_dec_core::release(void)
{
	if(!_binit)
		return CAFCCudaDecoder::ERR_CODE_SUCCESS;

	flush();

	CUresult status = cuvidDestroyDecoder(_decoder);
	//TRACELOG(LEVEL_DBG, _T("!#!# cuvidDestroyDecoder : %d"), status);
	status = cuvidDestroyVideoParser(_parser);
	//TRACELOG(LEVEL_DBG, _T("!#!# cuvidDestroyVideoParser : %d"), status);

	/*if (_decoder)
	{
		cu_auto_lock lock(_ctxlock);
		cuvidDestroyDecoder(_decoder);
		TRACELOG(LEVEL_DBG, _T("!#!# cuCtxDestroy Failed : %d"), status);
		_decoder = 0;
	}

	if (_parser)
	{
		cu_auto_lock lock(_ctxlock);
		cuvidDestroyVideoParser(_parser);
		_parser = 0;
	}*/

	::EnterCriticalSection(&_cs);
	clear_decoded_buffer();
	::LeaveCriticalSection(&_cs);

	_binit = false;

	return release_cuda();
	//return CAFCCudaDecoder::ERR_CODE_SUCCESS;
}

CAFCCudaDecoder::CU_DEC_ERR_CODE cu_dec_core::decode(unsigned char * input, unsigned int isize, unsigned int stride, unsigned char * output, unsigned int & osize, PixelFormat cs)
{
	if(!_binit)
		return CAFCCudaDecoder::ERR_CODE_SUCCESS;

	//TRACELOG(LEVEL_DBG, _T("!#!# CUDA Decode"));
	CAFCCudaDecoder::CU_DEC_ERR_CODE result = CAFCCudaDecoder::ERR_CODE_SUCCESS;

	fetch_video_data(input, isize);

	//TRACELOG(LEVEL_DBG, _T("!#!# Before Enter CriticalSection"));
	::EnterCriticalSection(&_cs);
	std::deque<FRAME_INFO_T*>::iterator iter;
	if(_frame_queue.size()>0)
	{
		FRAME_INFO_T * frame_info = _frame_queue.front();
		_frame_queue.pop_front();

		if(stride==0)
			stride = _width+32;
		unsigned int uv_width = _width >> 1;
		unsigned int uv_height = _height >> 1;

		unsigned char *dst_y = output + 32;//ffmpeg�� av_picture_size ��, ��¹��۷� ���Ǵ� ������ ù 32 bytes�� av_picture�� ��������
		unsigned char *dst_v = dst_y + stride*_height;
		unsigned char *dst_u = dst_v + ((stride*_height)>>2);

		unsigned int src_stride = _device_pitch;
		unsigned char *src_y = frame_info->buffer;
		unsigned char *src_uv = src_y + _device_pitch*_height;

		unsigned int decoded_buffer_size = (unsigned int)(stride*_height*1.5);

		for (unsigned int h = 0, h1 = 0; h<_height; h++, h1 = h1 + 2)
		{
			memcpy(dst_y + h*stride, src_y + h*src_stride, _width);
			if (h<uv_height)
			{
				for (unsigned int w = 0; w < _width; w = w + 2)
				{
					dst_v[((stride/2)*h)+(w>>1)] = src_uv[(h*src_stride) + w];
					dst_u[((stride/2)*h)+(w>>1)] = src_uv[(h*src_stride) + (w + 1)];
				}
			}
		}

		//TRACELOG(LEVEL_DBG, _T("!#!# Decode Success"));
		osize = decoded_buffer_size;
		free(frame_info);
		frame_info = 0;
		result = CAFCCudaDecoder::ERR_CODE_SUCCESS;
		
	}
	else
	{
		//TRACELOG(LEVEL_DBG, _T("!#!# Decode Failed"));
		osize = 0;
		result = CAFCCudaDecoder::ERR_CODE_SUCCESS;
	}

	::LeaveCriticalSection(&_cs);
	//TRACELOG(LEVEL_DBG, _T("!#!# After Leave CriticalSection"));
	return result;
}

CAFCCudaDecoder::CU_DEC_ERR_CODE cu_dec_core::flush(void)
{
	CUVIDSOURCEDATAPACKET pkt;
	memset(&pkt, 0x00, sizeof(pkt));
	pkt.flags |= CUVID_PKT_ENDOFSTREAM;
	CUresult result = CUDA_SUCCESS;

	cuvidCtxLock(_ctxlock, 0);
	__try
	{
		result = cuvidParseVideoData(_parser, &pkt);
	}
	__except(1)
	{
		result = CUDA_ERROR_UNKNOWN;
	}

	if (result == CUDA_SUCCESS)
	{
		//TRACELOG(LEVEL_DBG, _T("!#!# cuvidParseVideoData Success"));
		cuvidCtxUnlock(_ctxlock, 0);
		return CAFCCudaDecoder::ERR_CODE_SUCCESS;
	}
	else
	{
		TRACELOG(LEVEL_DBG, _T("!#!# cuvidParseVideoData Failed"));
		return CAFCCudaDecoder::ERR_CODE_FAILED;
	}
}

int cu_dec_core::fetch_video_data(unsigned char * data, unsigned int size)
{
	CUVIDSOURCEDATAPACKET pkt;
	CUresult result;

	if (size <= 0)
		return CAFCCudaDecoder::ERR_CODE_FAILED;

	pkt.flags = 0;
	pkt.payload_size = size;
	pkt.payload = data;
	pkt.timestamp = 0;  // not using timestamps

	cu_auto_lock lock(_ctxlock);
	result = cuvidParseVideoData(_parser, &pkt);
	if (result == CUDA_SUCCESS)
	{
		//TRACELOG(LEVEL_DBG, _T("!#!# cuvidParseVideoData Success"));
		return CAFCCudaDecoder::ERR_CODE_SUCCESS;
	}
	else
	{
		TRACELOG(LEVEL_DBG, _T("!#!# cuvidParseVideoData Failed"));
		return CAFCCudaDecoder::ERR_CODE_FAILED;
	}
}

int __stdcall cu_dec_core::on_video_sequence(void * user_data, CUVIDEOFORMAT * format)
{
	cu_dec_core * self = static_cast<cu_dec_core*>(user_data);

	CUresult result = CUDA_SUCCESS;
	if ((format->codec != self->_decode_info.CodecType) ||
		(format->coded_width != self->_decode_info.ulWidth) ||
		(format->coded_height != self->_decode_info.ulHeight) ||
		(format->chroma_format != self->_decode_info.ChromaFormat))
	{
		cu_auto_lock lock(self->_ctxlock);
		if (self->_decoder)
		{
			cuvidDestroyDecoder(self->_decoder);
			self->_decoder = 0;
		}
		memset(&self->_decode_info, 0, sizeof(CUVIDDECODECREATEINFO));
		self->_decode_info.ulWidth = format->display_area.right - format->display_area.left;
		self->_decode_info.ulHeight = format->display_area.bottom - format->display_area.top;
		self->_width = self->_decode_info.ulWidth;
		self->_height = self->_decode_info.ulHeight;
		self->_decode_info.display_area.bottom = format->display_area.bottom;
		self->_decode_info.display_area.left = format->display_area.left;
		self->_decode_info.display_area.right = format->display_area.right;
		self->_decode_info.display_area.top = format->display_area.top;
		self->_decode_info.ulNumDecodeSurfaces = MAX_DECODE_FRAMES;
		self->_decode_info.CodecType = format->codec;
		self->_decode_info.ChromaFormat = format->chroma_format;

		// Output (pass through)
		self->_decode_info.OutputFormat = cudaVideoSurfaceFormat_NV12;
		self->_decode_info.DeinterlaceMode = cudaVideoDeinterlaceMode_Adaptive; // Adaptive deinterlacing
		self->_decode_info.ulTargetWidth = self->_width;
		self->_decode_info.ulTargetHeight = self->_height;
		self->_decode_info.ChromaFormat = cudaVideoChromaFormat_420;
		self->_decode_info.ulNumOutputSurfaces = 2;

		self->_decode_info.display_area.right  = (short)self->_width;
		self->_decode_info.display_area.bottom = (short)self->_height;

		self->_decode_info.ulCreationFlags = cudaVideoCreate_PreferCUVID;
		self->_decode_info.vidLock = self->_ctxlock;

		// Create the decoder
		result = cuvidCreateDecoder(&self->_decoder, &self->_decode_info);
		if (result != CUDA_SUCCESS)
		{
			TRACELOG(LEVEL_DBG, _T("!#!# cuvidCreateDecoder Failed %d"), result);
			return 0;
		}
	}
	return 1;	
}

int __stdcall cu_dec_core::on_picture_decode(void * user_data, CUVIDPICPARAMS * pic_params)
{
	CUresult result;
	cu_dec_core * self = static_cast<cu_dec_core*>(user_data);

	if (self->_decoder)
	{
		cuvidCtxLock(self->_ctxlock, 0);
		__try 
		{
			result = cuvidDecodePicture(self->_decoder, pic_params);
			if (result != CUDA_SUCCESS)
			{
				TRACELOG(LEVEL_DBG, _T("!#!# cuvidDecodePicture Failed %d"), result);
				cuvidCtxUnlock(self->_ctxlock, 0);
				return 0;
			}
		} 
		__except(1) 
		{
			TRACELOG(LEVEL_DBG, _T("!#!# cuvidDecodePicture threw an exception"));
			cuvidCtxUnlock(self->_ctxlock, 0);
			return 0;
		}
	}
	cuvidCtxUnlock(self->_ctxlock, 0);
	return 1;
}

int __stdcall cu_dec_core::on_picture_display(void * user_data, CUVIDPARSERDISPINFO * pic_params)
{
	CUresult result;
	CUVIDPROCPARAMS vpp;
	CUdeviceptr device_ptr;
	cu_dec_core * self = static_cast<cu_dec_core*>(user_data);

	unsigned int pitch = 0, w, h;
	if (self->_decoder)
	{
		memset(&vpp, 0, sizeof(vpp));
		vpp.progressive_frame = pic_params->progressive_frame;
		vpp.top_field_first = pic_params->top_field_first;
		w = self->_decode_info.ulTargetWidth;
		h = self->_decode_info.ulTargetHeight;

		cu_auto_lock lock(self->_ctxlock);

		result = cuvidMapVideoFrame(self->_decoder, pic_params->picture_index, &device_ptr, &pitch, &vpp);
		if(result!=CUDA_SUCCESS)
			return 0;

		self->_device_pitch = pitch;

		::EnterCriticalSection(&self->_cs);

		if(self->_frame_queue.size()>MAX_BUFFER_REDUNDANCY)
			self->clear_decoded_buffer();

		FRAME_INFO_T * frame_info = static_cast<FRAME_INFO_T*>(malloc(sizeof(FRAME_INFO_T)));
		
		if (pitch > 0 && pitch <= 4096)
		{
			//TRACELOG(LEVEL_DBG, _T("!#!# Copy Decoded Frame"));
			frame_info->buffer_size = (unsigned int)(self->_device_pitch*h*1.5);
			cudaMemcpy(frame_info->buffer, (unsigned char *)device_ptr, frame_info->buffer_size, cudaMemcpyDeviceToHost);
		}
		self->_frame_queue.push_back(frame_info);
		::LeaveCriticalSection(&self->_cs);

		result = cuvidUnmapVideoFrame(self->_decoder, device_ptr);
		if(result!=CUDA_SUCCESS)
			return 0;
		//self->_is_decoded_picture = true;
	}
	return 1;
}

CAFCCudaDecoder::CU_DEC_ERR_CODE cu_dec_core::initialize_cuda(void)
{
	CUresult status;
	CUdevice device;
	int device_count = 0;
	int  SMminor = 0, SMmajor = 0;

#if defined(WITH_DYNAMIC_CUDA_LOAD)
	status = _driver_api.init(0);
	if (status != CUDA_SUCCESS)
	{
		TRACELOG(LEVEL_DBG, _T("!#!# cuInit Failed : %d"), status);
		return CAFCCudaDecoder::ERR_CODE_FAILED;
	}

	status = _driver_api.device_get_count(&device_count);
	if (status != CUDA_SUCCESS)
	{
		TRACELOG(LEVEL_DBG, _T("!#!# cuDeviceGetCount Failed : %d"), status);
		return CAFCCudaDecoder::ERR_CODE_FAILED;
	}

	size_t available_device_memory = 0;
	int device_id = -1;
	for (int index = 0; index < device_count; index++)
	{
		CUdevice tmp_device;
		size_t tmp_available_device_memory = 0;
		status = _driver_api.device_get(&tmp_device, index);
		if (status != CUDA_SUCCESS)
		{
			TRACELOG(LEVEL_DBG, _T("!#!# cuDeviceGet Failed : %d"), status);
			continue;
		}

		int version = 0;
		status = _driver_api.driver_get_version(&version);
		if (status != CUDA_SUCCESS)
		{
			TRACELOG(LEVEL_DBG, _T("!#!# cuDriverGetVersion Failed : %d"), status);
			continue;
		}
		if(version<REQUIRED_MINIMUM_CUDA_DRIVER_VERSION)
			continue;

		status = _driver_api.device_total_memory(&tmp_available_device_memory, tmp_device);
		if (status != CUDA_SUCCESS)
		{
			TRACELOG(LEVEL_DBG, _T("!#!# cuDeviceTotalMem Failed : %d"), status);
			continue;
		}

		if (available_device_memory < tmp_available_device_memory)
		{
			available_device_memory = tmp_available_device_memory;
			device_id = index;
		}
	}

	if (device_id<0)
		return CAFCCudaDecoder::ERR_CODE_FAILED;
	status = _driver_api.device_get(&device, device_id);
	if (status != CUDA_SUCCESS)
	{
		TRACELOG(LEVEL_DBG, _T("!#!# 2 cuDeviceGet Failed : %d"), status);
		return CAFCCudaDecoder::ERR_CODE_FAILED;
	}

	status = _driver_api.ctx_create(&_context, CU_CTX_BLOCKING_SYNC, 0);
	if (status != CUDA_SUCCESS)
	{
		TRACELOG(LEVEL_DBG, _T("!#!# cuCtxCreate Failed : %d"), status);
		return CAFCCudaDecoder::ERR_CODE_FAILED;
	}

	status = cuvidCtxLockCreate(&_ctxlock, _context);
	if (status != CUDA_SUCCESS)
	{
		TRACELOG(LEVEL_DBG, _T("!#!# cuvidCtxLockCreate Failed : %d"), status);
		return CAFCCudaDecoder::ERR_CODE_FAILED;
	}
#else
	status = cuInit(0);
	if (status != CUDA_SUCCESS)
		return CAFCCudaDecoder::ERR_CODE_FAILED;

	status = cuDeviceGetCount(&device_count);
	if (status != CUDA_SUCCESS)
		return CAFCCudaDecoder::ERR_CODE_FAILED;

	size_t available_device_memory = 0;
	int device_id = -1;
	for (int index = 0; index < device_count; index++)
	{
		CUdevice tmp_device;
		size_t tmp_available_device_memory = 0;
		status = cuDeviceGet(&tmp_device, index);
		if (status != CUDA_SUCCESS)
			continue;
		//status = cuDeviceComputeCapability(&SMmajor, &SMminor, tmp_device);
		//if (status != CUDA_SUCCESS)
		//	continue;
		//if (((SMmajor << 4) + SMminor) < 0x30)
		//	continue;
		status = cuDeviceTotalMem(&tmp_available_device_memory, tmp_device);
		if (status != CUDA_SUCCESS)
			continue;

		if (available_device_memory < tmp_available_device_memory)
			device_id = index;
	}

	if (device_id<0)
		return CAFCCudaDecoder::ERR_CODE_FAILED;
	status = cuDeviceGet(&device, device_id);
	if (status != CUDA_SUCCESS)
		return CAFCCudaDecoder::ERR_CODE_FAILED;

	status = cuCtxCreate(&_context.context, CU_CTX_BLOCKING_SYNC, 0);
	if (status != CUDA_SUCCESS)
		return CAFCCudaDecoder::ERR_CODE_FAILED;
	status = cuvidCtxLockCreate(&_context.ctxlock, _context.context);
	if (status != CUDA_SUCCESS)
		return CAFCCudaDecoder::ERR_CODE_FAILED;
#endif
	return CAFCCudaDecoder::ERR_CODE_SUCCESS;
}

CAFCCudaDecoder::CU_DEC_ERR_CODE cu_dec_core::release_cuda(void)
{
	CUresult status = cuvidCtxLockDestroy(*(&_ctxlock));
	if(status!=CUDA_SUCCESS)
	{
		TRACELOG(LEVEL_DBG, _T("!#!# cuvidCtxLockDestroy Failed : %d"), status);
	}

#if defined(WITH_DYNAMIC_CUDA_LOAD)
	status = _driver_api.ctx_destroy(_context);
#else
	status = cuCtxDestroy(_context.context);
#endif
	if(status!=CUDA_SUCCESS)
	{
		TRACELOG(LEVEL_DBG, _T("!#!# cuCtxDestroy Failed : %d"), status);
	}

/*
	if (_context)
	{
#if defined(WITH_DYNAMIC_CUDA_LOAD)
		_driver_api.ctx_destroy(_context);
#else
		cuCtxDestroy(_context.context);
#endif
		_context = 0;
	}
*/
	return CAFCCudaDecoder::ERR_CODE_SUCCESS;
}


void cu_dec_core::clear_decoded_buffer(void)
{
	while(_frame_queue.size()>0)
	{
		FRAME_INFO_T * frame_info = _frame_queue.front();
		_frame_queue.pop_front();
		free(frame_info);
		frame_info = 0;
	}
}