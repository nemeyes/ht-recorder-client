#include "AFCCudaDecoder.h"
#include "cu_dec_core.h"



CAFCCudaDecoder::CAFCCudaDecoder(void)
	: _cu_dec_core(0)
{
	_cu_dec_core = new cu_dec_core();
}

CAFCCudaDecoder::~CAFCCudaDecoder(void)
{
	release();
}

CAFCCudaDecoder::CU_DEC_ERR_CODE CAFCCudaDecoder::initialize(unsigned int width, unsigned int height, PixelFormat cs)
{
	return _cu_dec_core->initialize(width, height, cs);
}

CAFCCudaDecoder::CU_DEC_ERR_CODE CAFCCudaDecoder::release(void)
{
	CAFCCudaDecoder::CU_DEC_ERR_CODE result = _cu_dec_core->release();
	if (_cu_dec_core)
	{
		delete _cu_dec_core;
		_cu_dec_core = 0;
	}
	return result;
}

CAFCCudaDecoder::CU_DEC_ERR_CODE CAFCCudaDecoder::decode(unsigned char * input, unsigned int isize, unsigned int stride, unsigned char * output, unsigned int & osize, PixelFormat cs)
{
	return _cu_dec_core->decode(input, isize, stride, output, osize, cs);
}

/*
bool CAFCCudaDecoder::is_cuda_nvcuvid_supported(void)
{
	int  SMminor = 0, SMmajor = 0;
	int device_count = 0;
	cu_driver_api driver_api;
	if (!driver_api.load())
		return false;

	CUresult result = driver_api.init(0);
	if (result != CUDA_SUCCESS)
	{
		driver_api.free();
		return false;
	}

	result = driver_api.device_get_count(&device_count);
	if (result != CUDA_SUCCESS)
	{
		driver_api.free();
		return false;
	}

	if (device_count<1)
	{
		driver_api.free();
		return false;
	}

	size_t available_device_memory = 0;
	int device_id = -1;
	for (int index = 0; index < device_count; index++)
	{
		CUdevice tmp_device;
		size_t tmp_available_device_memory = 0;
		result = driver_api.device_get(&tmp_device, index);
		if (result != CUDA_SUCCESS)
			continue;

		int version = 0;
		result = driver_api.driver_get_version(&version);
		if (result != CUDA_SUCCESS)
			continue;
		if(version<REQUIRED_MINIMUM_CUDA_DRIVER_VERSION)
			continue;

		result = driver_api.device_total_memory(&tmp_available_device_memory, tmp_device);
		if (result != CUDA_SUCCESS)
			continue;

		if (available_device_memory < tmp_available_device_memory)
		{
			available_device_memory = tmp_available_device_memory;
			device_id = index;
		}

	if (device_id<0)
	{
		driver_api.free();
		return false;
	}

	driver_api.free();

#if defined(WIN32)
	HANDLE cu_dec_inst = LoadLibrary(TEXT("nvcuvid.dll"));
#else
	void * cu_dec_inst = dlopen("nvcuvid.so", RTLD_NOW);
#endif
	if (!cu_dec_inst)
		return false;

#if defined(WIN32)
	return FreeLibrary((HMODULE)cu_dec_inst) == TRUE ? true : false;
#else
	return dlclose(cu_dec_inst) == 0 ? true : false;
#endif

}
*/