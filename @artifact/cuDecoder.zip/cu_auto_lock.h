#ifndef _CU_AUTO_LOCK_H_
#define _CU_AUTO_LOCK_H_

#include <cuda.h>

class cu_auto_lock
{
private:
	CUvideoctxlock _ctx;

public:
	cu_auto_lock(CUvideoctxlock ctx)
		: _ctx(ctx)
	{
		cuvidCtxLock(_ctx, 0);
	};

	~cu_auto_lock(void)
	{
		cuvidCtxUnlock(_ctx, 0);
	};
};












#endif